# Промпт D2. Каталог: вкладка «Фьючерсы»

Новый фрейм рядом с Каталогом populated. Тот же layout, sidebar, topbar, header, метрики. Отличается: активный таб «Фьючерсы», другие колонки таблицы, другие фильтры.

## Палитра

Фон app: #0B0D10. Фон surface: #14171C. Border hairline: #1A1E25. Border subtle: #232831. Border default: #2D333E. Text primary: #E6E8EC. Text secondary: #9BA1AD. Text muted: #6B7280. Text disabled: #3E4451. Accent: #6366F1. Success fg/soft/border: #22C55E / #14532D / rgba(22,163,74,0.4). Warning fg/soft/border: #EAB308 / #713F12 / rgba(202,138,4,0.4). Error fg/soft/border: #EF4444 / #7F1D1D / rgba(220,38,38,0.4). Running fg/soft/border: #38BDF8 / #0C4A6E / rgba(14,165,233,0.4). Neutral fg/soft/border: #9CA3AF / #1F2937 / rgba(75,85,99,0.4). Font UI: Inter. Font mono: JetBrains Mono.

Тени карточки: 0 6px 16px -3px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.035).

## Таб «Фьючерсы» активен

Active: «Фьючерсы» 13px bold #E6E8EC, border-bottom 2px #6366F1.

### Breadcrumb

«DATA OPS / Инструменты / Фьючерсы».

## Фильтры (futures-specific)

«Базовый актив ▾» «Статус данных ▾» «Что загружено ▾» «Флаги ▾» «Отслеживание ▾».

Поиск: placeholder «Поиск secid, названия или asset_code (Si, BR)» 12px #6B7280.

Фильтр «Базовый актив»: значения Si, BR, RTS, GOLD... Futures-специфичный.

Фильтр «Что загружено»: candles / futoi / securities.

Фильтр «Флаги»: все / экспирация / нет связи / только asset_code / не обогащён / stale.

## Таблица фьючерсов

Caption: «ФЬЮЧЕРСЫ» 11px bold #6B7280 + «64» mono 11px #9BA1AD.

Колонки header (9px bold uppercase tracking 0.16em #6B7280):

ИНСТРУМЕНТ | БАЗОВЫЙ АКТИВ | ЭКСПИРАЦИЯ | ДН | ГО | КОМИССИЯ | СТАТУС ДАННЫХ | ЧТО ЗАГРУЖЕНО | ПЕРИОД | ПОКРЫТИЕ | ФЛАГИ | ОТСЛЕЖ. | ДЕЙСТВИЕ

**ИНСТРУМЕНТ:** secid 13px bold #E6E8EC, под ним shortname 10px mono #6B7280.

**БАЗОВЫЙ АКТИВ:** mono 13px bold #E6E8EC. Значение: «Si», «BR», «RTS». Ключевое поле — FUTOI загружается по asset_code.

**ЭКСПИРАЦИЯ:** mono 12px #9BA1AD. Значение: «20.06.26», «19.09.26». Формат DD.MM.YY. Источник: moex_forts_contracts.expiration_date. НЕ использовать last_trade_date как источник истины для экспирации.

**ДН:** mono 13px medium. Дней до экспирации. Значение: «12», «102». Цвет: <14 → #EF4444 (срочно), 14–30 → #EAB308 (скоро), >30 → #9BA1AD (нормально). Right-aligned.

**ГО:** mono 12px #9BA1AD. Значение: «15 420 ₽», «8 200 ₽». Из поля initial_margin. Right-aligned.

**КОМИССИЯ:** mono 12px #9BA1AD. Значение: «3.21 ₽», «—». Из поля buysell_fee. Right-aligned. Если null (не обогащён): «—» #3E4451.

**СТАТУС ДАННЫХ:** StatusBadge — как в D1.

**ЧТО ЗАГРУЖЕНО:** маленькие теги — как в D1.

**ПЕРИОД:** mono 12px #9BA1AD.

**ПОКРЫТИЕ:** mono 13px medium. 100% → #22C55E, 1–99% → #EAB308, 0% → #3E4451.

**ФЛАГИ:** маленькие теги — как в D1 плюс:
- экспирация: 9px mono, text #EF4444, bg #7F1D1D, border rgba(220,38,38,0.3)
- нет связи: 9px mono, text #9CA3AF, bg #1F2937, border rgba(75,85,99,0.3) — нет ни target_secid, ни target_asset_code
- только asset_code: 9px mono, text #38BDF8, bg #0C4A6E, border rgba(14,165,233,0.3) — есть target_asset_code, но нет связанной акции

**ОТСЛЕЖ.:** Toggle pill 28×16 — как в D1.

**ДЕЙСТВИЕ:** контекстная ссылка 12px bold — как в D1.

## 5 строк данных

| SiM6 | Фьюч. USD/RUB | Si | 20.06.26 | 12 (красный) | 15 420 ₽ | 3.21 ₽ | ● частично | candles, futoi | 01.12—31.12 | 88% | экспирация | ON | Открыть |
| SiU6 | Фьюч. USD/RUB | Si | 19.09.26 | 102 | 15 420 ₽ | 3.21 ₽ | ● не загружено | — | — | 0% | только asset_code | OFF | Загрузить |
| SiZ6 | Фьюч. USD/RUB | Si | 18.12.26 | 192 | 15 420 ₽ | — | ● не загружено | — | — | 0% | не обогащён | OFF | Загрузить |
| BRN6 | Фьюч. Brent | BR | 01.07.26 | 23 (жёлтый) | 8 200 ₽ | 2.00 ₽ | ● загружено | candles, futoi | 01.12—31.12 | 100% | — | ON | Открыть |
| GOLD-6.26 | Фьюч. золото | GOLD | 15.06.26 | 7 (красный) | 22 100 ₽ | 5.50 ₽ | ● частично | candles | 15.12—31.12 | 52% | экспирация | ON | Дозагрузить |

Группировка: строки с одинаковым asset_code идут рядом (три Si-контракта вместе).

Строки «не загружено» (SiU6, SiZ6): secid #6B7280, остальное #3E4451, action «Загрузить» #6366F1. НЕ disabled.

## Правила таблицы

Если таблица не помещается по ширине: не сжимать текст до нечитаемости. Оставить первую колонку «Инструмент» sticky. Разрешить горизонтальную прокрутку внутри table container. Не переносить числа ГО, комиссии, экспирации на две строки.

## Чего НЕ делать

- НЕ использовать #FFFFFF для обычного текста — #E6E8EC. Исключение: primary button.
- НЕ использовать индиго для бейджей статуса данных.
- НЕ использовать статусный цвет для primary кнопки.
- НЕ дублировать primary action на экране.
- НЕ делать glassmorphism, neon glow, градиенты.
- НЕ перегружать таблицу иконками.
- НЕ использовать last_trade_date как источник экспирации — только moex_forts_contracts.expiration_date.
- Все статусы на русском.
- Hover строк — тихий (bg #181C22 + 1px muted left).
- Selected — bg rgba(99,102,241,0.06) + 2px accent left.