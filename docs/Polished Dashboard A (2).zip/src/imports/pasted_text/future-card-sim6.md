# Промпт G. Карточка фьючерса — полная страница

Новый фрейм. Страница /instruments/SiM6.

Sidebar: DATA OPS раскрыт, «Инструменты» active. Topbar: breadcrumb «DATA OPS / Инструменты / SiM6».

## Палитра

Фон app: #0B0D10. Фон surface: #14171C. Фон elevated: #1C2027. Border hairline: #1A1E25. Border subtle: #232831. Border default: #2D333E. Text primary: #E6E8EC. Text secondary: #9BA1AD. Text muted: #6B7280. Text disabled: #3E4451. Accent: #6366F1. Success fg/soft/border: #22C55E / #14532D / rgba(22,163,74,0.4). Warning fg/soft/border: #EAB308 / #713F12 / rgba(202,138,4,0.4). Error fg/soft/border: #EF4444 / #7F1D1D / rgba(220,38,38,0.4). Running fg/soft/border: #38BDF8 / #0C4A6E / rgba(14,165,233,0.4). Neutral fg/soft/border: #9CA3AF / #1F2937 / rgba(75,85,99,0.4). Font UI: Inter. Font mono: JetBrains Mono.

Тени карточки: 0 6px 16px -3px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.035). Primary button: 0 4px 12px -2px rgba(99,102,241,0.3), inset 0 1px 0 rgba(255,255,255,0.18).

## Page header

«SiM6» 24px bold #E6E8EC. Под ним: «Фьючерс USD/RUB · Si · RFUD» 13px #9BA1AD. Badge «частично» (жёлтый). Рядом: «12 дней до экспирации» 12px bold #EF4444.

Справа: «Создать задание» primary + «Обогатить карточку» secondary.

## 4 мини-метрики (inline)

| Label 9px uppercase #6B7280 | Значение 13px mono #E6E8EC |
|---|---|
| Покрытие | 88% (#EAB308) |
| Загружено типов | 2 из 3 |
| До экспирации | 12 дн (#EF4444) |
| Откр. интерес | 1 245 000 |

## Секция 1: Параметры карточки фьючерса

Section label: «ПАРАМЕТРЫ» 10px uppercase tracking 0.14em #6B7280.

Карточка #14171C, border 1px #232831, radius 12px, padding 24px.

Два столбца (label 11px #6B7280, значение 13px #E6E8EC):

| Label | Значение | Label | Значение |
|---|---|---|---|
| Базовый актив | Si | Объём лота | 1 |
| Режим | RFUD | Шаг цены | 1 |
| Экспирация | 20.06.2026 | Цена шага | 1.00 ₽ |
| Дата поставки | 22.06.2026 | Верхний лимит | 98 500 |
| ГО | 15 420 ₽ | Нижний лимит | 82 300 |
| Откр. интерес | 1 245 000 | Комиссия биржи | 3.21 ₽ |
|  |  | Скальперская ком. | 0.50 ₽ |

Источник экспирации: moex_forts_contracts.expiration_date. last_trade_date показывать отдельной строкой как справочное поле, не как основную дату экспирации.

Warning если не обогащён: 3px бар #EAB308. «Биржевые комиссии и расчётная цена доступны после обогащения MarketStatistics.» 12px #EAB308. Action: «Обогатить карточку →» 12px #6366F1.

## Секция 2: Покрытие данных

Section label: «ПОКРЫТИЕ ДАННЫХ» 10px uppercase #6B7280 + «2 из 3 типов загружено» 11px #9BA1AD.

Таблица в карточке #14171C. Header 9px uppercase #6B7280.

ТИП ДАННЫХ | ИНТЕРВАЛ | ПЕРИОД | СТРОК | ХРАНИЛИЩЕ | СТАТУС | ОБНОВЛЕНО | ДЕЙСТВИЕ

| candles | 1m | 01.12—31.12 | 14 220 | file | ● ok | 09:39 | Открыть задания |
| futoi | — | 01.12—31.12 | 1 440 | file | ● ok | 09:39 | Открыть задания |
| securities | — | актуально | — | PostgreSQL | ● ok | сегодня | Обновить |

Пояснение под таблицей: «ℹ FUTOI загружается по asset_code Si, не по secid SiM6. Данные FUTOI покрывают все контракты на базовый актив.» 11px #6B7280.

## Секция 3: Таблица ролла

Section label: «КОНТРАКТЫ Si» 10px uppercase #6B7280 + «3 контракта» 11px #9BA1AD.

Источник: moex_forts_contracts. Таблица в карточке #14171C. Header 9px uppercase #6B7280.

КОНТРАКТ | ТИП | ЭКСПИРАЦИЯ | ДНЕЙ | WEEKEND | СТАТУС

| **SiM6** | quarterly | 20.06.2026 | **12** (#EF4444) | нет | ← текущий |
| SiU6 | quarterly | 19.09.2026 | 102 | нет | следующий |
| SiZ6 | quarterly | 18.12.2026 | 192 | нет | — |

Текущий контракт (SiM6) — bold #E6E8EC. Метка «← текущий» 10px #38BDF8.
Остальные — 13px #9BA1AD.
Weekend: «да»/«нет» из поля weekend_session.

## Секция 4: Связи

Section label: «СВЯЗИ» 10px uppercase #6B7280.

| Инструмент | Тип связи | Asset code | Confidence |
|---|---|---|---|
| — | future_underlying | Si | auto |

«Связанная акция не найдена. Базовый актив Si не соответствует secid ни одной акции.» 12px #9BA1AD.

Action: «Создать ручную связь →» 12px #6366F1.

## Секция 5: Ограничения и изменения

Как в промпте F. Для SiM6: «Активных приостановок нет.» 12px #9BA1AD с зелёной точкой.

## Секция 6: Последние действия

5 строк (время mono 11px #6B7280, описание 12px #9BA1AD):
- 09:39 · candles загружены · 14 220 строк
- 09:39 · futoi загружены · 1 440 строк (asset_code: Si)
- вчера · справочник instruments обновлён

## Чего НЕ делать

- НЕ добавлять графики цен, сигналы, торговые рекомендации — это DATA OPS-карточка.
- НЕ использовать #FFFFFF для обычного текста — #E6E8EC. Исключение: primary button.
- НЕ использовать индиго для бейджей статуса данных.
- НЕ использовать статусный цвет для primary кнопки.
- НЕ дублировать primary action на экране.
- НЕ показывать storage_target = none как полноценную доступность данных.
- НЕ использовать last_trade_date как источник экспирации — только moex_forts_contracts.expiration_date.
- Все статусы на русском.
- Hover строк — тихий (bg #181C22).