Ниже — пошаговые инструкции. Каждый блок — отдельное изменение. Применяй по порядку. Не удаляй существующие элементы, если не сказано прямо. Палитра остаётся Slate + Indigo, ничего не меняй в цветах — меняй материальность.

1. TOPBAR — добавь breadcrumb, LIVE-индикатор и ⌘K
Текущий топбар содержит поиск + «обновлено 09:42:18». Переделай его:
Левая часть:

Текст «MOEX Data Ops» размером 12px цветом #6B7280
Символ «/» размером 13px цветом #3E4451 с отступом 10px слева и справа
Текст «Dashboard» размером 13px font-weight 600 цветом #E6E8EC

Правая часть (через gap 18px между элементами):

Зелёная точка 6×6 border-radius 50% цветом #22C55E
Текст «LIVE» размером 10px font-weight 600 letter-spacing 0.14em цветом #22C55E
Разделитель gap 18px
Текст «обновлено» размером 11px цветом #6B7280
Текст «09:42:18» размером 12px моноширинным шрифтом (JetBrains Mono) цветом #9BA1AD
Разделитель gap 18px
Поле поиска: фон #14171C, border 1px #2D333E, border-radius 8px, padding 7px 8px 7px 12px, внутри:

Иконка search 12px цветом #6B7280
Текст «Поиск по тикеру…» размером 12px цветом #6B7280
Справа: бейдж «⌘K» — фон #0B0D10, border 1px #2D333E, border-radius 4px, padding 2px 6px, текст моноширинный 10px цветом #6B7280




2. HERO CARD — добавь тень и уточни структуру
Карточка hero (с текстом «Всё под контролем»):
Тень: box-shadow с двумя слоями:

Слой 1: offset 0 16px, blur 40px, spread -8px, цвет rgba(0,0,0,0.5)
Слой 2: offset 0 2px, blur 4px, spread 0, цвет rgba(0,0,0,0.35)

Внутренняя подсветка верхнего края:

inner shadow: offset 0 1px, blur 0, spread 0, цвет rgba(255,255,255,0.04) — это создаёт тонкую белую линию по верхнему краю карточки

Border: 1px solid #232831 (вместо #2D333E — тоньше визуально)
Верхний ряд внутри карточки — строка с eyebrow и кнопками:

Слева: зелёная точка 5×5 #22C55E, затем текст «СИСТЕМА · ГОТОВНОСТЬ 96%» размером 10px, font-weight 600, letter-spacing 0.18em, uppercase, цвет #6B7280
Справа: две кнопки в ряд — «Открыть операции» (secondary) и «Создать задание» (primary)

Заголовок «Всё под контролем»: размер 38px, font-weight 600, letter-spacing -0.02em, цвет #E6E8EC
Добавь горизонтальную линию-разделитель перед чеклистом: высота 1px, цвет #1A1E25
Над чеклистом добавь eyebrow-метку: «ЧТО НАСТРОЕНО» размер 10px, font-weight 600, letter-spacing 0.18em, uppercase, цвет #6B7280

3. METRIC CARDS — display-числа как герой
Каждая из 4 карточек метрик:
Тень: offset 0 6px, blur 16px, spread -3px, цвет rgba(0,0,0,0.4)
Inner shadow: offset 0 1px, blur 0, spread 0, цвет rgba(255,255,255,0.035)
Border: 1px solid #232831
Border-radius: 12px
Padding: 24px
Внутренняя структура (сверху вниз, вертикальный layout):

Label: текст UPPERCASE (например «ИНСТРУМЕНТЫ»), размер 9px, font-weight 600, letter-spacing 0.2em, цвет #6B7280
Отступ 16px
Число: моноширинный шрифт (JetBrains Mono), font-weight 500, размер 44px, letter-spacing -0.04em, цвет #E6E8EC. Это ГЛАВНЫЙ элемент карточки — он должен быть самым крупным.
Отступ 14px
Breakdown: текст размером 11px, цвет #9BA1AD. Например «183 акций · 64 фьючерса»
Отступ 6px
Delta: текст размером 11px. Если положительный — цвет #9BA1AD с зелёной точкой 5×5 #22C55E перед текстом. Если нейтральный — цвет #6B7280 без точки.

Данные для 4 карточек:
Карточка 1: label «ИНСТРУМЕНТЫ», число «247», breakdown «183 акций · 64 фьючерса», delta «+12 за неделю» (зелёная точка)
Карточка 2: label «ЗАДАНИЯ СЕГОДНЯ», число «32», breakdown «27 done · 3 running · 2 error», delta «6 в очереди» (без точки)
Карточка 3: label «СТРОК ЗА 24Ч», число «45 832», breakdown «средне 1 910 строк/час», delta «+8.4% к прошлым суткам» (зелёная точка)
Карточка 4: label «КАЧЕСТВО ДАННЫХ», число «98%», breakdown «12 предупреждений · 0 ошибок», delta «в пределах нормы» (без точки)

4. WARNINGS — вертикальный бар статуса + sub-line
Каждое предупреждение — отдельная карточка:

Фон: #14171C
Border: 1px solid #232831
Border-radius: 10px
Padding: 16px 18px
Shadow: offset 0 3px, blur 8px, spread -2px, rgba(0,0,0,0.3)

Внутри — горизонтальный layout:

Вертикальная полоса: ширина 3px, высота на всю высоту контента (~32px), border-radius 1.5px. Цвет зависит от типа:

warning: #EAB308
error: #EF4444
info: #38BDF8


Текстовый блок (через gap 14px от полосы):

Первая строка (title): размер 13px, font-weight 500, цвет #E6E8EC
Вторая строка (sub): размер 11px, цвет #6B7280


Справа — action-ссылка: текст вроде «Открыть карточку →», размер 12px, font-weight 600, цвет #6366F1

Данные (4 предупреждения):

warning, title «SiM6 — экспирация через 12 дней», sub «Карточка фьючерса требует продления календаря», action «Открыть карточку →»
error, title «GMKN candles 20.12—31.12 — задание упало», sub «MOEX вернул HTTP 429, последняя попытка 09:38:44», action «Повторить →»
warning, title «Пропуск в MGNT candles за 14.12», sub «Рабочий день, остальные даты периода загружены», action «Перезагрузить →»
info, title «Тариф брокера не введён», sub «Без тарифа полные издержки рассчитываются неверно», action «Ввести тариф →»

ВАЖНО: убери старые точки-маркеры перед текстом. Теперь индикатор статуса — только вертикальная полоса слева.

5. SIDEBAR — секции и карточка аккаунта
Структура sidebar сверху вниз:
Логотип (padding-left 12px):

Квадрат 24×24, border-radius 6px, фон #6366F1
Справа: «MOEX» 13px font-weight 600 letter-spacing 0.08em #E6E8EC, под ним «Data Operations» 10px letter-spacing 0.04em #6B7280

Секция «МОНИТОРИНГ» (отступ сверху 28px):

Метка секции: «МОНИТОРИНГ», размер 10px, font-weight 600, letter-spacing 0.16em, uppercase, цвет #6B7280, padding-left 14px, padding-bottom 8px
Пункты меню:

«Dashboard» — АКТИВНЫЙ: фон #1E1F3A, border-left 2px solid #6366F1, текст «Dashboard» 13px font-weight 600 цвет #6366F1, padding 10px 14px, border-radius 8px
«Инструменты» — обычный: без фона, текст 13px цвет #9BA1AD, padding 10px 16px
«Календарь» — обычный
«Загрузки» — обычный



Секция «АНАЛИТИКА» (отступ сверху 28px):

Метка секции: «АНАЛИТИКА» — тот же стиль что у МОНИТОРИНГ
Пункты:

«Качество» — обычный
«Издержки» — обычный
«Рейтинг» — обычный
«Логи» — обычный



Разделитель: линия 1px #1A1E25 (через auto-spacer к низу sidebar)
Пункт «Настройки» — обычный стиль
Карточка аккаунта (внизу):

Фон #0B0D10, border 1px solid #1A1E25, border-radius 8px, padding 8px 14px 8px 10px
Круг-аватар 30×30, border-radius 50%, фон #1E1F3A, border 1px solid rgba(99,102,241,0.4)
Справа: «Александр Е.» 12px font-weight 500 цвет #E6E8EC, под ним «Оператор · MOEX» 10px цвет #6B7280


6. TABLE — тихий hover и refined header
Header таблицы:

Фон: #0B0D10 (основной фон, чтобы header визуально утапливался)
Текст: 9px, font-weight 600, letter-spacing 0.16em, uppercase, цвет #6B7280
Padding: 14px 24px
Border-bottom: 1px solid #232831

Строки:

Padding: 16px 24px (увеличь с текущих ~12px)
Разделитель между строками: 1px rgba(26,30,37,0.6) — почти прозрачный

Колонка «Инструмент» — две строки: тикер 13px font-weight 600 #E6E8EC, под ним тип данных (candles/tradestats/etc) моноширинным 10px #6B7280
Колонка «Строк» — выравнивание по правому краю, моноширинный шрифт, font-weight 500, 13px, #E6E8EC, letter-spacing -0.02em
Selected row (MGNT, строка 7):

Фон: #1E1F3A
Border-left: 2px solid #6366F1
Вся строка чуть сдвигается правее на 2px (компенсация border)
Разделители вокруг этой строки: 1px solid #1E1F3A (чтобы не было резкого перехода)

Hover row (VTBR, строка ближе к концу):

Фон: #181C22
Border-left: 1px solid rgba(107,114,128,0.5)
Это имитация hover-состояния (статичная, не интерактивная)

ВАЖНО: обе строки (selected и hover) должны быть визуально заметны, но не кричать. Если убрать из dashboard все статусные бейджи — selected и hover всё равно должны быть видны по фону.

7. PRIMARY BUTTON — indigo glow
Кнопка «Создать задание» (и другие primary-кнопки):

Фон: #6366F1
Текст: белый #FFFFFF, 13px, font-weight 600
Padding: 10px 18px
Border-radius: 8px
Shadow: offset 0 4px, blur 12px, spread -2px, цвет rgba(99,102,241,0.3) — это создаёт мягкое индиго-свечение под кнопкой
Inner shadow: offset 0 1px, blur 0, spread 0, цвет rgba(255,255,255,0.18) — белая подсветка верхнего края кнопки

Кнопка secondary «Обновить справочники»:

Фон: #14171C
Border: 1px solid #2D333E
Текст: #E6E8EC, 13px, font-weight 500
Padding: 10px 18px
Border-radius: 8px
Без тени


8. SECTION LABELS — eyebrow + action link
Каждый section label (КЛЮЧЕВЫЕ МЕТРИКИ, ПРЕДУПРЕЖДЕНИЯ, ПОСЛЕДНИЕ ЗАГРУЗКИ) переделай:
Горизонтальный ряд с justify-content space-between:

Слева: текст UPPERCASE, 11px, font-weight 600, letter-spacing 0.14em, цвет #6B7280. Если есть счётчик — через gap 8px добавь число моноширинным 11px цвет #9BA1AD
Справа: ссылка вроде «Все метрики →» или «Все предупреждения →», 11px, font-weight 500, цвет #6366F1


9. TABLE CARD — общая обёртка
Таблица должна быть обёрнута в карточку:

Фон: #14171C
Border: 1px solid #232831
Border-radius: 12px
overflow: hidden (чтобы header с фоном #0B0D10 скруглялся по углам)
Shadow: offset 0 5px, blur 12px, spread -3px, rgba(0,0,0,0.35)
Inner shadow: offset 0 1px, blur 0, spread 0, rgba(255,255,255,0.03)

Над карточкой таблицы — caption-ряд:

Слева: «ПОСЛЕДНИЕ ЗАГРУЗКИ» eyebrow + число «15» моноширинным
Справа: зелёная точка 5×5 #22C55E + текст «обновлено 5 сек назад · авто-poll каждые 5 сек» размером 11px цвет #6B7280


10. FOOTER — статусная легенда + кнопки
Под таблицей — ряд с justify-content space-between:
Слева:

Eyebrow «СТАТУСНАЯ ЛЕГЕНДА», 10px, font-weight 600, letter-spacing 0.14em, #6B7280
Под ним: ряд из 4 бейджей done, warning, error, running (оставь существующие стили бейджей)

Справа:

Кнопка secondary «Обновить справочники»
Кнопка primary «Создать задание загрузки» (чуть крупнее: padding 12px 22px, font-size 14px)


11. STATUS BADGES — уточни border
Каждый бейдж:

done: фон #14532D, текст #22C55E, border 1px solid rgba(22,163,74,0.4), точка #22C55E
warning: фон #713F12, текст #EAB308, border 1px solid rgba(202,138,4,0.4), точка #EAB308
error: фон #7F1D1D, текст #EF4444, border 1px solid rgba(220,38,38,0.4), точка #EF4444
running: фон #0C4A6E, текст #38BDF8, border 1px solid rgba(14,165,233,0.4), точка #38BDF8

Размер: padding 3px 9px 3px 7px, border-radius 4px, font-size 11px font-weight 500. Точка 5×5 с gap 6px перед текстом.

12. TOGGLE SWITCHES
Пилюля переключателя watched/not-watched:

Размер: 28×16, border-radius 8px
ON-состояние: фон #6366F1, кнопка 12×12 #FFFFFF, position right (x=14, y=2)
OFF-состояние: фон #2D333E, кнопка 12×12 #6B7280, position left (x=2, y=2)


ОБЩИЕ ПРАВИЛА

Шрифт основной: Inter. Числа и mono-текст: JetBrains Mono
Основной фон dashboard: #0B0D10
Фон карточек/поверхностей: #14171C
Hairline-бордеры: #232831 (на карточках), #1A1E25 (разделители между строк)
Бордер на элементах ввода: #2D333E
Текст primary: #E6E8EC
Текст secondary: #9BA1AD
Текст muted: #6B7280
Акцент (индиго): #6366F1 — ТОЛЬКО для: active nav, primary кнопка, action-ссылки, selected row, toggle on, focus ring. Нигде больше.
Индиго не значит статус. Статус показывается ТОЛЬКО через success/warning/error/running бейджи и вертикальные полосы.
НЕ добавляй glassmorphism, neon glow, gradient overlay на весь экран, или decorative patterns.
НЕ используй чистый белый (#FFFFFF) для текста на тёмном фоне. Используй #E6E8EC.
Тени — двухслойные (длинная мягкая + короткая резкая). Inner shadow на верхнем крае карточек обязательна.