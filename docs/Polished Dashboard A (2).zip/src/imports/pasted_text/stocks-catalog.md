# Промпт D1. Каталог: вкладка «Акции»

Применить к фрейму: Каталог populated (36:6342).

Не менять header, метрики. Менять chips переключателя, фильтры и таблицу.

## Палитра

Фон app: #0B0D10. Фон surface: #14171C. Border hairline: #1A1E25. Border subtle: #232831. Border default: #2D333E. Text primary: #E6E8EC. Text secondary: #9BA1AD. Text muted: #6B7280. Text disabled: #3E4451. Accent: #6366F1. Success fg/soft/border: #22C55E / #14532D / rgba(22,163,74,0.4). Warning fg/soft/border: #EAB308 / #713F12 / rgba(202,138,4,0.4). Error fg/soft/border: #EF4444 / #7F1D1D / rgba(220,38,38,0.4). Running fg/soft/border: #38BDF8 / #0C4A6E / rgba(14,165,233,0.4). Neutral fg/soft/border: #9CA3AF / #1F2937 / rgba(75,85,99,0.4). Font UI: Inter. Font mono: JetBrains Mono.

Тени карточки: 0 6px 16px -3px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.035).

## Переключатель вкладок

Текущие chips «Все 247 / Акции 183 / Фьючерсы 64» заменить на полноценные табы.

3 таба: «Все» «Акции» «Фьючерсы».

Active tab (Акции): 13px bold #E6E8EC, border-bottom 2px #6366F1.
Inactive: 13px #9BA1AD, без border.
Под табами: линия 1px #1A1E25 на всю ширину.

На этом фрейме активен таб «Акции».

### Breadcrumb

«DATA OPS / Инструменты / Акции» 12px #6B7280 · 13px bold #E6E8EC.

## Фильтры (stock-specific)

Ряд dropdown-фильтров: «Статус данных ▾» «Что загружено ▾» «Листинг ▾» «Флаги ▾» «Отслеживание ▾». Каждый: фон #14171C, border 1px #2D333E, radius 6px, текст 13px #9BA1AD, padding 8px 12px.

Поиск: placeholder «Поиск secid, тикера или названия» 12px #6B7280.

«Сбросить фильтры» 12px #6B7280 справа.

Фильтр «Листинг»: значения 1, 2, 3 — уровень листинга MOEX.

Фильтр «Флаги»: все / не обогащён / обогащение частично / stale / ограничение / изменён.

Фильтр «Что загружено»: candles / tradestats / orderstats / obstats / securities.

## Таблица акций

Caption: «АКЦИИ» 11px bold #6B7280 + «183» mono 11px #9BA1AD.

Колонки header (9px bold uppercase tracking 0.16em #6B7280):

ИНСТРУМЕНТ | ЛИСТИНГ | ЛОТ | ШАГ ЦЕНЫ | СТАТУС ДАННЫХ | ЧТО ЗАГРУЖЕНО | ПЕРИОД | ПОКРЫТИЕ | ФЛАГИ | ОТСЛЕЖ. | ДЕЙСТВИЕ

**ИНСТРУМЕНТ:** secid 13px bold #E6E8EC, под ним shortname 10px mono #6B7280.

**ЛИСТИНГ:** mono 13px medium #E6E8EC. Значение: «1», «2», «3». Right-aligned.

**ЛОТ:** mono 13px medium #E6E8EC. Значение: «10», «100», «1». Right-aligned.

**ШАГ ЦЕНЫ:** mono 12px #9BA1AD. Значение: «0.01», «0.1», «—» (если не обогащён).

**СТАТУС ДАННЫХ:** StatusBadge (dot 5px + text 11px medium на soft-фоне, radius 4px, padding 3px 9px 3px 7px):
- загружено: dot #22C55E, text #22C55E, bg #14532D, border rgba(22,163,74,0.4)
- частично: dot #EAB308, text #EAB308, bg #713F12, border rgba(202,138,4,0.4)
- не загружено: dot #9CA3AF, text #9CA3AF, bg #1F2937, border rgba(75,85,99,0.4)
- требует проверки: dot #EAB308, text #EAB308, bg #713F12, border rgba(202,138,4,0.4)

**ЧТО ЗАГРУЖЕНО:** маленькие теги (10px mono #9BA1AD, фон #0B0D10, border 1px #232831, radius 3px, padding 2px 6px).

**ПЕРИОД:** mono 12px #9BA1AD.

**ПОКРЫТИЕ:** mono 13px medium. 100% → #22C55E, 1–99% → #EAB308, 0% → #3E4451.

**ФЛАГИ:** маленькие теги:
- не обогащён: 9px mono, text #EAB308, bg #713F12, border rgba(202,138,4,0.3), radius 3px, padding 2px 6px
- обогащение частично: 9px mono, text #EAB308, bg #713F12, border rgba(202,138,4,0.3) — часть полей MarketStatistics есть, но не все
- stale: 9px mono, text #9CA3AF, bg #1F2937, border rgba(75,85,99,0.3)
- ограничение: 9px mono, text #EF4444, bg #7F1D1D, border rgba(220,38,38,0.3)
- изменён: 9px mono, text #38BDF8, bg #0C4A6E, border rgba(14,165,233,0.3)
- Если нет флагов: «—» #3E4451

**ОТСЛЕЖ.:** Toggle pill 28×16, radius 8px. ON: фон rgba(99,102,241,0.75), knob 12px белый справа. OFF: фон #2D333E, knob 12px #6B7280 слева.

**ДЕЙСТВИЕ:** контекстная ссылка 12px bold. загружено → «Открыть» #6366F1, частично → «Дозагрузить» #EAB308, не загружено → «Загрузить» #6366F1, требует проверки → «Проверить» #EAB308.

## 5 строк данных

| SBER | Сбербанк | 1 | 10 | 0.01 | ● частично | candles, tradestats, orderstats | 01.12—31.12 | 92% | обогащение частично | ON | Дозагрузить |
| GAZP | Газпром | 1 | 10 | 0.01 | ● частично | candles, tradestats | 01.12—20.12 | 65% | stale | OFF | Дозагрузить |
| LKOH | Лукойл | 1 | 1 | 0.5 | ● не загружено | — | — | 0% | — | OFF | Загрузить |
| GMKN | Норникель | 1 | 1 | 1.0 | ● требует проверки | candles | 20.12—31.12 | пропуски | ограничение, изменён | ON | Проверить |
| VTBR | ВТБ | 1 | 10000 | 0.0001 | ● загружено | candles, orderstats, obstats | 01.12—31.12 | 100% | — | OFF | Открыть |

Строки «не загружено» (LKOH): secid #6B7280, остальное #3E4451, action «Загрузить» #6366F1. Строка НЕ disabled — hover работает, клик работает.

## Правила таблицы

Если таблица не помещается по ширине: не сжимать текст до нечитаемости. Оставить первую колонку «Инструмент» sticky. Разрешить горизонтальную прокрутку внутри table container. Не переносить числа лот, шаг цены, покрытие на две строки.

## Чего НЕ делать

- НЕ использовать #FFFFFF для обычного текста — #E6E8EC. Исключение: primary button.
- НЕ использовать индиго для бейджей статуса данных.
- НЕ использовать статусный цвет для primary кнопки.
- НЕ дублировать primary action на экране.
- НЕ делать glassmorphism, neon glow, градиенты.
- НЕ делать TRADING-страницы.
- НЕ перегружать таблицу иконками — теги достаточно текстовые.
- Все статусы на русском: загружено, частично, не загружено, требует проверки.
- Hover строк — тихий (bg #181C22 + 1px muted left).
- Selected — bg rgba(99,102,241,0.06) + 2px accent left.