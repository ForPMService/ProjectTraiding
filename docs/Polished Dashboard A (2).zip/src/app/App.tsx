import { useState } from 'react';
import { DashboardNormal } from './components/states/DashboardNormal';
import { DashboardEmpty } from './components/states/DashboardEmpty';
import { DashboardError } from './components/states/DashboardError';
import { DashboardLoading } from './components/states/DashboardLoading';
import { InstrumentsCatalogPopulated } from './components/instruments/InstrumentsCatalogPopulated';
import { InstrumentsCatalogWithDrawer } from './components/instruments/InstrumentsCatalogWithDrawer';
import { InstrumentsCatalogEmpty } from './components/instruments/InstrumentsCatalogEmpty';
import { StocksCatalog } from './components/catalog/StocksCatalog';
import { FuturesCatalog } from './components/catalog/FuturesCatalog';
import { StocksCatalogWithDrawer } from './components/catalog/StocksCatalogWithDrawer';
import { StockCard } from './components/cards/StockCard';
import { FutureCard } from './components/cards/FutureCard';
// New screens
import { LoadsScreen } from './components/loads/LoadsScreen';
import { CalendarScreen } from './components/calendar/CalendarScreen';
import { QualityScreen } from './components/quality/QualityScreen';
import { CostsScreen } from './components/costs/CostsScreen';
import { RatingScreen } from './components/rating/RatingScreen';
import { OperationsScreen } from './components/operations/OperationsScreen';
import { SettingsScreen } from './components/settings/SettingsScreen';
// Drawers
import { CreateJobDrawer } from './components/drawers/CreateJobDrawer';
import { BulkLoadDrawer } from './components/drawers/BulkLoadDrawer';
import { NewTariffDrawer } from './components/drawers/NewTariffDrawer';
import { CreateLinkDrawer } from './components/drawers/CreateLinkDrawer';
import type { NavPage } from './components/shell/AppShell';

type Page = 'dashboard' | 'instruments' | NavPage;
type DashboardState = 'normal' | 'empty' | 'error' | 'loading';
type InstrumentsState = 'populated' | 'with-drawer' | 'empty' | 'stocks-catalog' | 'futures-catalog' | 'stocks-with-drawer' | 'stock-card' | 'future-card';
type DrawerKind = 'none' | 'create-job' | 'bulk-load' | 'new-tariff' | 'create-link';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');
  const [dashboardState, setDashboardState] = useState<DashboardState>('normal');
  const [instrumentsState, setInstrumentsState] = useState<InstrumentsState>('populated');
  const [drawer, setDrawer] = useState<DrawerKind>('none');
  const [drawerInst, setDrawerInst] = useState<string | undefined>();

  const openCreateJob = (code?: string) => { setDrawerInst(code); setDrawer('create-job'); };
  const openBulkLoad  = () => setDrawer('bulk-load');
  const openNewTariff = () => setDrawer('new-tariff');
  const openCreateLink = (code: string) => { setDrawerInst(code); setDrawer('create-link'); };
  const closeDrawer   = () => { setDrawer('none'); setDrawerInst(undefined); };

  const handleNavigate = (page: NavPage) => setCurrentPage(page);

  // New-screen drawer host — wraps content area so drawer doesn't cover sidebar/topbar
  const newScreenDrawer = (
    <>
      {drawer === 'create-job' && <CreateJobDrawer instrumentCode={drawerInst} onClose={closeDrawer} />}
      {drawer === 'bulk-load'  && <BulkLoadDrawer onClose={closeDrawer} />}
      {drawer === 'new-tariff' && <NewTariffDrawer onClose={closeDrawer} />}
      {drawer === 'create-link' && drawerInst && <CreateLinkDrawer instrumentCode={drawerInst} onClose={closeDrawer} />}
    </>
  );

  return (
    <div className="relative" style={{ position: 'relative' }}>
      {/* ── EXISTING SCREENS (Dashboard + Instruments) ── */}
      {currentPage === 'dashboard' && (
        <>
          {dashboardState === 'normal'  && <DashboardNormal />}
          {dashboardState === 'empty'   && <DashboardEmpty />}
          {dashboardState === 'error'   && <DashboardError />}
          {dashboardState === 'loading' && <DashboardLoading />}
        </>
      )}

      {currentPage === 'instruments' && (
        <>
          {instrumentsState === 'populated'       && <InstrumentsCatalogPopulated />}
          {instrumentsState === 'with-drawer'     && <InstrumentsCatalogWithDrawer />}
          {instrumentsState === 'empty'           && <InstrumentsCatalogEmpty />}
          {instrumentsState === 'stocks-catalog'  && <StocksCatalog />}
          {instrumentsState === 'futures-catalog' && <FuturesCatalog />}
          {instrumentsState === 'stocks-with-drawer' && <StocksCatalogWithDrawer />}
          {instrumentsState === 'stock-card'      && <StockCard />}
          {instrumentsState === 'future-card'     && <FutureCard />}
        </>
      )}

      {/* ── NEW SCREENS ── */}
      {currentPage === 'loads' && (
        <div style={{ position: 'relative' }}>
          <LoadsScreen currentPage="loads" onNavigate={handleNavigate} onCreateJob={openCreateJob} onBulkLoad={openBulkLoad} />
          {newScreenDrawer}
        </div>
      )}
      {currentPage === 'calendar' && (
        <div style={{ position: 'relative' }}>
          <CalendarScreen currentPage="calendar" onNavigate={handleNavigate} />
          {newScreenDrawer}
        </div>
      )}
      {currentPage === 'quality' && (
        <div style={{ position: 'relative' }}>
          <QualityScreen currentPage="quality" onNavigate={handleNavigate} />
          {newScreenDrawer}
        </div>
      )}
      {currentPage === 'costs' && (
        <div style={{ position: 'relative' }}>
          <CostsScreen currentPage="costs" onNavigate={handleNavigate} onAddTariff={openNewTariff} />
          {newScreenDrawer}
        </div>
      )}
      {currentPage === 'rating' && (
        <div style={{ position: 'relative' }}>
          <RatingScreen currentPage="rating" onNavigate={handleNavigate} />
          {newScreenDrawer}
        </div>
      )}
      {currentPage === 'operations' && (
        <div style={{ position: 'relative' }}>
          <OperationsScreen currentPage="operations" onNavigate={handleNavigate} />
          {newScreenDrawer}
        </div>
      )}
      {currentPage === 'settings' && (
        <div style={{ position: 'relative' }}>
          <SettingsScreen currentPage="settings" onNavigate={handleNavigate} />
          {newScreenDrawer}
        </div>
      )}

      {/* ── STATE SWITCHER ── */}
      <div className="fixed bottom-6 right-6 z-50 bg-[#14171c] border border-[#232831] rounded-xl p-4 shadow-2xl" style={{ maxHeight: '88vh', overflowY: 'auto', width: 200 }}>
        {/* Page switcher */}
        <div className="mb-3 pb-3 border-b border-[#232831]">
          <div className="text-[9px] font-semibold tracking-[0.18em] uppercase text-[#3E4451] mb-2">ЭКРАН</div>
          <div className="flex flex-col gap-1">
            {[
              { id: 'dashboard',   label: 'Dashboard' },
              { id: 'instruments', label: 'Инструменты' },
              { id: 'loads',       label: 'Загрузки' },
              { id: 'calendar',    label: 'Календарь' },
              { id: 'quality',     label: 'Качество' },
              { id: 'costs',       label: 'Издержки' },
              { id: 'rating',      label: 'Рейтинг' },
              { id: 'operations',  label: 'Операции' },
              { id: 'settings',    label: 'Настройки' },
            ].map(p => (
              <SwitcherBtn key={p.id} label={p.label} active={currentPage === p.id} onClick={() => setCurrentPage(p.id as Page)} />
            ))}
          </div>
        </div>

        {/* Sub-state for dashboard */}
        {currentPage === 'dashboard' && (
          <div className="mb-3 pb-3 border-b border-[#232831]">
            <div className="text-[9px] font-semibold tracking-[0.18em] uppercase text-[#3E4451] mb-2">DASHBOARD</div>
            {(['normal', 'empty', 'error', 'loading'] as DashboardState[]).map(s => (
              <SwitcherBtn key={s} label={s} active={dashboardState === s} onClick={() => setDashboardState(s)} />
            ))}
          </div>
        )}

        {/* Sub-state for instruments */}
        {currentPage === 'instruments' && (
          <div className="mb-3 pb-3 border-b border-[#232831]">
            <div className="text-[9px] font-semibold tracking-[0.18em] uppercase text-[#3E4451] mb-2">INSTRUMENTS</div>
            {([
              { k: 'populated', l: 'Populated' },
              { k: 'with-drawer', l: 'With Drawer' },
              { k: 'empty', l: 'Empty' },
              { k: 'stocks-catalog', l: 'Stocks Catalog' },
              { k: 'futures-catalog', l: 'Futures Catalog' },
              { k: 'stocks-with-drawer', l: 'Stocks + Drawer' },
              { k: 'stock-card', l: 'Stock Card (SBER)' },
              { k: 'future-card', l: 'Future Card (SiM6)' },
            ] as { k: InstrumentsState; l: string }[]).map(s => (
              <SwitcherBtn key={s.k} label={s.l} active={instrumentsState === s.k} onClick={() => setInstrumentsState(s.k)} />
            ))}
          </div>
        )}

        {/* Drawers */}
        <div>
          <div className="text-[9px] font-semibold tracking-[0.18em] uppercase text-[#3E4451] mb-2">DRAWER</div>
          <SwitcherBtn label="Создать задание" active={drawer === 'create-job'} onClick={() => drawer === 'create-job' ? closeDrawer() : openCreateJob()} />
          <SwitcherBtn label="Массовая загрузка" active={drawer === 'bulk-load'} onClick={() => drawer === 'bulk-load' ? closeDrawer() : openBulkLoad()} />
          <SwitcherBtn label="Новый тариф" active={drawer === 'new-tariff'} onClick={() => drawer === 'new-tariff' ? closeDrawer() : openNewTariff()} />
          <SwitcherBtn label="Ручная связь" active={drawer === 'create-link'} onClick={() => drawer === 'create-link' ? closeDrawer() : openCreateLink('SBER')} />
        </div>
      </div>

      {/* Drawers when on old-style pages (overlay whole page) */}
      {(currentPage === 'dashboard' || currentPage === 'instruments') && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 40, pointerEvents: drawer !== 'none' ? 'auto' : 'none' }}>
          {drawer === 'create-job'  && <CreateJobDrawer instrumentCode={drawerInst} onClose={closeDrawer} />}
          {drawer === 'bulk-load'   && <BulkLoadDrawer onClose={closeDrawer} />}
          {drawer === 'new-tariff'  && <NewTariffDrawer onClose={closeDrawer} />}
          {drawer === 'create-link' && drawerInst && <CreateLinkDrawer instrumentCode={drawerInst} onClose={closeDrawer} />}
        </div>
      )}
    </div>
  );
}

function SwitcherBtn({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`block w-full text-left px-2.5 py-1.5 rounded-lg text-[11px] font-medium transition-all duration-150 mb-0.5 ${
        active
          ? 'bg-[#6366f1] text-white'
          : 'text-[#3E4451] hover:bg-[#1a1d24] hover:text-[#9BA1AD]'
      }`}
    >
      {label}
    </button>
  );
}
