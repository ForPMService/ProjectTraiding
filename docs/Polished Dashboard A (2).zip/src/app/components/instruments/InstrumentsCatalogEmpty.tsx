import { Sidebar } from '../Sidebar';
import { Topbar } from '../Topbar';

export function InstrumentsCatalogEmpty() {
  return (
    <div className="min-h-screen bg-[#0b0d10] font-['Inter',sans-serif]">
      <Sidebar activePage="instruments" />

      <div className="ml-[220px] min-h-screen">
        <Topbar liveStatus="live" breadcrumb="Инструменты" />

        <div className="p-8">
          {/* Page header */}
          <div className="mb-6">
            <h1 className="text-[24px] font-semibold tracking-[-0.01em] text-[#e6e8ec]">
              Инструменты
            </h1>
          </div>

          {/* Empty hero */}
          <div
            className="mb-8 bg-[#14171c] border border-[#232831] rounded-[14px] p-12 flex flex-col items-center text-center"
            style={{
              boxShadow: '0 16px 40px -8px rgba(0,0,0,0.5), 0 2px 4px 0 rgba(0,0,0,0.35), inset 0 1px 0 0 rgba(255,255,255,0.04)'
            }}
          >
            {/* Иконка */}
            <div className="w-12 h-12 mb-4 text-[#3e4451]">
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
              </svg>
            </div>

            {/* Заголовок */}
            <h2 className="text-[20px] font-semibold text-[#e6e8ec] mb-2">
              Каталог инструментов пуст
            </h2>

            {/* Описание */}
            <p className="text-[13px] text-[#9ba1ad] mb-6 max-w-[480px]">
              Загрузите справочник инструментов Московской биржи, чтобы выбирать акции и фьючерсы для загрузки рыночных данных.
            </p>

            {/* Кнопка */}
            <button
              className="px-6 py-3 bg-[#6366f1] rounded-lg text-[13px] font-semibold text-white hover:bg-[#5558e3] transition-all duration-200 mb-3"
              style={{
                boxShadow: '0 4px 12px -2px rgba(99,102,241,0.3), inset 0 1px 0 0 rgba(255,255,255,0.18)'
              }}
            >
              Загрузить справочник
            </button>

            {/* Ссылка */}
            <button className="text-[12px] font-semibold text-[#6366f1] hover:text-[#8084f4] transition-colors">
              Открыть настройки
            </button>
          </div>

          {/* Пустые метрики */}
          <div className="grid grid-cols-4 gap-4">
            <EmptyMetricCard label="ВСЕГО ИНСТРУМЕНТОВ" value="0" subtitle="справочник не загружен" />
            <EmptyMetricCard label="ЗАГРУЖЕНО" value="0" subtitle="—" />
            <EmptyMetricCard label="ЧАСТИЧНО" value="0" subtitle="—" />
            <EmptyMetricCard label="НЕ ЗАГРУЖЕНО" value="0" subtitle="—" />
          </div>
        </div>
      </div>
    </div>
  );
}

function EmptyMetricCard({ label, value, subtitle }: { label: string; value: string; subtitle: string }) {
  return (
    <div
      className="bg-[#14171c] border border-[#232831] rounded-xl p-6"
      style={{
        boxShadow: '0 6px 16px -3px rgba(0,0,0,0.4), inset 0 1px 0 0 rgba(255,255,255,0.035)'
      }}
    >
      <div className="text-[9px] tracking-[0.2em] font-semibold uppercase text-[#6b7280] mb-3">
        {label}
      </div>
      <div className="font-['JetBrains_Mono',monospace] text-[44px] font-medium tracking-[-0.04em] text-[#3e4451] leading-none mb-3 tabular-nums">
        {value}
      </div>
      <div className="text-[11px] text-[#6b7280]">{subtitle}</div>
    </div>
  );
}
