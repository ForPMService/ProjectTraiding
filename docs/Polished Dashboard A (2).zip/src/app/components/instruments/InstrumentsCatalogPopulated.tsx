import { Sidebar } from '../Sidebar';
import { Topbar } from '../Topbar';

export function InstrumentsCatalogPopulated() {
  const instruments = [
    { secid: 'SBER', name: 'Сбербанк', type: 'акция', status: 'частично', tags: ['candles', 'tradestats', 'orderstats'], period: '01.12 — 31.12', coverage: '92%', updated: '09:42', watched: true, action: 'Дозагрузить', selected: true },
    { secid: 'GAZP', name: 'Газпром', type: 'акция', status: 'частично', tags: ['candles', 'tradestats'], period: '01.12 — 20.12', coverage: '65%', updated: 'вчера', watched: false, action: 'Дозагрузить' },
    { secid: 'LKOH', name: 'Лукойл', type: 'акция', status: 'не загружено', tags: [], period: '—', coverage: '0%', updated: '—', watched: false, action: 'Загрузить' },
    { secid: 'GMKN', name: 'Норникель', type: 'акция', status: 'требует проверки', tags: ['candles'], period: '20.12 — 31.12', coverage: 'есть пропуски', updated: '09:38', watched: true, action: 'Проверить' },
    { secid: 'SiM6', name: 'Фьюч. USD/RUB', type: 'фьючерс', status: 'частично', tags: ['candles', 'futoi'], period: '01.12 — 31.12', coverage: '88%', updated: '09:39', watched: true, action: 'Открыть' },
    { secid: 'SiH7', name: 'Фьюч. USD/RUB', type: 'фьючерс', status: 'не загружено', tags: [], period: '—', coverage: '0%', updated: '—', watched: false, action: 'Загрузить' },
    { secid: 'VTBR', name: 'ВТБ', type: 'акция', status: 'загружено', tags: ['candles', 'orderstats', 'obstats'], period: '01.12 — 31.12', coverage: '100%', updated: '09:34', watched: false, action: 'Открыть' },
  ];

  return (
    <div className="min-h-screen bg-[#0b0d10] font-['Inter',sans-serif]">
      <Sidebar activePage="instruments" />

      <div className="ml-[220px] min-h-screen">
        <Topbar liveStatus="live" breadcrumb="Инструменты" />

        <div className="p-8">
          {/* Page header */}
          <div className="flex items-end justify-between mb-6">
            <div>
              <h1 className="text-[24px] font-semibold tracking-[-0.01em] text-[#e6e8ec] mb-1">
                Инструменты
              </h1>
              <p className="text-[13px] text-[#9ba1ad]">
                Каталог инструментов и покрытие загруженных данных
              </p>
            </div>
            <div className="flex items-center gap-2.5">
              <button className="px-[18px] py-[10px] bg-[#14171c] border border-[#2d333e] rounded-lg text-[13px] font-semibold text-[#e6e8ec] hover:border-[#6366f1]/50 hover:bg-[#16191f] transition-all duration-200">
                Обновить справочник
              </button>
              <button
                className="px-[18px] py-[10px] bg-[#6366f1] rounded-lg text-[13px] font-semibold text-white hover:bg-[#5558e3] transition-all duration-200"
                style={{
                  boxShadow: '0 4px 12px -2px rgba(99,102,241,0.3), inset 0 1px 0 0 rgba(255,255,255,0.18)'
                }}
              >
                Создать задание
              </button>
            </div>
          </div>

          {/* 4 метрики */}
          <div className="grid grid-cols-4 gap-4 mb-3">
            <MetricCard label="ВСЕГО ИНСТРУМЕНТОВ" value="247" subtitle="183 акции · 64 фьючерса" />
            <MetricCard label="ЗАГРУЖЕНО" value="155" subtitle="полное покрытие выбранного периода" />
            <MetricCard label="ЧАСТИЧНО" value="51" subtitle="есть пропуски или не все типы данных" />
            <MetricCard label="НЕ ЗАГРУЖЕНО" value="41" subtitle="инструмент есть, данных нет" />
          </div>

          <div className="text-[11px] text-[#6b7280] mb-6">
            Отслеживается 38 инструментов · требует проверки 3
          </div>

          {/* Фильтры */}
          <div className="flex items-center gap-2 mb-4">
            {/* Переключатель типа */}
            <div className="flex items-center gap-2">
              <TypeFilterButton label="Все 247" active />
              <TypeFilterButton label="Акции 183" />
              <TypeFilterButton label="Фьючерсы 64" />
            </div>

            <div className="w-px h-4 bg-[#232831]" />

            {/* Dropdown-фильтры */}
            <FilterDropdown label="Статус данных" />
            <FilterDropdown label="Что загружено" />
            <FilterDropdown label="Период покрытия" />
            <FilterDropdown label="Отслеживание" />

            <div className="w-px h-4 bg-[#232831]" />

            {/* Поиск */}
            <div className="flex items-center gap-2 bg-[#14171c] border border-[#2d333e] rounded-md py-2 px-3 flex-1 max-w-sm">
              <svg className="w-3.5 h-3.5 text-[#6b7280]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              <input
                type="text"
                placeholder="Поиск secid, тикера или названия"
                className="bg-transparent border-none outline-none text-[12px] text-[#e6e8ec] placeholder-[#6b7280] flex-1"
              />
            </div>

            <div className="flex-1" />

            <button className="text-[12px] text-[#6b7280] hover:text-[#9ba1ad] transition-colors">
              Сбросить фильтры
            </button>
          </div>

          {/* Таблица */}
          <div className="flex items-center gap-2 mb-3">
            <span className="text-[11px] font-semibold tracking-[0.14em] uppercase text-[#6b7280]">
              КАТАЛОГ
            </span>
            <span className="font-['JetBrains_Mono',monospace] text-[11px] text-[#9ba1ad]">247</span>
          </div>

          <div
            className="bg-[#14171c] border border-[#232831] rounded-xl overflow-hidden"
            style={{
              boxShadow: '0 6px 16px -3px rgba(0,0,0,0.4), inset 0 1px 0 0 rgba(255,255,255,0.035)'
            }}
          >
            {/* Table Header */}
            <div className="bg-[#0b0d10] px-6 py-3.5 flex items-center gap-4 border-b border-[#232831]">
              <div className="w-[120px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ИНСТРУМЕНТ</div>
              <div className="w-[80px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ТИП</div>
              <div className="w-[140px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">СТАТУС ДАННЫХ</div>
              <div className="w-[200px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ЧТО ЗАГРУЖЕНО</div>
              <div className="w-[120px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ПЕРИОД</div>
              <div className="w-[100px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ПОКРЫТИЕ</div>
              <div className="w-[90px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ОБНОВЛЕНО</div>
              <div className="w-[60px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280] text-center">ОТСЛЕЖ.</div>
              <div className="w-[100px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ДЕЙСТВИЕ</div>
            </div>

            {/* Table Rows */}
            <div className="bg-[#0b0d10]">
              {instruments.map((item, i) => {
                const isNotLoaded = item.status === 'не загружено';
                const isSelected = item.selected;

                return (
                  <div key={i}>
                    <div
                      className={`flex items-center gap-4 px-6 py-4 relative transition-all duration-200 cursor-pointer ${
                        isSelected ? 'bg-[rgba(99,102,241,0.06)]' : 'hover:bg-[#0f1216]'
                      }`}
                      style={{ paddingLeft: isSelected ? 'calc(1.5rem + 2px)' : '1.5rem' }}
                    >
                      {isSelected && <div className="absolute left-0 top-0 bottom-0 w-0.5 bg-[#6366f1]" />}

                      <div className="w-[120px]">
                        <div className={`font-semibold text-[13px] leading-none mb-1 ${isNotLoaded ? 'text-[#6b7280]' : 'text-[#e6e8ec]'}`}>
                          {item.secid}
                        </div>
                        <div className={`font-['JetBrains_Mono',monospace] text-[10px] ${isNotLoaded ? 'text-[#3e4451]' : 'text-[#6b7280]'}`}>
                          {item.name}
                        </div>
                      </div>

                      <div className={`w-[80px] text-[13px] ${isNotLoaded ? 'text-[#3e4451]' : 'text-[#9ba1ad]'}`}>
                        {item.type}
                      </div>

                      <div className="w-[140px]">
                        <DataStatusBadge status={item.status} />
                      </div>

                      <div className="w-[200px] flex items-center gap-1 flex-wrap">
                        {item.tags.length > 0 ? (
                          item.tags.map((tag, idx) => (
                            <span
                              key={idx}
                              className="font-['JetBrains_Mono',monospace] text-[10px] text-[#9ba1ad] bg-[#0b0d10] border border-[#232831] rounded px-1.5 py-0.5"
                            >
                              {tag}
                            </span>
                          ))
                        ) : (
                          <span className="text-[13px] text-[#3e4451]">—</span>
                        )}
                      </div>

                      <div className={`w-[120px] font-['JetBrains_Mono',monospace] text-[12px] ${isNotLoaded ? 'text-[#3e4451]' : 'text-[#9ba1ad]'}`}>
                        {item.period}
                      </div>

                      <div className="w-[100px]">
                        <CoverageText coverage={item.coverage} />
                      </div>

                      <div className={`w-[90px] font-['JetBrains_Mono',monospace] text-[12px] ${isNotLoaded ? 'text-[#3e4451]' : 'text-[#6b7280]'}`}>
                        {item.updated}
                      </div>

                      <div className="w-[60px] flex justify-center">
                        <Toggle checked={item.watched} />
                      </div>

                      <div className="w-[100px]">
                        <ActionButton action={item.action} status={item.status} />
                      </div>
                    </div>
                    {i < instruments.length - 1 && (
                      <div className="h-px bg-[rgba(26,30,37,0.6)]" />
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function MetricCard({ label, value, subtitle }: { label: string; value: string; subtitle: string }) {
  return (
    <div
      className="bg-[#14171c] border border-[#232831] rounded-xl p-6"
      style={{
        boxShadow: '0 6px 16px -3px rgba(0,0,0,0.4), inset 0 1px 0 0 rgba(255,255,255,0.035)'
      }}
    >
      <div className="text-[9px] tracking-[0.2em] font-semibold uppercase text-[#6b7280] mb-3">
        {label}
      </div>
      <div className="font-['JetBrains_Mono',monospace] text-[44px] font-medium tracking-[-0.04em] text-[#e6e8ec] leading-none mb-3 tabular-nums">
        {value}
      </div>
      <div className="text-[11px] text-[#9ba1ad]">{subtitle}</div>
    </div>
  );
}

function TypeFilterButton({ label, active = false }: { label: string; active?: boolean }) {
  return (
    <button
      className={`px-3 py-1.5 rounded-md text-[13px] font-medium transition-all duration-200 ${
        active
          ? 'bg-[rgba(30,31,58,1)] border border-[#6366f1] text-[#6366f1]'
          : 'border border-[#232831] text-[#9ba1ad] hover:border-[#2d333e] hover:text-[#c2c8d2]'
      }`}
    >
      {label}
    </button>
  );
}

function FilterDropdown({ label }: { label: string }) {
  return (
    <button className="flex items-center gap-2 bg-[#14171c] border border-[#2d333e] rounded-md py-2 px-3 text-[13px] text-[#9ba1ad] hover:border-[#6366f1]/40 transition-all duration-200">
      {label}
      <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
      </svg>
    </button>
  );
}

function DataStatusBadge({ status }: { status: string }) {
  const configs: Record<string, { bg: string; border: string; dot: string; text: string }> = {
    'загружено': { bg: '#14532d', border: 'rgba(22,163,74,0.4)', dot: '#22c55e', text: '#22c55e' },
    'частично': { bg: '#713f12', border: 'rgba(202,138,4,0.4)', dot: '#eab308', text: '#eab308' },
    'не загружено': { bg: '#1f2937', border: 'rgba(75,85,99,0.4)', dot: '#9ca3af', text: '#9ca3af' },
    'требует проверки': { bg: '#713f12', border: 'rgba(202,138,4,0.4)', dot: '#eab308', text: '#eab308' },
  };

  const config = configs[status] || configs['не загружено'];

  return (
    <div
      className="inline-flex items-center gap-1.5 py-[3px] pl-[7px] pr-[9px] rounded"
      style={{
        backgroundColor: config.bg,
        border: `1px solid ${config.border}`
      }}
    >
      <div className="w-[5px] h-[5px] rounded-sm" style={{ backgroundColor: config.dot }} />
      <span className="text-[11px] font-medium" style={{ color: config.text }}>{status}</span>
    </div>
  );
}

function CoverageText({ coverage }: { coverage: string }) {
  let color = '#3e4451';
  if (coverage === '100%') color = '#22c55e';
  else if (coverage.includes('%')) {
    const percent = parseInt(coverage);
    if (percent >= 65) color = '#eab308';
  } else if (coverage === 'есть пропуски') {
    return <span className="text-[11px] text-[#eab308]">{coverage}</span>;
  }

  return (
    <span className="font-['JetBrains_Mono',monospace] text-[13px] font-medium" style={{ color }}>
      {coverage}
    </span>
  );
}

function Toggle({ checked }: { checked: boolean }) {
  return (
    <div
      className={`w-7 h-4 rounded-lg relative transition-all duration-200 cursor-pointer ${
        checked ? 'bg-[rgba(99,102,241,0.75)]' : 'bg-[#2d333e]'
      }`}
    >
      <div
        className={`absolute top-0.5 w-3 h-3 rounded-md transition-all duration-200 ${
          checked ? 'left-[14px] bg-white' : 'left-0.5 bg-[#6b7280]'
        }`}
      />
    </div>
  );
}

function ActionButton({ action, status }: { action: string; status: string }) {
  const colorMap: Record<string, string> = {
    'загружено': '#6366f1',
    'частично': '#eab308',
    'не загружено': '#6366f1',
    'требует проверки': '#eab308',
  };

  const color = colorMap[status] || '#6366f1';

  return (
    <button
      className="text-[12px] font-semibold transition-all duration-200 hover:translate-x-0.5"
      style={{ color }}
    >
      {action}
    </button>
  );
}
