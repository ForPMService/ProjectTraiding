import { InstrumentsCatalogPopulated } from './InstrumentsCatalogPopulated';

export function InstrumentsCatalogWithDrawer() {
  return (
    <div className="relative">
      <InstrumentsCatalogPopulated />

      {/* Drawer */}
      <div
        className="fixed right-0 top-0 h-screen w-[480px] bg-[#1c2027] p-8 overflow-y-auto z-30"
        style={{
          borderTopLeftRadius: '16px',
          borderBottomLeftRadius: '16px',
          boxShadow: '0 24px 64px -12px rgba(0,0,0,0.7), 0 8px 16px -4px rgba(0,0,0,0.5)'
        }}
      >
        {/* Шапка drawer */}
        <div className="flex items-start justify-between mb-4">
          <div>
            <h2 className="text-[20px] font-semibold text-[#e6e8ec] mb-1">SBER</h2>
            <p className="text-[13px] text-[#9ba1ad]">Сбербанк · акция</p>
          </div>
          <button className="text-[20px] text-[#6b7280] hover:text-[#9ba1ad] transition-colors">
            ×
          </button>
        </div>

        <div className="h-px bg-[#1a1e25] my-4" />

        {/* Статус */}
        <div className="mb-4">
          <div
            className="inline-flex items-center gap-1.5 py-[3px] pl-[7px] pr-[9px] rounded"
            style={{
              backgroundColor: '#713f12',
              border: '1px solid rgba(202,138,4,0.4)'
            }}
          >
            <div className="w-[5px] h-[5px] rounded-sm bg-[#eab308]" />
            <span className="text-[11px] font-medium text-[#eab308]">частично</span>
          </div>
        </div>

        {/* Отслеживание */}
        <div className="flex items-start gap-3 mb-4">
          <div className="w-7 h-4 rounded-lg bg-[rgba(99,102,241,0.75)] relative mt-0.5">
            <div className="absolute top-0.5 left-[14px] w-3 h-3 rounded-md bg-white" />
          </div>
          <p className="text-[12px] text-[#9ba1ad] flex-1">
            Инструмент отслеживается. Система проверяет свежесть данных и пропуски.
          </p>
        </div>

        <div className="h-px bg-[#1a1e25] my-4" />

        {/* Секция ПОКРЫТИЕ ДАННЫХ */}
        <div className="mb-6">
          <h3 className="text-[10px] tracking-[0.14em] font-semibold uppercase text-[#6b7280] mb-3">
            ПОКРЫТИЕ ДАННЫХ
          </h3>

          {/* Header */}
          <div className="flex items-center gap-3 pb-2 border-b border-[#1a1e25]">
            <div className="w-[100px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ТИП ДАННЫХ</div>
            <div className="w-[90px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">СТАТУС</div>
            <div className="flex-1 text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ПЕРИОД</div>
            <div className="w-[70px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ОБНОВЛЕНО</div>
          </div>

          {/* Rows */}
          <div className="space-y-0">
            <DataTypeRow type="candles" status="загружено" period="01.12 — 31.12" updated="09:42" />
            <DataTypeRow type="tradestats" status="загружено" period="01.12 — 31.12" updated="09:41" />
            <DataTypeRow type="orderstats" status="загружено" period="01.12 — 31.12" updated="09:40" />
            <DataTypeRow type="obstats" status="не загружено" period="—" updated="—" action="Загрузить" />
            <DataTypeRow type="securities" status="загружено" period="актуально" updated="сегодня" action="Обновить" />
          </div>
        </div>

        <div className="h-px bg-[#1a1e25] my-4" />

        {/* Секция ПРОБЛЕМЫ */}
        <div className="mb-6">
          <h3 className="text-[10px] tracking-[0.14em] font-semibold uppercase text-[#6b7280] mb-3">
            ПРОБЛЕМЫ
          </h3>
          <div className="flex items-start gap-2">
            <div className="w-[5px] h-[5px] rounded-full bg-[#eab308] mt-1.5 shrink-0" />
            <p className="text-[13px] text-[#eab308]">
              obstats не загружен — данные по стаканам отсутствуют
            </p>
          </div>
        </div>

        <div className="h-px bg-[#1a1e25] my-4" />

        {/* Секция ПОСЛЕДНИЕ ДЕЙСТВИЯ */}
        <div className="mb-6">
          <h3 className="text-[10px] tracking-[0.14em] font-semibold uppercase text-[#6b7280] mb-3">
            ПОСЛЕДНИЕ ДЕЙСТВИЯ
          </h3>
          <div className="space-y-2">
            <ActionLogItem time="09:42" text="candles загружены успешно" />
            <ActionLogItem time="09:41" text="tradestats загружены успешно" />
            <ActionLogItem time="09:40" text="orderstats загружены успешно" />
          </div>
        </div>

        <div className="h-px bg-[#1a1e25] my-4" />

        {/* Кнопки внизу drawer */}
        <div className="space-y-2">
          <button
            className="w-full px-4 py-3 bg-[#6366f1] rounded-lg text-[13px] font-semibold text-white hover:bg-[#5558e3] transition-all duration-200"
            style={{
              boxShadow: '0 4px 12px -2px rgba(99,102,241,0.3), inset 0 1px 0 0 rgba(255,255,255,0.18)'
            }}
          >
            Загрузить недостающее
          </button>
          <button className="w-full px-4 py-3 bg-transparent border border-[#2d333e] rounded-lg text-[13px] font-semibold text-[#e6e8ec] hover:border-[#6366f1]/50 hover:bg-[#14171c] transition-all duration-200">
            Создать задание
          </button>
          <button className="w-full text-[12px] font-semibold text-[#6366f1] hover:text-[#8084f4] transition-colors py-2">
            Открыть загрузки по инструменту →
          </button>
        </div>
      </div>
    </div>
  );
}

function DataTypeRow({ type, status, period, updated, action }: { type: string; status: string; period: string; updated: string; action?: string }) {
  const statusColor = status === 'загружено' ? '#22c55e' : '#9ca3af';

  return (
    <div className="flex items-center gap-3 py-2 border-b border-[#1a1e25]">
      <div className="w-[100px] font-['JetBrains_Mono',monospace] text-[11px] text-[#9ba1ad]">
        {type}
      </div>
      <div className="w-[90px] flex items-center gap-1.5">
        <div className="w-1 h-1 rounded-full" style={{ backgroundColor: statusColor }} />
        <span className="text-[11px]" style={{ color: statusColor }}>{status}</span>
      </div>
      <div className="flex-1 font-['JetBrains_Mono',monospace] text-[11px] text-[#9ba1ad]">
        {period}
      </div>
      <div className="w-[70px] font-['JetBrains_Mono',monospace] text-[11px] text-[#6b7280]">
        {updated}
      </div>
      {action && (
        <button className="text-[11px] font-semibold text-[#6366f1] hover:text-[#8084f4] transition-colors whitespace-nowrap ml-2">
          {action}
        </button>
      )}
    </div>
  );
}

function ActionLogItem({ time, text }: { time: string; text: string }) {
  return (
    <div className="flex items-start gap-2">
      <span className="font-['JetBrains_Mono',monospace] text-[11px] text-[#6b7280] whitespace-nowrap">
        {time}
      </span>
      <span className="text-[11px] text-[#6b7280]">·</span>
      <span className="text-[12px] text-[#9ba1ad]">{text}</span>
    </div>
  );
}
