type TopbarProps = {
  liveStatus?: 'live' | 'error' | 'loading' | 'not-configured' | 'loading-data';
  timestamp?: string;
  errorMessage?: string;
  breadcrumb?: string;
};

export function Topbar({ liveStatus = 'live', timestamp = '09:42:18', errorMessage, breadcrumb = 'Dashboard' }: TopbarProps) {
  // Parse breadcrumb if it contains "/"
  const breadcrumbParts = breadcrumb.includes('/') ? breadcrumb.split(' / ').map(s => s.trim()) : null;

  return (
    <div className="sticky top-0 z-10 bg-[#0b0d10]/95 backdrop-blur-sm border-b border-[#1a1e25]">
      <div className="px-8 py-4 flex items-center justify-between">
        {/* Left: Breadcrumb */}
        <div className="flex items-center gap-2.5">
          {breadcrumbParts ? (
            <>
              {breadcrumbParts.map((part, i) => {
                const isLast = i === breadcrumbParts.length - 1;
                return (
                  <div key={i} className="flex items-center gap-2.5">
                    <span
                      className={isLast ? 'text-[13px] font-semibold text-[#e6e8ec]' : 'text-[12px] text-[#6b7280]'}
                    >
                      {part}
                    </span>
                    {!isLast && (
                      <span className="text-[13px] text-[#3e4451]">/</span>
                    )}
                  </div>
                );
              })}
            </>
          ) : (
            <>
              <span className="text-[12px] text-[#6b7280]">DATA OPS</span>
              <span className="text-[13px] text-[#3e4451]">/</span>
              <span className="text-[13px] font-semibold text-[#e6e8ec]">{breadcrumb}</span>
            </>
          )}
        </div>

        {/* Right: LIVE indicator + timestamp + search */}
        <div className="flex items-center gap-[18px]">
          {/* LIVE indicator */}
          {liveStatus === 'live' && (
            <div className="flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-[#22c55e] animate-pulse" />
              <span className="text-[10px] font-semibold tracking-[0.14em] text-[#22c55e]">LIVE</span>
            </div>
          )}

          {liveStatus === 'error' && (
            <div className="flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-[#ef4444]" />
              <span className="text-[10px] font-semibold tracking-[0.14em] text-[#ef4444]">ОШИБКА</span>
            </div>
          )}

          {liveStatus === 'loading' && (
            <div className="flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-[#6b7280] animate-pulse" />
              <span className="text-[10px] font-semibold tracking-[0.14em] text-[#6b7280]">ЗАГРУЗКА</span>
            </div>
          )}

          {liveStatus === 'not-configured' && (
            <div className="flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-[#6b7280]" />
              <span className="text-[10px] font-semibold tracking-[0.14em] text-[#6b7280]">НЕ НАСТРОЕНО</span>
            </div>
          )}

          {liveStatus === 'loading-data' && (
            <div className="flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-[#6b7280] animate-pulse" />
              <span className="text-[10px] font-semibold tracking-[0.14em] text-[#6b7280]">ЗАГРУЗКА ДАННЫХ</span>
            </div>
          )}

          {/* Updated timestamp or error message */}
          {liveStatus === 'live' && (
            <div className="flex items-center gap-2">
              <span className="text-[11px] text-[#a3adb9]">обновлено</span>
              <span className="font-['JetBrains_Mono',monospace] text-[12px] text-[#c2c8d2]">{timestamp}</span>
            </div>
          )}

          {liveStatus === 'error' && errorMessage && (
            <div className="flex items-center gap-2">
              <span className="text-[11px] text-[#ef4444]">{errorMessage}</span>
            </div>
          )}

          {/* Search with ⌘K badge */}
          <div className="flex items-center gap-2 bg-[#14171c] border border-[#2d333e] rounded-lg py-1.5 px-3 hover:border-[#6366f1]/40 transition-all duration-200">
            <svg className="w-3 h-3 text-[#96a1af]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <span className="text-[12px] text-[#96a1af]">Поиск secid, тикера или названия</span>
            <div className="ml-2 bg-[#0b0d10] border border-[#2d333e] rounded px-1.5 py-0.5">
              <span className="font-['JetBrains_Mono',monospace] text-[10px] text-[#96a1af]">⌘K</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
