import { Sidebar } from '../Sidebar';
import { Topbar } from '../Topbar';

export function DashboardLoading() {
  return (
    <div className="min-h-screen bg-[#0b0d10] font-['Inter',sans-serif]">
      <Sidebar activePage="dashboard" />

      <div className="ml-[220px] min-h-screen">
        <Topbar liveStatus="loading-data" />

        <div className="p-8">
          {/* Hero Skeleton */}
          <div
            className="mb-8 bg-gradient-to-b from-[#14171c] to-[#12151a] rounded-xl border border-[#232831] px-6 pt-4 pb-5 animate-pulse"
            style={{
              boxShadow: '0 16px 40px -8px rgba(0,0,0,0.5), 0 2px 4px 0 rgba(0,0,0,0.35), inset 0 1px 0 0 rgba(255,255,255,0.04)'
            }}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="h-4 w-48 bg-[#1a1e25] rounded" />
              <div className="flex items-center gap-2.5">
                <div className="h-10 w-40 bg-[#1a1e25] rounded-lg" />
                <div className="h-10 w-36 bg-[#1a1e25] rounded-lg" />
              </div>
            </div>

            <div className="h-11 w-80 bg-[#1a1e25] rounded mb-3" />
            <div className="space-y-2 mb-4">
              <div className="h-5 w-96 bg-[#1a1e25] rounded" />
              <div className="h-5 w-72 bg-[#1a1e25] rounded" />
              <div className="h-5 w-80 bg-[#1a1e25] rounded" />
            </div>

            <div className="h-px bg-[#1a1e25] mb-3.5" />

            <div className="grid grid-cols-2 gap-5">
              <div>
                <div className="h-3 w-24 bg-[#1a1e25] rounded mb-2.5" />
                <div className="space-y-1.5">
                  <div className="h-4 w-40 bg-[#1a1e25] rounded" />
                  <div className="h-4 w-36 bg-[#1a1e25] rounded" />
                  <div className="h-4 w-32 bg-[#1a1e25] rounded" />
                  <div className="h-4 w-28 bg-[#1a1e25] rounded" />
                </div>
              </div>

              <div>
                <div className="h-3 w-28 bg-[#1a1e25] rounded mb-2.5" />
                <div className="space-y-1.5">
                  <div className="h-4 w-24 bg-[#1a1e25] rounded" />
                  <div className="h-4 w-32 bg-[#1a1e25] rounded" />
                </div>
              </div>
            </div>
          </div>

          {/* Metrics Section Header Skeleton */}
          <div className="flex items-center justify-between mb-4">
            <div className="h-3 w-32 bg-[#1a1e25] rounded animate-pulse" />
          </div>

          {/* Metrics Skeletons */}
          <div className="grid grid-cols-4 gap-4 mb-8">
            {[1, 2, 3, 4].map((i) => (
              <div
                key={i}
                className="bg-gradient-to-b from-[#16191f] via-[#14171c] to-[#12151a] border border-[#232831] rounded-xl p-6 animate-pulse"
                style={{
                  boxShadow: '0 6px 16px -3px rgba(0,0,0,0.4), inset 0 1px 0 0 rgba(255,255,255,0.035)'
                }}
              >
                <div className="h-3 w-24 bg-[#1a1e25] rounded mb-4" />
                <div className="h-12 w-32 bg-[#1a1e25] rounded mb-4" />
                <div className="h-4 w-full bg-[#1a1e25] rounded mb-1.5" />
                <div className="h-4 w-28 bg-[#1a1e25] rounded" />
              </div>
            ))}
          </div>

          {/* Alerts Section Skeleton */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-3">
              <div className="h-3 w-40 bg-[#1a1e25] rounded animate-pulse" />
            </div>
            <div className="flex flex-col gap-2">
              {[1, 2, 3].map((i) => (
                <div
                  key={i}
                  className="flex items-center bg-[#14171c] border border-[#232831] rounded-[10px] py-4 px-[18px] animate-pulse"
                  style={{ boxShadow: '0 3px 8px -2px rgba(0,0,0,0.3)' }}
                >
                  <div className="w-[3px] h-8 rounded-[1.5px] shrink-0 mr-3.5 bg-[#1a1e25]" />
                  <div className="flex-1">
                    <div className="h-4 w-96 bg-[#1a1e25] rounded mb-1" />
                    <div className="h-3 w-80 bg-[#1a1e25] rounded" />
                  </div>
                  <div className="h-4 w-24 bg-[#1a1e25] rounded ml-4" />
                </div>
              ))}
            </div>
          </div>

          {/* Table Section Header Skeleton */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-6">
              <div className="h-3 w-40 bg-[#1a1e25] rounded animate-pulse" />
              <div className="flex items-center gap-2">
                {[1, 2, 3, 4, 5].map((i) => (
                  <div key={i} className="h-3 w-16 bg-[#1a1e25] rounded animate-pulse" />
                ))}
              </div>
            </div>
            <div className="h-3 w-64 bg-[#1a1e25] rounded animate-pulse" />
          </div>

          {/* Table Skeleton */}
          <div
            className="bg-[#14171c] border border-[#232831] rounded-xl overflow-hidden mb-8 animate-pulse"
            style={{
              boxShadow: '0 5px 12px -3px rgba(0,0,0,0.35), inset 0 1px 0 0 rgba(255,255,255,0.03)'
            }}
          >
            {/* Table Header */}
            <div className="bg-[#0b0d10] px-6 py-3.5 flex items-center gap-3 border-b border-[#232831]">
              <div className="h-3 w-[100px] bg-[#1a1e25] rounded" />
              <div className="h-3 w-[70px] bg-[#1a1e25] rounded" />
              <div className="h-3 w-[140px] bg-[#1a1e25] rounded" />
              <div className="h-3 w-[80px] bg-[#1a1e25] rounded" />
              <div className="h-3 w-[110px] bg-[#1a1e25] rounded" />
              <div className="h-3 w-[80px] bg-[#1a1e25] rounded" />
              <div className="h-3 w-[90px] bg-[#1a1e25] rounded" />
              <div className="h-3 w-[50px] bg-[#1a1e25] rounded" />
            </div>

            {/* Table Rows */}
            <div className="bg-[#0b0d10]">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((i) => (
                <div key={i}>
                  <div className="flex items-center gap-3 px-6 py-4">
                    <div className="w-[100px]">
                      <div className="h-4 w-16 bg-[#1a1e25] rounded mb-1" />
                      <div className="h-3 w-20 bg-[#1a1e25] rounded" />
                    </div>
                    <div className="h-4 w-[70px] bg-[#1a1e25] rounded" />
                    <div className="h-4 w-[140px] bg-[#1a1e25] rounded" />
                    <div className="h-4 w-[80px] bg-[#1a1e25] rounded" />
                    <div className="h-6 w-[110px] bg-[#1a1e25] rounded" />
                    <div className="h-4 w-[80px] bg-[#1a1e25] rounded" />
                    <div className="h-4 w-[90px] bg-[#1a1e25] rounded" />
                    <div className="h-4 w-[50px] bg-[#1a1e25] rounded" />
                  </div>
                  {i < 12 && (
                    <div className="h-px bg-[rgba(26,30,37,0.6)]" />
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
