import { Sidebar } from '../Sidebar';
import { Topbar } from '../Topbar';

export function DashboardEmpty() {
  return (
    <div className="min-h-screen bg-[#0b0d10] font-['Inter',sans-serif]">
      <Sidebar activePage="dashboard" />

      <div className="ml-[220px] min-h-screen">
        <Topbar liveStatus="not-configured" />

        <div className="p-8">
          {/* Hero - Setup Empty */}
          <div
            className="mb-8 bg-gradient-to-b from-[#14171c] to-[#12151a] rounded-xl border border-[#232831] px-6 pt-4 pb-5"
            style={{
              boxShadow: '0 16px 40px -8px rgba(0,0,0,0.5), 0 2px 4px 0 rgba(0,0,0,0.35), inset 0 1px 0 0 rgba(255,255,255,0.04)'
            }}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-[5px] h-[5px] rounded-sm bg-[#6b7280]" />
                <span className="text-[10px] font-semibold tracking-[0.18em] uppercase text-[#96a1af]">
                  СИСТЕМА · ГОТОВНОСТЬ 12%
                </span>
              </div>
              <div className="flex items-center gap-2.5">
                <button className="px-[18px] py-[10px] bg-[#14171c] border border-[#2d333e] rounded-lg text-[13px] font-medium text-[#e6e8ec] hover:border-[#6366f1]/50 hover:bg-[#16191f] transition-all duration-200">
                  Открыть настройки
                </button>
                <button
                  className="px-[18px] py-[10px] bg-[#6366f1] rounded-lg text-[13px] font-semibold text-white hover:bg-[#5558e3] hover:shadow-[0_6px_20px_-2px_rgba(99,102,241,0.5)] hover:-translate-y-0.5 transition-all duration-200"
                  style={{
                    boxShadow: '0 4px 12px -2px rgba(99,102,241,0.3), inset 0 1px 0 0 rgba(255,255,255,0.18)'
                  }}
                >
                  Загрузить инструменты
                </button>
              </div>
            </div>

            <h1 className="text-[38px] font-semibold tracking-[-0.02em] text-[#e6e8ec] mb-2.5 leading-tight">
              Система не настроена
            </h1>

            <div className="text-[13px] text-[#9ba1ad] mb-4">
              <p>Начните с загрузки справочника инструментов Московской биржи.</p>
            </div>

            <div className="h-px bg-[#1a1e25] mb-3.5" />

            {/* Status chips */}
            <div className="flex items-center gap-2">
              <span className="text-[11px] text-[#6b7280]">Готовность: 1 из 5</span>
              <div className="flex items-center gap-2">
                <StatusChip status="готово" label="Приложение" />
                <StatusChip status="не настроено" label="Инструменты" />
                <StatusChip status="не настроено" label="Календарь" />
                <StatusChip status="не настроено" label="Обогащение" />
                <StatusChip status="не настроено" label="Тарифы" />
              </div>
            </div>
          </div>

          {/* Empty Metrics */}
          <div className="flex items-center justify-between mb-4">
            <span className="text-[11px] font-semibold tracking-[0.14em] uppercase text-[#96a1af]">
              КЛЮЧЕВЫЕ МЕТРИКИ
            </span>
          </div>

          <div className="grid grid-cols-4 gap-4 mb-8">
            <EmptyMetricCard label="ИНСТРУМЕНТЫ" value="0" hint="Загрузите справочник MOEX" />
            <EmptyMetricCard label="ЗАДАНИЯ СЕГОДНЯ" value="0" hint="Создайте первое задание после загрузки инструментов" />
            <EmptyMetricCard label="СТРОК ЗА 24 Ч" value="0" hint="Данные появятся после выполнения первого задания" />
            <EmptyMetricCard label="КАЧЕСТВО ДАННЫХ" value="—" hint="Метрики доступны после загрузки данных" hintIcon />
          </div>

          {/* Alerts */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-semibold tracking-[0.14em] uppercase text-[#96a1af]">
                  ВНИМАНИЕ
                </span>
                <span className="font-['JetBrains_Mono',monospace] text-[11px] text-[#c2c8d2]">3</span>
              </div>
            </div>
            <div className="flex flex-col gap-2">
              <EmptyAlertCard
                title="Справочник инструментов не загружен"
                sub="Для начала работы необходимо загрузить справочник MOEX"
                action="Загрузить"
              />
              <EmptyAlertCard
                title="Ключ APIM не введён"
                sub="Без ключа автоматическое обогащение карточек недоступно"
                action="Открыть настройки"
              />
              <EmptyAlertCard
                title="Тариф брокера не введён"
                sub="Без тарифа полные издержки рассчитываться не будут"
                action="Добавить тариф"
              />
            </div>
          </div>

          {/* Empty Table State */}
          <div className="flex items-center justify-between mb-4">
            <span className="text-[11px] font-semibold tracking-[0.14em] uppercase text-[#96a1af]">
              ПОСЛЕДНИЕ ЗАГРУЗКИ
            </span>
          </div>

          <div
            className="bg-[#14171c] border border-[#232831] rounded-xl overflow-hidden mb-8 p-16 flex flex-col items-center justify-center text-center"
            style={{
              boxShadow: '0 5px 12px -3px rgba(0,0,0,0.35), inset 0 1px 0 0 rgba(255,255,255,0.03)'
            }}
          >
            <div className="w-12 h-12 rounded-full bg-[#1e1f3a] border border-[#2d333e] flex items-center justify-center mb-4">
              <svg className="w-6 h-6 text-[#6b7280]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4" />
              </svg>
            </div>
            <h3 className="text-[16px] font-semibold text-[#e6e8ec] mb-2">Загрузок пока нет</h3>
            <p className="text-[13px] text-[#96a1af] mb-4 max-w-md">
              Сначала загрузите инструменты, затем создайте первое задание
            </p>
            <button
              className="px-[18px] py-[10px] bg-[#6366f1] rounded-lg text-[13px] font-semibold text-white hover:bg-[#5558e3] transition-all duration-200"
              style={{
                boxShadow: '0 4px 12px -2px rgba(99,102,241,0.3), inset 0 1px 0 0 rgba(255,255,255,0.18)'
              }}
            >
              Загрузить инструменты
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatusChip({ status, label }: { status: 'готово' | 'внимание' | 'не настроено'; label: string }) {
  const configs = {
    'готово': {
      dotBg: '#22c55e',
      textColor: '#9ba1ad',
      border: 'rgba(22,163,74,0.2)',
      bg: 'transparent',
      dotType: 'solid'
    },
    'внимание': {
      dotBg: '#eab308',
      textColor: '#9ba1ad',
      border: 'rgba(202,138,4,0.2)',
      bg: 'transparent',
      dotType: 'solid'
    },
    'не настроено': {
      dotBg: 'transparent',
      textColor: '#6b7280',
      border: '#232831',
      bg: 'transparent',
      dotType: 'ring'
    }
  };

  const config = configs[status];

  return (
    <div
      className="inline-flex items-center gap-1.5 py-1 px-2.5 rounded"
      style={{
        border: `1px solid ${config.border}`,
        backgroundColor: config.bg
      }}
    >
      <div
        className="w-[5px] h-[5px] rounded-sm"
        style={{
          backgroundColor: config.dotType === 'solid' ? config.dotBg : 'transparent',
          border: config.dotType === 'ring' ? '1px solid #6b7280' : 'none'
        }}
      />
      <span className="text-[10px]" style={{ color: config.textColor }}>
        {label}
      </span>
    </div>
  );
}

function EmptyMetricCard({ label, value, hint, hintIcon = false }: { label: string; value: string; hint: string; hintIcon?: boolean }) {
  return (
    <div
      className="bg-gradient-to-b from-[#16191f] via-[#14171c] to-[#12151a] border border-[#232831] rounded-xl p-6"
      style={{
        boxShadow: '0 6px 16px -3px rgba(0,0,0,0.4), inset 0 1px 0 0 rgba(255,255,255,0.035)'
      }}
    >
      <div className="flex items-center gap-2 mb-4">
        <span className="text-[9px] tracking-[0.2em] font-semibold uppercase text-[#96a1af]">
          {label}
        </span>
        {hintIcon && (
          <div className="w-3 h-3 rounded-full bg-[#1e1f3a] border border-[#2d333e] flex items-center justify-center cursor-help">
            <span className="text-[8px] text-[#6b7280]">?</span>
          </div>
        )}
      </div>
      <div className="font-['JetBrains_Mono',monospace] text-[48px] font-medium tracking-[-0.04em] text-[#6b7280] leading-none mb-4 tabular-nums">
        {value}
      </div>
      <div className="text-[11px] text-[#6b7280]">{hint}</div>
    </div>
  );
}

function EmptyAlertCard({ title, sub, action }: { title: string; sub: string; action: string }) {
  return (
    <div
      className="flex items-center bg-[#14171c] border border-[#232831] rounded-[10px] py-4 px-[18px] hover:border-[#6366f1]/30 hover:shadow-lg transition-all duration-200 group cursor-pointer"
      style={{ boxShadow: '0 3px 8px -2px rgba(0,0,0,0.3)' }}
    >
      <div className="w-[3px] h-8 rounded-[1.5px] shrink-0 mr-3.5 bg-[#eab308] transition-all duration-200 group-hover:h-10" />

      <div className="flex-1">
        <div className="text-[13px] font-medium text-[#e6e8ec] mb-1 group-hover:text-white transition-colors duration-200">{title}</div>
        <div className="text-[11px] text-[#a3adb9]">{sub}</div>
      </div>

      <button className="text-[12px] font-semibold text-[#6366f1] hover:text-[#8084f4] hover:translate-x-0.5 transition-all duration-200 shrink-0 ml-4">
        {action} →
      </button>
    </div>
  );
}
