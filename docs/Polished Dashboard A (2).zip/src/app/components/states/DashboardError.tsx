import { Sidebar } from '../Sidebar';
import { Topbar } from '../Topbar';

export function DashboardError() {
  return (
    <div className="min-h-screen bg-[#0b0d10] font-['Inter',sans-serif]">
      <Sidebar activePage="dashboard" />

      <div className="ml-[220px] min-h-screen">
        {/* Topbar с ошибкой */}
        <Topbar
          liveStatus="error"
          errorMessage="ошибка обновления · последние данные 2 мин назад"
        />

        <div className="p-8">
          {/* Hero с warning плашкой */}
          <div
            className="mb-8 bg-gradient-to-b from-[#14171c] to-[#12151a] rounded-xl border border-[#232831] px-6 pt-4 pb-5"
            style={{
              boxShadow: '0 16px 40px -8px rgba(0,0,0,0.5), 0 2px 4px 0 rgba(0,0,0,0.35), inset 0 1px 0 0 rgba(255,255,255,0.04)'
            }}
          >
            {/* Warning плашка */}
            <div className="mb-4 bg-[#713f12] border border-[rgba(202,138,4,0.4)] rounded-lg p-3 flex items-start gap-3">
              <div className="w-1 h-full bg-[#eab308] rounded-full shrink-0" />
              <div className="flex-1">
                <div className="text-[13px] font-medium text-[#eab308] mb-1">
                  Автообновление временно недоступно
                </div>
                <div className="text-[11px] text-[#c2c8d2]">
                  Показаны последние полученные данные.
                </div>
              </div>
              <button
                className="px-4 py-2 bg-[#eab308]/10 hover:bg-[#eab308]/20 border border-[#eab308]/30 rounded-lg text-[12px] font-semibold text-[#eab308] transition-all duration-200 shrink-0"
              >
                Повторить обновление
              </button>
            </div>

            {/* Остальной контент hero как в Normal */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-[5px] h-[5px] rounded-sm bg-[#22c55e]" />
                <span className="text-[10px] font-semibold tracking-[0.18em] uppercase text-[#96a1af]">
                  СИСТЕМА · ГОТОВНОСТЬ 96%
                </span>
              </div>
              <div className="flex items-center gap-2.5">
                <button className="px-[18px] py-[10px] bg-[#14171c] border border-[#2d333e] rounded-lg text-[13px] font-medium text-[#e6e8ec] hover:border-[#6366f1]/50 hover:bg-[#16191f] transition-all duration-200">
                  Открыть операции
                </button>
                <button
                  className="px-[18px] py-[10px] bg-[#6366f1] rounded-lg text-[13px] font-semibold text-white hover:bg-[#5558e3] hover:shadow-[0_6px_20px_-2px_rgba(99,102,241,0.5)] hover:-translate-y-0.5 transition-all duration-200"
                  style={{
                    boxShadow: '0 4px 12px -2px rgba(99,102,241,0.3), inset 0 1px 0 0 rgba(255,255,255,0.18)'
                  }}
                >
                  Создать задание
                </button>
              </div>
            </div>

            <h1 className="text-[38px] font-semibold tracking-[-0.02em] text-[#e6e8ec] mb-2.5 leading-tight">
              Система стабильна
            </h1>

            {/* Hero подзаголовок */}
            <div className="text-[13px] text-[#9ba1ad] mb-4 space-y-1">
              <p>Справочники обновлены сегодня 09:15.</p>
              <p>32 задания сегодня · 2 ошибки.</p>
              <p>Сегодня торговый день (фондовый + срочный).</p>
            </div>

            {/* Separator */}
            <div className="h-px bg-[#1a1e25] mb-3.5" />

            {/* Status chips */}
            <div className="flex items-center gap-2">
              <span className="text-[11px] text-[#6b7280]">Готовность: 4 из 5</span>
              <div className="flex items-center gap-2">
                <StatusChip status="готово" label="Инструменты" />
                <StatusChip status="готово" label="Календарь" />
                <StatusChip status="готово" label="Ограничения" />
                <StatusChip status="внимание" label="Обогащение" />
                <StatusChip status="не настроено" label="Тарифы" />
              </div>
            </div>
          </div>

          {/* Строка обновления справочников */}
          <div className="text-[11px] text-[#6b7280] mb-6">
            Справочники: инструменты сегодня 09:15 · календарь сегодня 09:15 · приостановки вчера
          </div>

          {/* Метрики */}
          <div className="flex items-center justify-between mb-4">
            <span className="text-[11px] font-semibold tracking-[0.14em] uppercase text-[#6b7280]">
              КЛЮЧЕВЫЕ МЕТРИКИ
            </span>
          </div>

          <div className="grid grid-cols-4 gap-4 mb-8">
            <div className="bg-[#14171c] border border-[#232831] rounded-xl p-6"
              style={{ boxShadow: '0 6px 16px -3px rgba(0,0,0,0.4), inset 0 1px 0 0 rgba(255,255,255,0.035)' }}>
              <div className="text-[9px] tracking-[0.2em] font-semibold uppercase text-[#6b7280] mb-3">ИНСТРУМЕНТЫ</div>
              <div className="font-['JetBrains_Mono',monospace] text-[44px] font-medium tracking-[-0.04em] text-[#e6e8ec] leading-none mb-3 tabular-nums">247</div>
              <div className="text-[11px] text-[#9ba1ad]">183 акции · 64 фьючерса</div>
            </div>

            <div className="bg-[#14171c] border border-[#232831] rounded-xl p-6"
              style={{ boxShadow: '0 6px 16px -3px rgba(0,0,0,0.4), inset 0 1px 0 0 rgba(255,255,255,0.035)' }}>
              <div className="text-[9px] tracking-[0.2em] font-semibold uppercase text-[#6b7280] mb-3">КАРТОЧКИ</div>
              <div className="font-['JetBrains_Mono',monospace] text-[44px] font-medium tracking-[-0.04em] text-[#e6e8ec] leading-none mb-3 tabular-nums">186 / 247</div>
              <div className="text-[11px] text-[#9ba1ad]">обогащены MarketStatistics</div>
            </div>

            <div className="bg-[#14171c] border border-[#232831] rounded-xl p-6"
              style={{ boxShadow: '0 6px 16px -3px rgba(0,0,0,0.4), inset 0 1px 0 0 rgba(255,255,255,0.035)' }}>
              <div className="text-[9px] tracking-[0.2em] font-semibold uppercase text-[#6b7280] mb-3">ЗАДАНИЯ СЕГОДНЯ</div>
              <div className="font-['JetBrains_Mono',monospace] text-[44px] font-medium tracking-[-0.04em] text-[#e6e8ec] leading-none mb-3 tabular-nums">32</div>
              <div className="text-[11px] text-[#9ba1ad]">27 успешно · 5 требуют внимания</div>
            </div>

            <div className="bg-[#14171c] border border-[#232831] rounded-xl p-6"
              style={{ boxShadow: '0 6px 16px -3px rgba(0,0,0,0.4), inset 0 1px 0 0 rgba(255,255,255,0.035)' }}>
              <div className="text-[9px] tracking-[0.2em] font-semibold uppercase text-[#6b7280] mb-3">СТРОКИ ЗА 24 Ч</div>
              <div className="font-['JetBrains_Mono',monospace] text-[44px] font-medium tracking-[-0.04em] text-[#e6e8ec] leading-none mb-3 tabular-nums">45 832</div>
              <div className="text-[11px] text-[#9ba1ad]">file · 4 типа данных</div>
            </div>
          </div>

          {/* Critical Alerts */}
          <div className="mb-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-semibold tracking-[0.14em] uppercase text-[#ef4444]">
                  КРИТИЧНО
                </span>
                <span className="font-['JetBrains_Mono',monospace] text-[11px] text-[#c2c8d2]">1</span>
              </div>
            </div>
            <div className="flex flex-col gap-2">
              <div
                className="flex items-center bg-[#14171c] border border-[#232831] rounded-[10px] py-4 px-[18px]"
                style={{ boxShadow: '0 3px 8px -2px rgba(0,0,0,0.3)' }}
              >
                <div className="w-[3px] h-8 rounded-[1.5px] shrink-0 mr-3.5 bg-[#ef4444]" />
                <div className="flex-1">
                  <div className="text-[13px] font-medium text-[#e6e8ec] mb-1">
                    GMKN candles — задание упало, диапазон 20.12—31.12 не загружен
                  </div>
                  <div className="text-[11px] text-[#a3adb9]">
                    HTTP 429, 3 попытки исчерпаны. Ограничений по инструменту не найдено.
                  </div>
                </div>
                <button className="text-[12px] font-semibold text-[#ef4444] shrink-0 ml-4">
                  Повторить →
                </button>
              </div>
            </div>
          </div>

          {/* Warning Alerts */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-semibold tracking-[0.14em] uppercase text-[#96a1af]">
                  ВНИМАНИЕ
                </span>
                <span className="font-['JetBrains_Mono',monospace] text-[11px] text-[#c2c8d2]">3</span>
              </div>
              <a href="#" className="text-[11px] font-medium text-[#6366f1]">Все предупреждения →</a>
            </div>
            <div className="flex flex-col gap-2">
              <div
                className="flex items-center bg-[#14171c] border border-[#232831] rounded-[10px] py-4 px-[18px]"
                style={{ boxShadow: '0 3px 8px -2px rgba(0,0,0,0.3)' }}
              >
                <div className="w-[3px] h-8 rounded-[1.5px] shrink-0 mr-3.5 bg-[#eab308]" />
                <div className="flex-1">
                  <div className="text-[13px] font-medium text-[#e6e8ec] mb-1">
                    61 инструмент без обогащения MarketStatistics
                  </div>
                  <div className="text-[11px] text-[#a3adb9]">
                    Карточки доступны, но часть полей MarketStatistics ещё не заполнена.
                  </div>
                </div>
                <button className="text-[12px] font-semibold text-[#6366f1] shrink-0 ml-4">
                  Открыть инструменты →
                </button>
              </div>

              <div
                className="flex items-center bg-[#14171c] border border-[#232831] rounded-[10px] py-4 px-[18px]"
                style={{ boxShadow: '0 3px 8px -2px rgba(0,0,0,0.3)' }}
              >
                <div className="w-[3px] h-8 rounded-[1.5px] shrink-0 mr-3.5 bg-[#eab308]" />
                <div className="flex-1">
                  <div className="text-[13px] font-medium text-[#e6e8ec] mb-1">
                    3 активные приостановки торгов
                  </div>
                  <div className="text-[11px] text-[#a3adb9]">
                    Перед созданием заданий проверьте ограничения по инструментам.
                  </div>
                </div>
                <button className="text-[12px] font-semibold text-[#6366f1] shrink-0 ml-4">
                  Открыть ограничения →
                </button>
              </div>

              <div
                className="flex items-center bg-[#14171c] border border-[#232831] rounded-[10px] py-4 px-[18px]"
                style={{ boxShadow: '0 3px 8px -2px rgba(0,0,0,0.3)' }}
              >
                <div className="w-[3px] h-8 rounded-[1.5px] shrink-0 mr-3.5 bg-[#eab308]" />
                <div className="flex-1">
                  <div className="text-[13px] font-medium text-[#e6e8ec] mb-1">
                    SiM6 — экспирация через 12 дней
                  </div>
                  <div className="text-[11px] text-[#a3adb9]">
                    Ближний контракт Si. Проверьте таблицу ролла и переключение.
                  </div>
                </div>
                <button className="text-[12px] font-semibold text-[#6366f1] shrink-0 ml-4">
                  Открыть фьючерсы →
                </button>
              </div>
            </div>
          </div>

          {/* Table Section Header with stale data indicator */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-semibold tracking-[0.14em] uppercase text-[#96a1af]">
                  ПОСЛЕДНИЕ ЗАГРУЗКИ
                </span>
                <span className="font-['JetBrains_Mono',monospace] text-[11px] text-[#c2c8d2]">12</span>
              </div>

              {/* Status Filter Bar - disabled */}
              <div className="flex items-center gap-2 opacity-60">
                <span className="text-[11px] text-[#96a1af]">Все 12</span>
                <span className="text-[#3e4451]">·</span>
                <span className="text-[11px] text-[#96a1af]">успешно 8</span>
                <span className="text-[#3e4451]">·</span>
                <span className="text-[11px] text-[#96a1af]">выполняется 1</span>
                <span className="text-[#3e4451]">·</span>
                <span className="text-[11px] text-[#96a1af]">внимание 1</span>
                <span className="text-[#3e4451]">·</span>
                <span className="text-[11px] text-[#96a1af]">ошибка 1</span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <div className="w-[5px] h-[5px] rounded-sm bg-[#eab308]" />
              <span className="text-[11px] text-[#a3adb9]">последнее успешное обновление 2 мин назад · автообновление недоступно</span>
            </div>
          </div>

          {/* Table Card */}
          <div
            className="bg-[#14171c] border border-[#232831] rounded-xl overflow-hidden mb-8"
            style={{
              boxShadow: '0 5px 12px -3px rgba(0,0,0,0.35), inset 0 1px 0 0 rgba(255,255,255,0.03)'
            }}
          >
            {/* Table Header */}
            <div className="bg-[#0b0d10] px-6 py-3.5 flex items-center gap-3 border-b border-[#232831]">
              <div className="w-[100px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#96a1af]">ИНСТРУМЕНТ</div>
              <div className="w-[70px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#96a1af]">ТИП</div>
              <div className="w-[140px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#96a1af]">ПЕРИОД</div>
              <div className="w-[80px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#96a1af] text-right">СТРОК</div>
              <div className="w-[110px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#96a1af]">СТАТУС</div>
              <div className="w-[80px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#96a1af]">ВРЕМЯ</div>
              <div className="w-[90px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#96a1af]">ДЕЙСТВИЕ</div>
              <div className="w-[50px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#96a1af] text-center">ОТСЛЕЖ.</div>
            </div>

            {/* Table Rows */}
            <div className="bg-[#0b0d10]">
              {[
                { secid: 'SBER', type: 'candles', subtype: 'акция', period: '01.12 — 31.12', rows: '22 341', status: 'success', time: '09:42:18', watched: true },
                { secid: 'GAZP', type: 'tradestats', subtype: 'акция', period: '01.12 — 31.12', rows: '18 902', status: 'success', time: '09:41:55', watched: false },
                { secid: 'LKOH', type: 'obstats', subtype: 'акция', period: '15.12 — 31.12', rows: '8 210', status: 'running', time: '09:40:11', watched: true },
                { secid: 'SiM6', type: 'futoi', subtype: 'фьюч.', period: '01.12 — 31.12', rows: '1 440', status: 'success', time: '09:39:02', watched: true },
                { secid: 'GMKN', type: 'candles', subtype: 'акция', period: '20.12 — 31.12', rows: '3 180', status: 'error', time: '09:38:44', watched: false },
                { secid: 'ROSN', type: 'orderstats', subtype: 'акция', period: '01.12 — 31.12', rows: '25 118', status: 'success', time: '09:37:21', watched: false },
                { secid: 'MGNT', type: 'candles', subtype: 'акция', period: '01.12 — 15.12', rows: '11 402', status: 'warning', time: '09:36:09', watched: true, selected: true },
                { secid: 'SiH7', type: 'candles', subtype: 'фьюч.', period: '01.12 — 31.12', rows: '14 220', status: 'success', time: '09:35:47', watched: true },
                { secid: 'VTBR', type: 'candles', subtype: 'акция', period: '01.12 — 31.12', rows: '19 004', status: 'success', time: '09:34:12', watched: false },
                { secid: 'NVTK', type: 'obstats', subtype: 'акция', period: '10.12 — 31.12', rows: '7 821', status: 'success', time: '09:33:28', watched: false },
                { secid: 'TATN', type: 'candles', subtype: 'акция', period: '01.12 — 31.12', rows: '20 156', status: 'success', time: '09:32:05', watched: false },
                { secid: 'ALRS', type: 'tradestats', subtype: 'акция', period: '01.12 — 31.12', rows: '12 447', status: 'success', time: '09:30:43', watched: false },
              ].map((item, i) => {
                const isSelected = item.selected;
                const borderColor = isSelected ? 'rgba(26,30,37,0.3)' : 'rgba(26,30,37,0.6)';

                return (
                  <div key={i}>
                    <div
                      className={`flex items-center gap-3 px-6 py-4 relative ${
                        isSelected ? 'bg-[#0f1114]' : 'bg-transparent'
                      }`}
                      style={{ paddingLeft: isSelected ? 'calc(1.5rem + 2px)' : '1.5rem' }}
                    >
                      {isSelected && <div className="absolute left-0 top-0 bottom-0 w-0.5 bg-[#6366f1]" />}

                      <div className="w-[100px]">
                        <div className="font-semibold text-[13px] text-[#e6e8ec] leading-none mb-1">{item.secid}</div>
                        <div className="font-['JetBrains_Mono',monospace] text-[10px] text-[#a3adb9]">{item.type}</div>
                      </div>
                      <div className="w-[70px] text-[12px] text-[#c2c8d2]">{item.subtype}</div>
                      <div className="w-[140px] font-['JetBrains_Mono',monospace] text-[11px] text-[#c2c8d2]">{item.period}</div>
                      <div className="w-[80px] font-['JetBrains_Mono',monospace] text-[13px] font-medium tracking-[-0.02em] text-[#e6e8ec] text-right tabular-nums">
                        {item.rows}
                      </div>
                      <div className="w-[110px]">
                        <StatusBadge status={item.status} />
                      </div>
                      <div className="w-[80px] font-['JetBrains_Mono',monospace] text-[11px] text-[#a3adb9]">{item.time}</div>
                      <div className="w-[90px]">
                        <ActionButton status={item.status} />
                      </div>
                      <div className="w-[50px] flex justify-center">
                        <Toggle checked={item.watched} />
                      </div>
                    </div>
                    {i < 11 && <div className="h-px" style={{ backgroundColor: borderColor }} />}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Footer */}
          <div className="flex items-end justify-end">
            <button className="px-[18px] py-[10px] bg-[#14171c] border border-[#2d333e] rounded-lg text-[13px] font-medium text-[#e6e8ec] hover:border-[#6366f1]/50 hover:bg-[#16191f] transition-all duration-200">
              Обновить справочники
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatusChip({ status, label }: { status: 'готово' | 'внимание' | 'не настроено'; label: string }) {
  const configs = {
    'готово': {
      dotBg: '#22c55e',
      textColor: '#9ba1ad',
      border: 'rgba(22,163,74,0.2)',
      bg: 'transparent',
      dotType: 'solid'
    },
    'внимание': {
      dotBg: '#eab308',
      textColor: '#9ba1ad',
      border: 'rgba(202,138,4,0.2)',
      bg: 'transparent',
      dotType: 'solid'
    },
    'не настроено': {
      dotBg: 'transparent',
      textColor: '#6b7280',
      border: '#232831',
      bg: 'transparent',
      dotType: 'ring'
    }
  };

  const config = configs[status];

  return (
    <div
      className="inline-flex items-center gap-1.5 py-1 px-2.5 rounded"
      style={{
        border: `1px solid ${config.border}`,
        backgroundColor: config.bg
      }}
    >
      <div
        className="w-[5px] h-[5px] rounded-sm"
        style={{
          backgroundColor: config.dotType === 'solid' ? config.dotBg : 'transparent',
          border: config.dotType === 'ring' ? '1px solid #6b7280' : 'none'
        }}
      />
      <span className="text-[10px]" style={{ color: config.textColor }}>
        {label}
      </span>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const configs: Record<string, { bg: string; border: string; dot: string; text: string; label: string }> = {
    success: { bg: '#14532d', border: 'rgba(22,163,74,0.4)', dot: '#22c55e', text: '#22c55e', label: 'успешно' },
    warning: { bg: '#713f12', border: 'rgba(202,138,4,0.4)', dot: '#eab308', text: '#eab308', label: 'внимание' },
    error: { bg: '#7f1d1d', border: 'rgba(220,38,38,0.4)', dot: '#ef4444', text: '#ef4444', label: 'ошибка' },
    running: { bg: '#0c4a6e', border: 'rgba(14,165,233,0.4)', dot: '#38bdf8', text: '#38bdf8', label: 'выполняется' },
  };

  const config = configs[status] || configs.success;

  return (
    <div
      className="inline-flex items-center gap-1.5 py-[3px] pl-[7px] pr-[9px] rounded"
      style={{
        backgroundColor: config.bg,
        border: `1px solid ${config.border}`
      }}
    >
      <div className="w-[5px] h-[5px] rounded-sm" style={{ backgroundColor: config.dot }} />
      <span className="text-[11px] font-medium" style={{ color: config.text }}>{config.label}</span>
    </div>
  );
}

function ActionButton({ status }: { status: string }) {
  const actionMap: Record<string, { text: string; color: string }> = {
    success: { text: 'Открыть', color: '#6366f1' },
    running: { text: 'Детали', color: '#6366f1' },
    error: { text: 'Повторить', color: '#ef4444' },
    warning: { text: 'Проверить', color: '#eab308' },
  };

  const action = actionMap[status] || actionMap.success;

  return (
    <button
      className="text-[12px] font-medium"
      style={{ color: action.color }}
    >
      {action.text}
    </button>
  );
}

function Toggle({ checked }: { checked: boolean }) {
  return (
    <div
      className={`w-7 h-4 rounded-lg relative ${
        checked ? 'bg-[#4a4eb3]' : 'bg-[#2d333e]'
      }`}
    >
      <div
        className={`absolute top-0.5 w-3 h-3 rounded-md ${
          checked ? 'left-[14px] bg-white' : 'left-0.5 bg-[#96a1af]'
        }`}
      />
    </div>
  );
}
