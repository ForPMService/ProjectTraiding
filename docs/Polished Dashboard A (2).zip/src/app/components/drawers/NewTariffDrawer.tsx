import { useEffect, useState } from 'react';
import { X, Check } from 'lucide-react';
import { T, Mono, PrimaryBtn, SecondaryBtn } from '../shell/AppShell';

interface NewTariffDrawerProps { onClose: () => void }

function DField({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <div>
      <label style={{ display: 'block', fontSize: 10, fontWeight: 600, letterSpacing: '0.14em', textTransform: 'uppercase', color: T.txtDisabled, marginBottom: 6 }}>
        {label}{required && <span style={{ color: '#EF4444', marginLeft: 4 }}>*</span>}
      </label>
      {children}
    </div>
  );
}

const inputStyle: React.CSSProperties = {
  height: 34, width: '100%', background: T.bgApp, border: `1px solid ${T.border}`, borderRadius: 8,
  padding: '0 12px', fontSize: 12, color: T.txtPrimary, outline: 'none',
  fontFamily: "'Inter', sans-serif", boxSizing: 'border-box',
};

export function NewTariffDrawer({ onClose }: NewTariffDrawerProps) {
  const [form, setForm] = useState({ broker: '', name: '', market: 'stock', commType: '', value: '', currency: '', minComm: '', threshold: '', dateFrom: '', dateTo: '', comment: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [serverError] = useState('');
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, [onClose]);

  const set = (k: string, v: string) => setForm(p => ({ ...p, [k]: v }));

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.broker)    e.broker   = 'Обязательное поле';
    if (!form.name)      e.name     = 'Обязательное поле';
    if (!form.commType)  e.commType = 'Выберите тип';
    if (!form.value)     e.value    = 'Обязательное поле';
    if (!form.dateFrom)  e.dateFrom = 'Обязательное поле';
    if (form.dateTo && form.dateFrom && form.dateTo < form.dateFrom)
      e.dateTo = 'Дата окончания раньше даты начала';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  return (
    <>
      <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.6)', zIndex: 40 }} />
      <div style={{
        position: 'absolute', right: 0, top: 0, bottom: 0, width: 480, zIndex: 50,
        background: T.bgElevated, borderLeft: `1px solid ${T.subtle}`,
        borderRadius: '16px 0 0 16px', boxShadow: T.shadowModal,
        display: 'flex', flexDirection: 'column',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '18px 24px', borderBottom: `1px solid ${T.hairline}`, flexShrink: 0 }}>
          <span style={{ fontSize: 15, fontWeight: 600, color: T.txtPrimary }}>Новый тариф</span>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: T.txtDisabled, display: 'flex' }}>
            <X size={16} />
          </button>
        </div>

        {success ? (
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 16 }}>
            <div style={{ width: 48, height: 48, borderRadius: '50%', background: 'rgba(34,197,94,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Check size={22} color="#22C55E" />
            </div>
            <div style={{ fontSize: 16, fontWeight: 600, color: T.txtPrimary }}>Тариф добавлен</div>
          </div>
        ) : (
          <>
            <div style={{ flex: 1, overflowY: 'auto', padding: '20px 24px', display: 'flex', flexDirection: 'column', gap: 16 }}>
              <DField label="Брокер" required>
                <input value={form.broker} onChange={e => set('broker', e.target.value)} placeholder="Название брокера" style={inputStyle} />
                {errors.broker && <div style={{ fontSize: 11, color: '#EF4444', marginTop: 4 }}>{errors.broker}</div>}
              </DField>
              <DField label="Название тарифа" required>
                <input value={form.name} onChange={e => set('name', e.target.value)} placeholder="Название тарифа" style={inputStyle} />
                {errors.name && <div style={{ fontSize: 11, color: '#EF4444', marginTop: 4 }}>{errors.name}</div>}
              </DField>
              <DField label="Рынок" required>
                <div style={{ display: 'flex', gap: 4 }}>
                  {[{ k: 'stock', l: 'Фондовый' }, { k: 'futures', l: 'Срочный' }].map(m => (
                    <button key={m.k} onClick={() => set('market', m.k)} style={{
                      padding: '6px 14px', borderRadius: 8, fontSize: 12, fontWeight: 500, cursor: 'pointer', fontFamily: "'Inter', sans-serif",
                      background: form.market === m.k ? T.accentSub : T.bgApp,
                      color: form.market === m.k ? T.accent : T.txtSecondary,
                      border: `1px solid ${form.market === m.k ? T.accent : T.border}`,
                    }}>{m.l}</button>
                  ))}
                </div>
              </DField>
              <DField label="Тип комиссии" required>
                <select value={form.commType} onChange={e => set('commType', e.target.value)}
                  style={{ ...inputStyle, cursor: 'pointer' }}>
                  <option value="">Выберите тип...</option>
                  <option value="percent_of_turnover">percent_of_turnover — процент от оборота</option>
                  <option value="fixed_per_contract">fixed_per_contract — фикс. за контракт</option>
                  <option value="fixed_per_trade">fixed_per_trade — фикс. за сделку</option>
                  <option value="monthly">monthly — ежемесячная</option>
                  <option value="depository">depository — депозитарная</option>
                </select>
                {errors.commType && <div style={{ fontSize: 11, color: '#EF4444', marginTop: 4 }}>{errors.commType}</div>}
              </DField>
              <DField label="Значение комиссии" required>
                <input value={form.value} onChange={e => set('value', e.target.value)} placeholder="Напр. 0.0413 или 2.50" style={{ ...inputStyle, fontFamily: 'JetBrains Mono, monospace' }} />
                {errors.value && <div style={{ fontSize: 11, color: '#EF4444', marginTop: 4 }}>{errors.value}</div>}
              </DField>
              <DField label="Валюта">
                <input value={form.currency} onChange={e => set('currency', e.target.value)} placeholder="по умолчанию RUB" style={inputStyle} />
              </DField>
              <DField label="Мин. комиссия">
                <input value={form.minComm} onChange={e => set('minComm', e.target.value)} placeholder="Необязательно" style={{ ...inputStyle, fontFamily: 'JetBrains Mono, monospace' }} />
              </DField>
              <DField label="Порог оборота">
                <input value={form.threshold} onChange={e => set('threshold', e.target.value)} placeholder="Необязательно" style={{ ...inputStyle, fontFamily: 'JetBrains Mono, monospace' }} />
              </DField>
              <DField label="Действует с" required>
                <input type="date" value={form.dateFrom} onChange={e => set('dateFrom', e.target.value)} style={inputStyle} />
                {errors.dateFrom && <div style={{ fontSize: 11, color: '#EF4444', marginTop: 4 }}>{errors.dateFrom}</div>}
              </DField>
              <DField label="Действует по">
                <input type="date" value={form.dateTo} onChange={e => set('dateTo', e.target.value)} style={inputStyle} />
                {errors.dateTo && <div style={{ fontSize: 11, color: '#EF4444', marginTop: 4 }}>{errors.dateTo}</div>}
              </DField>
              <DField label="Комментарий">
                <textarea value={form.comment} onChange={e => set('comment', e.target.value)} placeholder="Необязательно" rows={3}
                  style={{ width: '100%', background: T.bgApp, border: `1px solid ${T.border}`, borderRadius: 8, padding: '8px 12px', fontSize: 12, color: T.txtPrimary, outline: 'none', resize: 'vertical', fontFamily: "'Inter', sans-serif", boxSizing: 'border-box' }} />
              </DField>
              {serverError && <div style={{ fontSize: 12, color: '#EF4444', padding: '8px 0' }}>{serverError}</div>}
            </div>
            <div style={{ padding: '16px 24px', borderTop: `1px solid ${T.hairline}`, display: 'flex', gap: 10, flexShrink: 0 }}>
              <PrimaryBtn onClick={() => { if (validate()) setSuccess(true); }}>Сохранить тариф</PrimaryBtn>
              <SecondaryBtn onClick={onClose}>Отмена</SecondaryBtn>
            </div>
          </>
        )}
      </div>
    </>
  );
}
