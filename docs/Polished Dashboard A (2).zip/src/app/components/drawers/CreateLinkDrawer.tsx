import { useEffect, useState } from 'react';
import { X, Check, Search, Lock } from 'lucide-react';
import { T, Mono, PrimaryBtn, SecondaryBtn } from '../shell/AppShell';
import { INSTRUMENTS_LIST } from '../loads/LoadsScreen';

interface CreateLinkDrawerProps { instrumentCode: string; onClose: () => void }

function DField({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <div>
      <label style={{ display: 'block', fontSize: 10, fontWeight: 600, letterSpacing: '0.14em', textTransform: 'uppercase', color: T.txtDisabled, marginBottom: 6 }}>
        {label}{required && <span style={{ color: '#EF4444', marginLeft: 4 }}>*</span>}
      </label>
      {children}
    </div>
  );
}

export function CreateLinkDrawer({ instrumentCode, onClose }: CreateLinkDrawerProps) {
  const [search, setSearch] = useState('');
  const [form, setForm] = useState({ targetCode: '', targetUnderlying: '', linkType: '', confidence: 'manual', comment: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [serverError] = useState('');
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, [onClose]);

  const set = (k: string, v: string) => setForm(p => ({ ...p, [k]: v }));

  const searchResults = search
    ? INSTRUMENTS_LIST.filter(i => i.secid !== instrumentCode && i.secid.toLowerCase().includes(search.toLowerCase())).slice(0, 5)
    : [];

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.targetCode && !form.targetUnderlying) e.target = 'Нужен хотя бы один из двух: целевой инструмент или базовый актив';
    if (!form.linkType) e.linkType = 'Выберите тип связи';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const inputStyle: React.CSSProperties = {
    height: 34, width: '100%', background: T.bgApp, border: `1px solid ${T.border}`, borderRadius: 8,
    padding: '0 12px', fontSize: 12, color: T.txtPrimary, outline: 'none',
    fontFamily: "'Inter', sans-serif", boxSizing: 'border-box',
  };

  return (
    <>
      <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.6)', zIndex: 40 }} />
      <div style={{
        position: 'absolute', right: 0, top: 0, bottom: 0, width: 480, zIndex: 50,
        background: T.bgElevated, borderLeft: `1px solid ${T.subtle}`,
        borderRadius: '16px 0 0 16px', boxShadow: T.shadowModal,
        display: 'flex', flexDirection: 'column',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '18px 24px', borderBottom: `1px solid ${T.hairline}`, flexShrink: 0 }}>
          <span style={{ fontSize: 15, fontWeight: 600, color: T.txtPrimary }}>Создать ручную связь</span>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: T.txtDisabled, display: 'flex' }}>
            <X size={16} />
          </button>
        </div>

        {success ? (
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 16, textAlign: 'center' }}>
            <div style={{ width: 48, height: 48, borderRadius: '50%', background: 'rgba(34,197,94,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Check size={22} color="#22C55E" />
            </div>
            <div style={{ fontSize: 16, fontWeight: 600, color: T.txtPrimary }}>Связь сохранена</div>
          </div>
        ) : (
          <>
            <div style={{ flex: 1, overflowY: 'auto', padding: '20px 24px', display: 'flex', flexDirection: 'column', gap: 18 }}>
              {/* Source — locked */}
              <DField label="Исходный инструмент">
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 12px', background: T.bgApp, border: `1px solid ${T.border}`, borderRadius: 8 }}>
                  <Lock size={12} color={T.txtDisabled} />
                  <Mono size={13} bold>{instrumentCode}</Mono>
                  <span style={{ fontSize: 10, color: T.txtDisabled, marginLeft: 2 }}>locked</span>
                </div>
              </DField>

              {/* Target instrument search */}
              <DField label="Целевой инструмент">
                <div style={{ position: 'relative' }}>
                  <Search size={13} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: T.txtDisabled }} />
                  <input value={search} onChange={e => { setSearch(e.target.value); if (!e.target.value) set('targetCode', ''); }}
                    placeholder="Поиск по коду..."
                    style={{ ...inputStyle, paddingLeft: 30 }} />
                  {searchResults.length > 0 && (
                    <div style={{ position: 'absolute', top: '100%', left: 0, right: 0, marginTop: 4, background: T.bgElevated, border: `1px solid ${T.subtle}`, borderRadius: 8, overflow: 'hidden', zIndex: 10, boxShadow: T.shadowModal }}>
                      {searchResults.map(i => (
                        <button key={i.secid}
                          onClick={() => { set('targetCode', i.secid); setSearch(i.secid); }}
                          style={{ display: 'flex', alignItems: 'center', gap: 10, width: '100%', padding: '10px 14px', background: 'none', border: 'none', borderBottom: `1px solid ${T.hairline}`, cursor: 'pointer', fontFamily: "'Inter', sans-serif" }}
                          onMouseEnter={e => (e.currentTarget as HTMLElement).style.background = T.bgHover}
                          onMouseLeave={e => (e.currentTarget as HTMLElement).style.background = 'none'}
                        >
                          <Mono size={13} bold>{i.secid}</Mono>
                          <span style={{ fontSize: 12, color: T.txtSecondary }}>{i.name}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </DField>

              {/* Target underlying */}
              <DField label="Целевой базовый актив">
                <input value={form.targetUnderlying} onChange={e => set('targetUnderlying', e.target.value)} placeholder="Напр. Si"
                  style={{ ...inputStyle, fontFamily: 'JetBrains Mono, monospace' }} />
                <div style={{ fontSize: 11, color: T.txtDisabled, marginTop: 5 }}>нужен хотя бы один из двух: целевой инструмент или базовый актив</div>
              </DField>

              {errors.target && <div style={{ fontSize: 12, color: '#EF4444', marginTop: -8 }}>{errors.target}</div>}

              {/* Link type */}
              <DField label="Тип связи" required>
                <select value={form.linkType} onChange={e => set('linkType', e.target.value)}
                  style={{ ...inputStyle, cursor: 'pointer' }}>
                  <option value="">Выберите тип...</option>
                  <option value="future_underlying">фьючерс на базовый актив</option>
                  <option value="same_underlying">общий базовый актив</option>
                  <option value="manual_related">связь вручную</option>
                </select>
                {errors.linkType && <div style={{ fontSize: 11, color: '#EF4444', marginTop: 4 }}>{errors.linkType}</div>}
              </DField>

              {/* Confidence */}
              <DField label="Достоверность">
                <div style={{ display: 'flex', gap: 4 }}>
                  {['auto', 'manual'].map(c => (
                    <button key={c} onClick={() => set('confidence', c)} style={{
                      padding: '6px 16px', borderRadius: 8, fontSize: 12, fontWeight: 500, cursor: 'pointer', fontFamily: "'Inter', sans-serif",
                      background: form.confidence === c ? T.accentSub : T.bgApp,
                      color: form.confidence === c ? T.accent : T.txtSecondary,
                      border: `1px solid ${form.confidence === c ? T.accent : T.border}`,
                    }}>{c}</button>
                  ))}
                </div>
              </DField>

              {/* Comment */}
              <DField label="Комментарий">
                <textarea value={form.comment} onChange={e => set('comment', e.target.value)} placeholder="Необязательно" rows={3}
                  style={{ width: '100%', background: T.bgApp, border: `1px solid ${T.border}`, borderRadius: 8, padding: '8px 12px', fontSize: 12, color: T.txtPrimary, outline: 'none', resize: 'vertical', fontFamily: "'Inter', sans-serif", boxSizing: 'border-box' }} />
              </DField>

              {serverError && <div style={{ fontSize: 12, color: '#EF4444' }}>{serverError}</div>}
            </div>
            <div style={{ padding: '16px 24px', borderTop: `1px solid ${T.hairline}`, display: 'flex', gap: 10, flexShrink: 0 }}>
              <PrimaryBtn onClick={() => { if (validate()) setSuccess(true); }}>Сохранить связь</PrimaryBtn>
              <SecondaryBtn onClick={onClose}>Отмена</SecondaryBtn>
            </div>
          </>
        )}
      </div>
    </>
  );
}
