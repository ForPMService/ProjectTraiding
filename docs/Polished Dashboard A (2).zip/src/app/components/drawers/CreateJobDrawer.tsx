import { useState, useEffect } from 'react';
import { X, Check, Search, Database, AlertTriangle } from 'lucide-react';
import { T, Mono, PrimaryBtn, SecondaryBtn } from '../shell/AppShell';
import { INSTRUMENTS_LIST } from '../loads/LoadsScreen';

interface CreateJobDrawerProps {
  instrumentCode?: string;
  onClose: () => void;
}

const DATA_TYPES_STOCK   = ['candles', 'tradestats', 'orderstats', 'obstats'];
const DATA_TYPES_FUTURES = ['candles', 'futoi', 'tradestats', 'obstats'];
const DT_DESC: Record<string, string> = {
  candles:    'свечи',
  tradestats: 'статистика сделок',
  orderstats: 'статистика заявок',
  obstats:    'статистика стакана',
  futoi:      'открытые позиции',
};

function DrawerField({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <div>
      <label style={{ display: 'block', fontSize: 10, fontWeight: 600, letterSpacing: '0.14em', textTransform: 'uppercase', color: T.txtDisabled, marginBottom: 6 }}>
        {label}{required && <span style={{ color: '#EF4444', marginLeft: 4 }}>*</span>}
      </label>
      {children}
    </div>
  );
}

function FieldErr({ msg }: { msg?: string }) {
  if (!msg) return null;
  return <div style={{ fontSize: 11, color: '#EF4444', marginTop: 4 }}>{msg}</div>;
}

function DInput({ value, onChange, placeholder, mono }: { value: string; onChange: (v: string) => void; placeholder?: string; mono?: boolean }) {
  return (
    <input value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
      style={{ height: 34, width: '100%', background: T.bgApp, border: `1px solid ${T.border}`, borderRadius: 8, padding: '0 12px', fontSize: 12, color: T.txtPrimary, outline: 'none', fontFamily: mono ? 'JetBrains Mono, monospace' : "'Inter', sans-serif", boxSizing: 'border-box' }}
    />
  );
}

export function CreateJobDrawer({ instrumentCode, onClose }: CreateJobDrawerProps) {
  const fixedInst = instrumentCode ? INSTRUMENTS_LIST.find(i => i.secid === instrumentCode) : null;
  const baseType = fixedInst?.type ?? 'stock';

  const [searchVal, setSearchVal] = useState(instrumentCode ?? '');
  const [selectedSecid, setSelectedSecid] = useState(instrumentCode ?? '');
  const [showDropdown, setShowDropdown] = useState(false);
  const [dataTypes, setDataTypes] = useState<Record<string, boolean>>({
    candles: true, tradestats: baseType === 'stock', orderstats: baseType === 'stock', obstats: baseType === 'stock', futoi: baseType === 'future',
  });
  const [interval, setInterval] = useState('1m');
  const [period, setPeriod] = useState('last-month');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [success, setSuccess] = useState(false);

  const resolvedInst = selectedSecid ? INSTRUMENTS_LIST.find(i => i.secid === selectedSecid) : fixedInst;
  const resolvedType = resolvedInst?.type ?? baseType;
  const dtOptions = resolvedType === 'stock' ? DATA_TYPES_STOCK : DATA_TYPES_FUTURES;
  const selectedTypes = Object.entries(dataTypes).filter(([, v]) => v).map(([k]) => k);

  const searchResults = searchVal && !instrumentCode
    ? INSTRUMENTS_LIST.filter(i => i.secid.toLowerCase().includes(searchVal.toLowerCase()) || i.name.toLowerCase().includes(searchVal.toLowerCase())).slice(0, 6)
    : [];

  const validate = () => {
    const e: Record<string, string> = {};
    if (!instrumentCode && !selectedSecid) e.inst = 'Выберите инструмент';
    if (selectedTypes.length === 0) e.types = 'Выберите хотя бы один тип данных';
    if (period === 'custom') {
      if (!dateFrom) e.dateFrom = 'Укажите дату начала';
      if (!dateTo) e.dateTo = 'Укажите дату окончания';
      if (dateFrom && dateTo && dateTo < dateFrom) e.dateTo = 'Дата окончания раньше даты начала';
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const summaryCode = instrumentCode ?? selectedSecid;
  const summaryTypes = selectedTypes.join(', ');
  const summaryPeriod = period === 'last-month' ? 'последний месяц' : period === 'last-quarter' ? 'последний квартал' : `${dateFrom}–${dateTo}`;

  useEffect(() => {
    const handler = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, [onClose]);

  return (
    <>
      <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.6)', zIndex: 40 }} />
      <div style={{
        position: 'absolute', right: 0, top: 0, bottom: 0, width: 480, zIndex: 50,
        background: T.bgElevated, borderLeft: `1px solid ${T.subtle}`,
        borderRadius: '16px 0 0 16px', boxShadow: T.shadowModal,
        display: 'flex', flexDirection: 'column',
      }}>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '18px 24px', borderBottom: `1px solid ${T.hairline}`, flexShrink: 0 }}>
          <span style={{ fontSize: 15, fontWeight: 600, color: T.txtPrimary }}>Создать задание на загрузку</span>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: T.txtDisabled, display: 'flex' }}>
            <X size={16} />
          </button>
        </div>

        {success ? (
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 16, textAlign: 'center' }}>
            <div style={{ width: 48, height: 48, borderRadius: '50%', background: 'rgba(34,197,94,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Check size={22} color="#22C55E" />
            </div>
            <div>
              <div style={{ fontSize: 16, fontWeight: 600, color: T.txtPrimary, marginBottom: 8 }}>Задание создано</div>
              <button style={{ fontSize: 13, color: T.accent, background: 'none', border: 'none', cursor: 'pointer' }}>
                Открыть в разделе Загрузки
              </button>
            </div>
          </div>
        ) : (
          <>
            <div style={{ flex: 1, overflowY: 'auto', padding: '20px 24px', display: 'flex', flexDirection: 'column', gap: 18 }}>
              {/* Instrument */}
              <DrawerField label="Инструмент" required>
                {instrumentCode ? (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 12px', background: T.bgApp, border: `1px solid ${T.border}`, borderRadius: 8 }}>
                    <Mono size={13} bold>{instrumentCode}</Mono>
                    <span style={{ fontSize: 11, color: T.txtSecondary, padding: '2px 6px', background: T.bgSurface, borderRadius: 4, border: `1px solid ${T.hairline}` }}>{baseType === 'stock' ? 'акция' : 'фьючерс'}</span>
                    {fixedInst?.assetCode && <Mono size={11} color={T.txtMuted}>{fixedInst.assetCode}</Mono>}
                    <button style={{ marginLeft: 'auto', fontSize: 12, color: T.accent, background: 'none', border: 'none', cursor: 'pointer' }}>сменить</button>
                  </div>
                ) : (
                  <div style={{ position: 'relative' }}>
                    <Search size={13} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: T.txtDisabled }} />
                    <input
                      value={searchVal}
                      onChange={e => { setSearchVal(e.target.value); setShowDropdown(true); if (!e.target.value) setSelectedSecid(''); }}
                      onFocus={() => setShowDropdown(true)}
                      placeholder="Поиск по коду или названию..."
                      style={{ height: 34, width: '100%', background: T.bgApp, border: `1px solid ${T.border}`, borderRadius: 8, padding: '0 12px 0 32px', fontSize: 12, color: T.txtPrimary, outline: 'none', boxSizing: 'border-box' }}
                    />
                    {showDropdown && searchResults.length > 0 && (
                      <div style={{ position: 'absolute', top: '100%', left: 0, right: 0, marginTop: 4, background: T.bgElevated, border: `1px solid ${T.subtle}`, borderRadius: 8, overflow: 'hidden', zIndex: 10, boxShadow: T.shadowModal }}>
                        {searchResults.map(i => (
                          <button key={i.secid}
                            onClick={() => { setSelectedSecid(i.secid); setSearchVal(i.secid); setShowDropdown(false); }}
                            style={{ display: 'flex', alignItems: 'center', gap: 10, width: '100%', padding: '10px 14px', background: 'none', border: 'none', borderBottom: `1px solid ${T.hairline}`, cursor: 'pointer', fontFamily: "'Inter', sans-serif', textAlign: 'left" }}
                            onMouseEnter={e => (e.currentTarget as HTMLElement).style.background = T.bgHover}
                            onMouseLeave={e => (e.currentTarget as HTMLElement).style.background = 'none'}
                          >
                            <Mono size={13} bold>{i.secid}</Mono>
                            <span style={{ fontSize: 12, color: T.txtSecondary }}>{i.name}</span>
                            <span style={{ marginLeft: 'auto', fontSize: 10, color: T.txtMuted, padding: '2px 6px', border: `1px solid ${T.hairline}`, borderRadius: 4 }}>{i.type}</span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                )}
                <FieldErr msg={errors.inst} />
              </DrawerField>

              {/* Data types */}
              <DrawerField label="Типы данных" required>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  {dtOptions.map(dt => {
                    const defaultOn = resolvedType === 'stock'
                      ? ['candles','tradestats','orderstats','obstats'].includes(dt)
                      : ['candles','futoi'].includes(dt);
                    return (
                      <label key={dt} style={{ display: 'flex', alignItems: 'flex-start', gap: 10, cursor: 'pointer' }}>
                        <input type="checkbox"
                          checked={!!dataTypes[dt]}
                          onChange={e => setDataTypes(p => ({ ...p, [dt]: e.target.checked }))}
                          style={{ marginTop: 2, accentColor: T.accent, width: 14, height: 14, flexShrink: 0 }}
                        />
                        <span>
                          <Mono size={12}>{dt}</Mono>
                          <span style={{ fontSize: 12, color: T.txtSecondary }}> — {DT_DESC[dt]}</span>
                          {dt === 'futoi' && resolvedType === 'future' && (
                            <div style={{ fontSize: 10, color: '#EAB308', marginTop: 2 }}>
                              загружается по asset_code, не по secid{resolvedInst?.assetCode ? `; для ${resolvedInst.secid} будет использован ${resolvedInst.assetCode}` : ''}
                            </div>
                          )}
                        </span>
                      </label>
                    );
                  })}
                </div>
                <FieldErr msg={errors.types} />
              </DrawerField>

              {/* Candle interval */}
              {dataTypes.candles && (
                <DrawerField label="Интервал свечей">
                  <div style={{ display: 'flex', gap: 4 }}>
                    {['1m','5m','1h','4h','1d'].map(iv => (
                      <button key={iv} onClick={() => setInterval(iv)} style={{
                        padding: '5px 12px', borderRadius: 8, fontSize: 12, fontFamily: 'JetBrains Mono, monospace', cursor: 'pointer',
                        background: interval === iv ? T.accentSub : T.bgApp,
                        color: interval === iv ? T.accent : T.txtSecondary,
                        border: `1px solid ${interval === iv ? T.accent : T.border}`,
                      }}>{iv}</button>
                    ))}
                  </div>
                </DrawerField>
              )}

              {/* Period */}
              <DrawerField label="Период">
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  {[
                    { k: 'last-month',   l: 'Последний месяц' },
                    { k: 'last-quarter', l: 'Последний квартал' },
                    { k: 'custom',       l: 'Произвольный' },
                  ].map(opt => (
                    <label key={opt.k} style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer' }}>
                      <input type="radio" checked={period === opt.k} onChange={() => setPeriod(opt.k)} style={{ accentColor: T.accent }} />
                      <span style={{ fontSize: 13, color: T.txtPrimary }}>{opt.l}</span>
                    </label>
                  ))}
                  {period === 'custom' && (
                    <div style={{ display: 'flex', gap: 8, paddingLeft: 22 }}>
                      <div>
                        <input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)}
                          style={{ height: 32, background: T.bgApp, border: `1px solid ${T.border}`, borderRadius: 8, padding: '0 10px', fontSize: 11, color: T.txtPrimary, outline: 'none' }} />
                        <FieldErr msg={errors.dateFrom} />
                      </div>
                      <div>
                        <input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)}
                          style={{ height: 32, background: T.bgApp, border: `1px solid ${T.border}`, borderRadius: 8, padding: '0 10px', fontSize: 11, color: T.txtPrimary, outline: 'none' }} />
                        <FieldErr msg={errors.dateTo} />
                      </div>
                    </div>
                  )}
                </div>
              </DrawerField>

              {/* Storage */}
              <DrawerField label="Хранилище">
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 12px', background: T.bgApp, border: `1px solid ${T.border}`, borderRadius: 8 }}>
                  <Database size={13} color={T.txtDisabled} />
                  <Mono size={12} color={T.txtSecondary}>ClickHouse</Mono>
                  <span style={{ fontSize: 11, color: T.txtDisabled, marginLeft: 4 }}>— рыночные ряды пишутся в ClickHouse</span>
                </div>
              </DrawerField>

              {/* Summary */}
              {summaryCode && selectedTypes.length > 0 && (
                <div style={{ padding: '12px 14px', background: T.bgApp, border: `1px solid ${T.hairline}`, borderRadius: 8 }}>
                  <div style={{ fontSize: 12, color: T.txtPrimary, marginBottom: 6 }}>
                    Будет создано: <Mono size={12}>{summaryCode}</Mono> · <Mono size={12}>{summaryTypes}{dataTypes.candles ? ` ${interval}` : ''}</Mono> · {summaryPeriod}
                  </div>
                  <div style={{ display: 'flex', alignItems: 'flex-start', gap: 6 }}>
                    <AlertTriangle size={12} color={T.txtDisabled} style={{ marginTop: 1, flexShrink: 0 }} />
                    <span style={{ fontSize: 11, color: T.txtDisabled, lineHeight: 1.5 }}>
                      Загрузка идёт постранично, может занять время. Запросы к MOEX платные и ограничены по частоте
                    </span>
                  </div>
                </div>
              )}
            </div>

            {/* Footer */}
            <div style={{ padding: '16px 24px', borderTop: `1px solid ${T.hairline}`, display: 'flex', gap: 10, flexShrink: 0 }}>
              <PrimaryBtn onClick={() => { if (validate()) setSuccess(true); }}>Создать задание</PrimaryBtn>
              <SecondaryBtn onClick={onClose}>Отмена</SecondaryBtn>
            </div>
          </>
        )}
      </div>
    </>
  );
}
