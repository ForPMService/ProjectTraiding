import { useEffect, useState } from 'react';
import { X, Check, Search, ChevronRight } from 'lucide-react';
import { T, Mono, PrimaryBtn, SecondaryBtn } from '../shell/AppShell';
import { INSTRUMENTS_LIST } from '../loads/LoadsScreen';

interface BulkLoadDrawerProps { onClose: () => void }

const ALL_DT = ['candles', 'tradestats', 'obstats', 'orderstats', 'futoi', 'hi2'];
const DEFAULT_FOR_TYPE = (type: string, dt: string): boolean => {
  if (type === 'stock')  return ['candles','tradestats','obstats','orderstats'].includes(dt);
  if (type === 'future') return ['candles','futoi','tradestats','obstats'].includes(dt) && dt !== 'orderstats';
  return false;
};

export function BulkLoadDrawer({ onClose }: BulkLoadDrawerProps) {
  const [step, setStep] = useState<1 | 2>(1);
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [matrix, setMatrix] = useState<Record<string, Record<string, boolean>>>({});
  const [period, setPeriod] = useState('last-month');
  const [interval, setInterval] = useState('1m');
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, [onClose]);

  const filtered = INSTRUMENTS_LIST.filter(i =>
    !search || i.secid.toLowerCase().includes(search.toLowerCase()) || i.name.toLowerCase().includes(search.toLowerCase())
  );

  const toggleInst = (secid: string) => {
    setSelected(prev => {
      const next = new Set(prev);
      if (next.has(secid)) next.delete(secid);
      else next.add(secid);
      return next;
    });
  };

  const goStep2 = () => {
    const inst = INSTRUMENTS_LIST.filter(i => selected.has(i.secid));
    const m: Record<string, Record<string, boolean>> = {};
    inst.forEach(i => {
      m[i.secid] = {};
      ALL_DT.forEach(dt => { m[i.secid][dt] = DEFAULT_FOR_TYPE(i.type, dt); });
    });
    setMatrix(m);
    setStep(2);
  };

  const toggleCell = (secid: string, dt: string) => {
    setMatrix(prev => ({ ...prev, [secid]: { ...prev[secid], [dt]: !prev[secid][dt] } }));
  };

  const jobCount = Object.entries(matrix).reduce((acc, [, dts]) => acc + Object.values(dts).filter(Boolean).length, 0);
  const selectedInsts = INSTRUMENTS_LIST.filter(i => selected.has(i.secid));

  return (
    <>
      <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.6)', zIndex: 40 }} />
      <div style={{
        position: 'absolute', right: 0, top: 0, bottom: 0, width: 480, zIndex: 50,
        background: T.bgElevated, borderLeft: `1px solid ${T.subtle}`,
        borderRadius: '16px 0 0 16px', boxShadow: T.shadowModal,
        display: 'flex', flexDirection: 'column',
      }}>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '18px 24px', borderBottom: `1px solid ${T.hairline}`, flexShrink: 0 }}>
          <div>
            <span style={{ fontSize: 15, fontWeight: 600, color: T.txtPrimary }}>Массовая загрузка</span>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 4 }}>
              <span style={{ fontSize: 11, color: step === 1 ? T.accent : T.txtDisabled, fontWeight: step === 1 ? 600 : 400 }}>1 · Инструменты</span>
              <ChevronRight size={12} color={T.txtDisabled} />
              <span style={{ fontSize: 11, color: step === 2 ? T.accent : T.txtDisabled, fontWeight: step === 2 ? 600 : 400 }}>2 · Параметры</span>
            </div>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: T.txtDisabled, display: 'flex' }}>
            <X size={16} />
          </button>
        </div>

        {success ? (
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 16, textAlign: 'center' }}>
            <div style={{ width: 48, height: 48, borderRadius: '50%', background: 'rgba(34,197,94,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Check size={22} color="#22C55E" />
            </div>
            <div style={{ fontSize: 16, fontWeight: 600, color: T.txtPrimary }}>Создано {jobCount} заданий</div>
          </div>
        ) : step === 1 ? (
          <>
            <div style={{ flex: 1, overflowY: 'auto', padding: '16px 24px' }}>
              <div style={{ position: 'relative', marginBottom: 12 }}>
                <Search size={13} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: T.txtDisabled }} />
                <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Поиск..."
                  style={{ height: 32, width: '100%', background: T.bgApp, border: `1px solid ${T.border}`, borderRadius: 8, padding: '0 12px 0 30px', fontSize: 12, color: T.txtPrimary, outline: 'none', boxSizing: 'border-box' }} />
              </div>
              {/* Type filter tabs */}
              <div style={{ display: 'flex', gap: 4, marginBottom: 12 }}>
                {['Все', 'Акции', 'Фьючерсы'].map(f => (
                  <button key={f} style={{ fontSize: 11, padding: '3px 10px', borderRadius: 6, background: T.bgApp, color: T.txtSecondary, border: `1px solid ${T.border}`, cursor: 'pointer' }}>{f}</button>
                ))}
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                {filtered.map(inst => {
                  const on = selected.has(inst.secid);
                  return (
                    <div key={inst.secid}
                      onClick={() => toggleInst(inst.secid)}
                      style={{
                        display: 'flex', alignItems: 'center', gap: 10, padding: '8px 10px', borderRadius: 8,
                        background: on ? T.accentSub : 'transparent', cursor: 'pointer',
                        border: `1px solid ${on ? T.accent : 'transparent'}`,
                      }}
                      onMouseEnter={e => { if (!on) (e.currentTarget as HTMLElement).style.background = T.bgHover; }}
                      onMouseLeave={e => { if (!on) (e.currentTarget as HTMLElement).style.background = 'transparent'; }}
                    >
                      <div style={{ width: 16, height: 16, borderRadius: 4, border: `2px solid ${on ? T.accent : T.border}`, background: on ? T.accent : 'transparent', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                        {on && <Check size={10} color="#fff" />}
                      </div>
                      <Mono size={13} color={on ? T.accent : T.txtPrimary} bold>{inst.secid}</Mono>
                      <span style={{ fontSize: 12, color: T.txtSecondary }}>{inst.name}</span>
                      <span style={{ marginLeft: 'auto', fontSize: 10, color: T.txtMuted }}>{inst.type}</span>
                    </div>
                  );
                })}
              </div>
            </div>
            <div style={{ padding: '16px 24px', borderTop: `1px solid ${T.hairline}`, display: 'flex', gap: 10, flexShrink: 0 }}>
              <PrimaryBtn onClick={goStep2} small>Далее · {selected.size} инстр. <ChevronRight size={13} /></PrimaryBtn>
              <SecondaryBtn onClick={onClose} small>Отмена</SecondaryBtn>
            </div>
          </>
        ) : (
          <>
            <div style={{ flex: 1, overflowY: 'auto', padding: '16px 24px' }}>
              {/* Matrix */}
              <div style={{ overflowX: 'auto', marginBottom: 16 }}>
                <table style={{ borderCollapse: 'collapse', width: '100%' }}>
                  <thead>
                    <tr>
                      <th style={{ padding: '6px 8px', fontSize: 9, textAlign: 'left', color: T.txtMuted, textTransform: 'uppercase', letterSpacing: '0.12em', whiteSpace: 'nowrap' }}>Инструмент</th>
                      {ALL_DT.map(dt => (
                        <th key={dt} style={{ padding: '6px 8px', fontSize: 9, textAlign: 'center', color: T.txtMuted, textTransform: 'uppercase', letterSpacing: '0.1em', fontFamily: 'JetBrains Mono, monospace' }}>{dt}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {selectedInsts.map(inst => (
                      <tr key={inst.secid} style={{ borderBottom: `1px solid rgba(26,30,37,0.5)` }}>
                        <td style={{ padding: '6px 8px' }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                            <Mono size={12} bold>{inst.secid}</Mono>
                            <span style={{ fontSize: 10, color: T.txtMuted }}>{inst.type}</span>
                          </div>
                        </td>
                        {ALL_DT.map(dt => {
                          const on = matrix[inst.secid]?.[dt] ?? false;
                          return (
                            <td key={dt} style={{ padding: '6px 8px', textAlign: 'center' }}>
                              <input type="checkbox" checked={on} onChange={() => toggleCell(inst.secid, dt)}
                                style={{ accentColor: T.accent, width: 14, height: 14 }} />
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {/* Period & interval */}
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                {['last-month','last-quarter','custom'].map(p => (
                  <button key={p} onClick={() => setPeriod(p)} style={{
                    fontSize: 12, padding: '5px 12px', borderRadius: 8, cursor: 'pointer', fontFamily: "'Inter', sans-serif",
                    background: period === p ? T.accentSub : T.bgApp, color: period === p ? T.accent : T.txtSecondary,
                    border: `1px solid ${period === p ? T.accent : T.border}`,
                  }}>{p === 'last-month' ? 'Посл. месяц' : p === 'last-quarter' ? 'Посл. квартал' : 'Произвольный'}</button>
                ))}
              </div>
            </div>
            <div style={{ padding: '16px 24px', borderTop: `1px solid ${T.hairline}`, display: 'flex', gap: 10, flexShrink: 0 }}>
              <PrimaryBtn onClick={() => setSuccess(true)}>Создать {jobCount} задан{jobCount === 1 ? 'ие' : 'ий'}</PrimaryBtn>
              <SecondaryBtn onClick={() => setStep(1)} small>← Назад</SecondaryBtn>
            </div>
          </>
        )}
      </div>
    </>
  );
}
