import { useState, useMemo } from 'react';
import { Plus, Users, Filter, RotateCcw, AlertTriangle, ChevronDown, X } from 'lucide-react';
import { AppShell, NavPage, T, Mono, StatusBadge, PrimaryBtn, SecondaryBtn, SectionLabel, EmptyState } from '../shell/AppShell';

// ── Demo data ──────────────────────────────────────────────────────────
export const INSTRUMENTS_LIST = [
  { secid: 'SBER', name: 'Сбербанк', type: 'stock', assetCode: null },
  { secid: 'GAZP', name: 'Газпром', type: 'stock', assetCode: null },
  { secid: 'LKOH', name: 'Лукойл', type: 'stock', assetCode: null },
  { secid: 'GMKN', name: 'Норильский никель', type: 'stock', assetCode: null },
  { secid: 'VTBR', name: 'ВТБ', type: 'stock', assetCode: null },
  { secid: 'SiM6', name: 'Фьючерс USD/RUB', type: 'future', assetCode: 'Si' },
  { secid: 'SiU6', name: 'Фьючерс USD/RUB', type: 'future', assetCode: 'Si' },
  { secid: 'BRN6', name: 'Фьючерс нефть Brent', type: 'future', assetCode: 'BR' },
];

const JOBS_DATA = [
  { id: 'J8F2A1', secid: 'SBER', dataTypes: ['candles'], interval: '1m',  period: '01.05–31.05', rows: 44640,   status: 'success',  reason: '—',                                   time: '10:24' },
  { id: 'J7E3B2', secid: 'SiM6', dataTypes: ['candles','futoi'], interval: '1m', period: '01.05–31.05', rows: null, status: 'running',  reason: 'Загрузка страницы 3/47',               time: '11:02' },
  { id: 'J6D4C3', secid: 'GMKN', dataTypes: ['candles'], interval: '1m',  period: '01.05–31.05', rows: null,    status: 'error',    reason: 'HTTP 429 Too Many Requests',            time: '07:45' },
  { id: 'J5C5D4', secid: 'GAZP', dataTypes: ['tradestats'], interval: '—', period: '01.05–31.05', rows: 12800,  status: 'warning',  reason: '3 дня без данных после 2026-05-17',     time: '08:33' },
  { id: 'J4B6E5', secid: 'LKOH', dataTypes: ['candles'], interval: '1h',  period: '01.04–30.04', rows: 2520,   status: 'success',  reason: '—',                                   time: '09:15' },
  { id: 'J3A7F6', secid: 'VTBR', dataTypes: ['candles','orderstats'], interval: '5m', period: '01.05–31.05', rows: null, status: 'pending', reason: 'В очереди',                    time: '11:30' },
];

const RANGES_DATA = [
  { secid: 'SBER', dataType: 'candles',    interval: '1m', period: '2026-01-01–2026-05-31', rows: 214200, storage: 'ClickHouse', status: 'ok',      updated: '2026-06-01 10:24' },
  { secid: 'SBER', dataType: 'tradestats', interval: '—',  period: '2026-01-01–2026-05-31', rows: 156400, storage: 'ClickHouse', status: 'ok',      updated: '2026-06-01 10:24' },
  { secid: 'SiM6', dataType: 'candles',    interval: '1m', period: '2026-03-01–2026-05-31', rows: 65520,  storage: 'ClickHouse', status: 'partial', updated: '2026-05-15 09:00' },
  { secid: 'SiM6', dataType: 'futoi',      interval: '—',  period: '2026-03-01–2026-05-31', rows: 44100,  storage: 'ClickHouse', status: 'ok',      updated: '2026-05-31 14:22' },
  { secid: 'GMKN', dataType: 'candles',    interval: '1m', period: '2026-05-01–2026-05-15', rows: 10080,  storage: 'ClickHouse', status: 'stale',   updated: '2026-05-15 08:00' },
];

const DATA_TYPES = ['candles', 'tradestats', 'obstats', 'orderstats', 'futoi', 'hi2'];
const STATUS_FILTERS = [
  { key: 'all',     label: 'Все' },
  { key: 'pending', label: 'Ожидают' },
  { key: 'running', label: 'Выполняются' },
  { key: 'success', label: 'Успешно' },
  { key: 'warning', label: 'Внимание' },
  { key: 'error',   label: 'Ошибка' },
];

const STATUS_COLOR: Record<string, string> = {
  success: '#22C55E', warning: '#EAB308', error: '#EF4444', running: '#38BDF8', pending: '#94A3B8', all: T.txtSecondary,
};

function fmtRows(n: number | null): string {
  if (n === null) return '—';
  return n.toLocaleString('ru-RU');
}

// Contextual action per status
function RowAction({ status }: { status: string }) {
  const map: Record<string, { label: string; color: string }> = {
    success: { label: 'Открыть',   color: T.accent },
    running: { label: 'Детали',    color: T.accent },
    pending: { label: 'Детали',    color: T.accent },
    error:   { label: 'Повторить', color: '#EF4444' },
    warning: { label: 'Проверить', color: '#EAB308' },
  };
  const a = map[status] ?? { label: 'Открыть', color: T.accent };
  return (
    <button style={{ fontSize: 12, fontWeight: 500, color: a.color, background: 'none', border: 'none', cursor: 'pointer', padding: 0, fontFamily: "'Inter', sans-serif" }}>
      {a.label}
    </button>
  );
}

// ── LOADS JOBS ─────────────────────────────────────────────────────────
function JobsTab({ onCreateJob, onBulkLoad }: { onCreateJob: () => void; onBulkLoad: () => void }) {
  const [statusFilter, setStatusFilter] = useState('all');
  const [secidSearch, setSecidSearch] = useState('');
  const [selectedTypes, setSelectedTypes] = useState<string[]>([]);
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [intervalFilter, setIntervalFilter] = useState('');
  const [hoveredRow, setHoveredRow] = useState<string | null>(null);

  const counts = useMemo(() => ({
    all: JOBS_DATA.length,
    pending: JOBS_DATA.filter(j => j.status === 'pending').length,
    running: JOBS_DATA.filter(j => j.status === 'running').length,
    success: JOBS_DATA.filter(j => j.status === 'success').length,
    warning: JOBS_DATA.filter(j => j.status === 'warning').length,
    error:   JOBS_DATA.filter(j => j.status === 'error').length,
  }), []);

  const hasFilters = secidSearch || selectedTypes.length > 0 || dateFrom || dateTo || intervalFilter;

  const filtered = useMemo(() => {
    let items = JOBS_DATA;
    if (statusFilter !== 'all') items = items.filter(j => j.status === statusFilter);
    if (secidSearch) items = items.filter(j => j.secid.toLowerCase().includes(secidSearch.toLowerCase()));
    if (selectedTypes.length > 0) items = items.filter(j => selectedTypes.some(t => j.dataTypes.includes(t)));
    return items;
  }, [statusFilter, secidSearch, selectedTypes]);

  const toggleType = (t: string) =>
    setSelectedTypes(prev => prev.includes(t) ? prev.filter(x => x !== t) : [...prev, t]);

  const reset = () => { setSecidSearch(''); setSelectedTypes([]); setDateFrom(''); setDateTo(''); setIntervalFilter(''); };

  const showInterval = selectedTypes.includes('candles') || selectedTypes.length === 0;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
      {/* Status filter chips */}
      <div style={{ padding: '14px 20px 0', display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
        {STATUS_FILTERS.map(f => {
          const count = counts[f.key as keyof typeof counts] ?? 0;
          const active = statusFilter === f.key;
          const dotColor = STATUS_COLOR[f.key] ?? T.txtSecondary;
          return (
            <button
              key={f.key}
              onClick={() => setStatusFilter(f.key)}
              style={{
                display: 'inline-flex', alignItems: 'center', gap: 6,
                padding: '5px 10px', borderRadius: 6, fontSize: 12, fontWeight: 500, cursor: 'pointer',
                background: active ? T.accentSub : T.bgSurface,
                color: active ? T.accent : T.txtSecondary,
                border: `1px solid ${active ? T.accent : T.subtle}`,
                fontFamily: "'Inter', sans-serif",
                transition: 'all 0.12s',
              }}
            >
              {f.key !== 'all' && (
                <span style={{ width: 6, height: 6, borderRadius: '50%', background: active ? T.accent : dotColor, flexShrink: 0 }} />
              )}
              {f.label}
              <span style={{
                fontSize: 10, fontWeight: 600, padding: '1px 5px', borderRadius: 4,
                background: active ? T.accent : T.bgApp, color: active ? '#fff' : T.txtMuted,
                fontFamily: "'JetBrains Mono', monospace",
              }}>{count}</span>
            </button>
          );
        })}
        <div style={{ flex: 1 }} />
        <SecondaryBtn onClick={onBulkLoad} small><Users size={13} />Массовая загрузка</SecondaryBtn>
        <PrimaryBtn onClick={onCreateJob} small><Plus size={13} />Создать задание</PrimaryBtn>
      </div>

      {/* Filter bar */}
      <div style={{ padding: '10px 20px', display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap', borderBottom: `1px solid ${T.hairline}` }}>
        {/* Instrument search */}
        <div style={{ position: 'relative' }}>
          <input
            value={secidSearch}
            onChange={e => setSecidSearch(e.target.value)}
            placeholder="Инструмент..."
            style={{ height: 30, width: 150, background: T.bgApp, border: `1px solid ${T.border}`, borderRadius: 6, padding: '0 10px', fontSize: 12, color: T.txtPrimary, outline: 'none', fontFamily: 'JetBrains Mono, monospace' }}
          />
        </div>
        {/* Data type chips */}
        <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
          {DATA_TYPES.map(t => {
            const on = selectedTypes.includes(t);
            return (
              <button key={t} onClick={() => toggleType(t)} style={{
                fontSize: 11, padding: '3px 8px', borderRadius: 4, cursor: 'pointer', fontFamily: 'JetBrains Mono, monospace',
                background: on ? T.accentSub : 'transparent', color: on ? T.accent : T.txtMuted,
                border: `1px solid ${on ? T.accent : T.subtle}`,
              }}>{t}</button>
            );
          })}
        </div>
        {/* Date range */}
        <input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)}
          style={{ height: 30, background: T.bgApp, border: `1px solid ${T.border}`, borderRadius: 6, padding: '0 8px', fontSize: 11, color: T.txtSecondary, outline: 'none' }} />
        <span style={{ fontSize: 12, color: T.txtDisabled }}>—</span>
        <input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)}
          style={{ height: 30, background: T.bgApp, border: `1px solid ${T.border}`, borderRadius: 6, padding: '0 8px', fontSize: 11, color: T.txtSecondary, outline: 'none' }} />
        {/* Interval — only if candles selected */}
        {showInterval && (
          <div style={{ display: 'flex', gap: 3 }}>
            {['1m','5m','1h','4h','1d'].map(iv => (
              <button key={iv} onClick={() => setIntervalFilter(intervalFilter === iv ? '' : iv)} style={{
                fontSize: 11, padding: '3px 7px', borderRadius: 4, cursor: 'pointer', fontFamily: 'JetBrains Mono, monospace',
                background: intervalFilter === iv ? T.accentSub : 'transparent',
                color: intervalFilter === iv ? T.accent : T.txtMuted,
                border: `1px solid ${intervalFilter === iv ? T.accent : T.subtle}`,
              }}>{iv}</button>
            ))}
          </div>
        )}
        {hasFilters && (
          <button onClick={reset} style={{ display: 'inline-flex', alignItems: 'center', gap: 4, fontSize: 12, color: T.txtMuted, background: 'none', border: 'none', cursor: 'pointer', fontFamily: "'Inter', sans-serif" }}>
            <RotateCcw size={12} />Сбросить фильтры
          </button>
        )}
      </div>

      {/* Table area */}
      <div style={{ flex: 1, overflowY: 'auto' }}>
        {filtered.length === 0 ? (
          hasFilters ? (
            <EmptyState
              icon={Filter}
              title="Нет заданий по этим фильтрам"
              description="Попробуйте изменить параметры поиска"
              action={<button onClick={reset} style={{ fontSize: 13, color: T.accent, background: 'none', border: 'none', cursor: 'pointer' }}>Сбросить фильтры</button>}
            />
          ) : (
            <EmptyState
              icon={Plus}
              title="Заданий пока нет"
              description="Выберите инструмент и создайте первое задание на загрузку рыночных данных."
              action={<PrimaryBtn onClick={onCreateJob}><Plus size={14} />Создать задание</PrimaryBtn>}
            />
          )
        ) : (
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ position: 'sticky', top: 0, background: T.bgApp, zIndex: 2 }}>
                {['ID', 'ИНСТРУМЕНТ', 'ИНТЕРВАЛ', 'ПЕРИОД', 'СТРОК', 'СТАТУС', 'ПРИЧИНА', 'ВРЕМЯ', 'ДЕЙСТВИЕ'].map((h, i) => (
                  <th key={h} style={{
                    padding: '10px 16px', textAlign: i >= 4 && i <= 4 ? 'right' : 'left',
                    fontSize: 9, fontWeight: 600, letterSpacing: '0.16em', textTransform: 'uppercase',
                    color: T.txtMuted, borderBottom: `1px solid ${T.hairline}`, whiteSpace: 'nowrap',
                  }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(job => {
                const hov = hoveredRow === job.id;
                return (
                  <tr key={job.id}
                    onMouseEnter={() => setHoveredRow(job.id)}
                    onMouseLeave={() => setHoveredRow(null)}
                    style={{
                      background: hov ? T.bgHover : 'transparent',
                      borderBottom: `1px solid rgba(26,30,37,0.6)`,
                      transition: 'background 0.1s',
                    }}
                  >
                    <td style={{ padding: '11px 16px' }}>
                      <Mono size={12} color={T.txtMuted}>{job.id}</Mono>
                    </td>
                    <td style={{ padding: '11px 16px' }}>
                      <div style={{ fontSize: 13, fontWeight: 600, color: T.txtPrimary, fontFamily: 'JetBrains Mono, monospace' }}>{job.secid}</div>
                      <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: T.txtSecondary, marginTop: 2 }}>
                        {job.dataTypes.join(', ')}
                      </div>
                    </td>
                    <td style={{ padding: '11px 16px' }}>
                      <Mono size={12} color={job.interval === '—' ? T.txtDisabled : T.txtSecondary}>{job.interval}</Mono>
                    </td>
                    <td style={{ padding: '11px 16px' }}>
                      <Mono size={12} color={T.txtSecondary}>{job.period}</Mono>
                    </td>
                    <td style={{ padding: '11px 16px', textAlign: 'right' }}>
                      <Mono size={12} color={job.rows === null ? T.txtDisabled : T.txtPrimary} bold>{fmtRows(job.rows)}</Mono>
                    </td>
                    <td style={{ padding: '11px 16px' }}>
                      <StatusBadge status={job.status} />
                    </td>
                    <td style={{ padding: '11px 16px', maxWidth: 200 }}>
                      <span style={{ fontSize: 12, color: T.txtSecondary, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', display: 'block' }}>
                        {job.reason}
                      </span>
                    </td>
                    <td style={{ padding: '11px 16px' }}>
                      <Mono size={12} color={T.txtMuted}>{job.time}</Mono>
                    </td>
                    <td style={{ padding: '11px 16px', textAlign: 'right' }}>
                      <RowAction status={job.status} />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

// ── LOADS RANGES ───────────────────────────────────────────────────────
function RangesTab() {
  const [hoveredRow, setHoveredRow] = useState<number | null>(null);

  const cards = [
    { label: 'Инструментов с загрузками', value: '7',   unit: '' },
    { label: 'Без загрузок',              value: '240',  unit: '' },
    { label: 'Типов данных',              value: '6',    unit: '' },
    { label: 'Строк всего',               value: '2.1M', unit: '' },
  ];

  return (
    <div style={{ flex: 1, overflowY: 'auto', padding: 20 }}>
      {/* Summary cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 20 }}>
        {cards.map(c => (
          <div key={c.label} style={{
            background: T.bgSurface, border: `1px solid ${T.subtle}`, borderRadius: 12,
            padding: 16, boxShadow: T.shadowCard,
          }}>
            <div style={{ fontSize: 9, fontWeight: 600, letterSpacing: '0.16em', textTransform: 'uppercase', color: T.txtMuted, marginBottom: 10 }}>{c.label}</div>
            <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 28, fontWeight: 500, color: T.txtPrimary }}>{c.value}</div>
          </div>
        ))}
      </div>

      {/* FUTOI info banner */}
      <div style={{
        display: 'flex', alignItems: 'flex-start', gap: 10, padding: '10px 14px', borderRadius: 8, marginBottom: 16,
        background: 'rgba(234,179,8,0.06)', border: `1px solid rgba(234,179,8,0.2)`,
      }}>
        <AlertTriangle size={14} color="#EAB308" style={{ marginTop: 1, flexShrink: 0 }} />
        <span style={{ fontSize: 12, color: '#EAB308', lineHeight: 1.5 }}>
          FUTOI загружается по <span style={{ fontFamily: 'JetBrains Mono, monospace' }}>asset_code</span> (Si), не по <span style={{ fontFamily: 'JetBrains Mono, monospace' }}>secid</span> (SiM6). Диапазоны могут объединять несколько контрактов.
        </span>
      </div>

      {/* Table */}
      <div style={{ background: T.bgSurface, border: `1px solid ${T.subtle}`, borderRadius: 12, overflow: 'hidden' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ background: T.bgApp }}>
              {['ИНСТРУМЕНТ', 'ТИП ДАННЫХ', 'ИНТЕРВАЛ', 'ПЕРИОД', 'СТРОК', 'ХРАНИЛИЩЕ', 'СТАТУС', 'ОБНОВЛЕНО'].map((h, i) => (
                <th key={h} style={{
                  padding: '10px 16px', textAlign: i === 4 ? 'right' : 'left',
                  fontSize: 9, fontWeight: 600, letterSpacing: '0.16em', textTransform: 'uppercase',
                  color: T.txtMuted, borderBottom: `1px solid ${T.hairline}`,
                }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {RANGES_DATA.map((r, i) => (
              <tr key={i}
                onMouseEnter={() => setHoveredRow(i)}
                onMouseLeave={() => setHoveredRow(null)}
                style={{ background: hoveredRow === i ? T.bgHover : 'transparent', borderBottom: `1px solid rgba(26,30,37,0.6)`, transition: 'background 0.1s' }}
              >
                <td style={{ padding: '11px 16px' }}>
                  <span style={{ fontSize: 13, fontWeight: 600, color: T.txtPrimary, fontFamily: 'JetBrains Mono, monospace' }}>{r.secid}</span>
                </td>
                <td style={{ padding: '11px 16px' }}>
                  <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 12, color: T.txtSecondary }}>{r.dataType}</span>
                </td>
                <td style={{ padding: '11px 16px' }}>
                  <Mono size={12} color={r.interval === '—' ? T.txtDisabled : T.txtSecondary}>{r.interval}</Mono>
                </td>
                <td style={{ padding: '11px 16px' }}>
                  <Mono size={12} color={T.txtSecondary}>{r.period}</Mono>
                </td>
                <td style={{ padding: '11px 16px', textAlign: 'right' }}>
                  <Mono size={12} color={T.txtPrimary} bold>{r.rows.toLocaleString('ru-RU')}</Mono>
                </td>
                <td style={{ padding: '11px 16px' }}>
                  <span style={{ fontSize: 11, fontFamily: 'JetBrains Mono, monospace', color: T.txtMuted, padding: '2px 6px', background: T.bgApp, borderRadius: 4, border: `1px solid ${T.hairline}` }}>{r.storage}</span>
                </td>
                <td style={{ padding: '11px 16px' }}>
                  <StatusBadge status={r.status} />
                </td>
                <td style={{ padding: '11px 16px' }}>
                  <Mono size={11} color={T.txtMuted}>{r.updated}</Mono>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── LOADS SCREEN ───────────────────────────────────────────────────────
interface LoadsScreenProps {
  currentPage: NavPage;
  onNavigate: (p: NavPage) => void;
  onCreateJob: () => void;
  onBulkLoad: () => void;
}

export function LoadsScreen({ currentPage, onNavigate, onCreateJob, onBulkLoad }: LoadsScreenProps) {
  const [tab, setTab] = useState<'jobs' | 'ranges'>('jobs');

  return (
    <AppShell currentPage={currentPage} onNavigate={onNavigate} breadcrumb="Загрузки">
      <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
        {/* Page header + tabs */}
        <div style={{ padding: '20px 20px 0', borderBottom: `1px solid ${T.hairline}`, flexShrink: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', marginBottom: 16 }}>
            <h1 style={{ fontSize: 24, fontWeight: 600, color: T.txtPrimary, margin: 0 }}>Загрузки</h1>
            <div style={{ flex: 1 }} />
          </div>
          {/* Tabs */}
          <div style={{ display: 'flex', gap: 0 }}>
            {[{ k: 'jobs', l: 'Задания' }, { k: 'ranges', l: 'Диапазоны' }].map(t => (
              <button
                key={t.k}
                onClick={() => setTab(t.k as 'jobs' | 'ranges')}
                style={{
                  padding: '8px 16px', fontSize: 13, fontWeight: 500, cursor: 'pointer',
                  background: 'none', border: 'none', borderBottom: `2px solid ${tab === t.k ? T.accent : 'transparent'}`,
                  color: tab === t.k ? T.accent : T.txtSecondary,
                  fontFamily: "'Inter', sans-serif", transition: 'all 0.12s',
                }}
              >{t.l}</button>
            ))}
          </div>
        </div>

        {/* Tab content */}
        <div style={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
          {tab === 'jobs'
            ? <JobsTab onCreateJob={onCreateJob} onBulkLoad={onBulkLoad} />
            : <RangesTab />
          }
        </div>
      </div>
    </AppShell>
  );
}
