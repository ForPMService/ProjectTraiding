import { useState } from 'react';
import { RefreshCw, ToggleLeft, ToggleRight } from 'lucide-react';
import { AppShell, NavPage, T, Mono, PrimaryBtn, SecondaryBtn, SectionLabel, StatusBadge } from '../shell/AppShell';

const SYNC_DATA = [
  { type: 'securities',  needsKey: false, lastSync: '2026-06-19 08:00', records: 247,    error: null },
  { type: 'calendar',   needsKey: false, lastSync: '2026-06-19 08:05', records: 156,    error: null },
  { type: 'candles',    needsKey: true,  lastSync: '2026-06-19 10:24', records: 214200, error: null },
  { type: 'tradestats', needsKey: true,  lastSync: '2026-06-18 23:50', records: 156400, error: null },
  { type: 'futoi',      needsKey: true,  lastSync: '2026-06-18 23:55', records: 44100,  error: null },
  { type: 'obstats',    needsKey: true,  lastSync: null,               records: 0,      error: 'API 429 — превышен лимит запросов' },
];

const AUTO_LOG = [
  { date: '2026-06-19 03:00', status: 'success', jobs: 5, duration: '12m 44s' },
  { date: '2026-06-18 03:00', status: 'success', jobs: 5, duration: '11m 22s' },
  { date: '2026-06-17 03:00', status: 'warning', jobs: 4, duration: '14m 01s' },
];

export function OperationsScreen({ currentPage, onNavigate }: { currentPage: NavPage; onNavigate: (p: NavPage) => void }) {
  const [autoEnabled, setAutoEnabled] = useState(true);
  const [hoveredRow, setHoveredRow] = useState<number | null>(null);

  return (
    <AppShell currentPage={currentPage} onNavigate={onNavigate} breadcrumb="Операции">
      <div style={{ height: '100%', overflowY: 'auto', padding: 20 }}>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 24 }}>
          <h1 style={{ fontSize: 24, fontWeight: 600, color: T.txtPrimary, margin: 0 }}>Операции</h1>
          <div style={{ flex: 1 }} />
          <PrimaryBtn small><RefreshCw size={13} />Обновить всё</PrimaryBtn>
        </div>

        {/* Sync table */}
        <SectionLabel>Синхронизации</SectionLabel>
        <div style={{ background: T.bgSurface, border: `1px solid ${T.subtle}`, borderRadius: 12, overflow: 'hidden', boxShadow: T.shadowCard, marginBottom: 24 }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: T.bgApp }}>
                {['ТИП ДАННЫХ', 'КЛЮЧ APIM', 'ПОСЛЕДНЯЯ СИНХРОНИЗАЦИЯ', 'ЗАПИСЕЙ', 'ОШИБКА', ''].map(h => (
                  <th key={h} style={{ padding: '10px 16px', textAlign: 'left', fontSize: 9, fontWeight: 600, letterSpacing: '0.16em', textTransform: 'uppercase', color: T.txtMuted, borderBottom: `1px solid ${T.hairline}` }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {SYNC_DATA.map((s, i) => (
                <tr key={i}
                  onMouseEnter={() => setHoveredRow(i)}
                  onMouseLeave={() => setHoveredRow(null)}
                  style={{ background: hoveredRow === i ? T.bgHover : 'transparent', borderBottom: `1px solid rgba(26,30,37,0.6)`, transition: 'background 0.1s' }}
                >
                  <td style={{ padding: '11px 16px' }}><Mono size={12} color={T.txtPrimary}>{s.type}</Mono></td>
                  <td style={{ padding: '11px 16px' }}>
                    <span style={{ fontSize: 11, color: s.needsKey ? '#EAB308' : T.txtMuted }}>
                      {s.needsKey ? '✓ нужен' : '—'}
                    </span>
                  </td>
                  <td style={{ padding: '11px 16px' }}>
                    {s.lastSync
                      ? <Mono size={12} color={T.txtSecondary}>{s.lastSync}</Mono>
                      : <span style={{ fontSize: 12, color: T.txtDisabled }}>никогда</span>
                    }
                  </td>
                  <td style={{ padding: '11px 16px', textAlign: 'right' }}>
                    <Mono size={12} color={s.records > 0 ? T.txtPrimary : T.txtDisabled}>{s.records > 0 ? s.records.toLocaleString('ru-RU') : '—'}</Mono>
                  </td>
                  <td style={{ padding: '11px 16px', maxWidth: 240 }}>
                    {s.error
                      ? <span style={{ fontSize: 12, color: '#EF4444', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', display: 'block' }}>{s.error}</span>
                      : <span style={{ fontSize: 12, color: T.txtDisabled }}>—</span>
                    }
                  </td>
                  <td style={{ padding: '11px 16px', textAlign: 'right' }}>
                    <button style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 12, color: T.accent, background: 'none', border: 'none', cursor: 'pointer', fontFamily: "'Inter', sans-serif" }}>
                      <RefreshCw size={12} />Обновить
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Auto jobs */}
        <SectionLabel>Автоматические задания</SectionLabel>
        <div style={{ background: T.bgSurface, border: `1px solid ${T.subtle}`, borderRadius: 12, padding: 20, boxShadow: T.shadowCard }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
            <div>
              <div style={{ fontSize: 14, fontWeight: 500, color: T.txtPrimary, marginBottom: 3 }}>Ежевечерняя загрузка свечей</div>
              <div style={{ fontSize: 12, color: T.txtSecondary }}>Ежедневно в <Mono size={12} color={T.txtPrimary}>03:00</Mono> по всем отслеживаемым инструментам</div>
            </div>
            <button onClick={() => setAutoEnabled(e => !e)} style={{ background: 'none', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 8 }}>
              {autoEnabled
                ? <ToggleRight size={32} color={T.accent} />
                : <ToggleLeft size={32} color={T.txtDisabled} />
              }
              <span style={{ fontSize: 13, color: autoEnabled ? T.accent : T.txtDisabled, fontWeight: 500 }}>{autoEnabled ? 'Вкл.' : 'Выкл.'}</span>
            </button>
          </div>

          {/* Instruments list */}
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 16, padding: '12px 0', borderTop: `1px solid ${T.hairline}`, borderBottom: `1px solid ${T.hairline}` }}>
            {['SBER', 'GAZP', 'LKOH', 'SiM6', 'SiU6'].map(s => (
              <span key={s} style={{ fontSize: 11, fontFamily: 'JetBrains Mono, monospace', color: T.txtSecondary, padding: '3px 8px', background: T.bgApp, borderRadius: 4, border: `1px solid ${T.hairline}` }}>{s}</span>
            ))}
          </div>

          {/* Log */}
          <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: T.txtDisabled, marginBottom: 8 }}>Последние запуски</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
            {AUTO_LOG.map((l, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '6px 0', borderBottom: i < AUTO_LOG.length - 1 ? `1px solid rgba(26,30,37,0.5)` : 'none' }}>
                <Mono size={11} color={T.txtMuted}>{l.date}</Mono>
                <StatusBadge status={l.status} />
                <span style={{ fontSize: 12, color: T.txtSecondary }}>{l.jobs} задан{l.jobs === 1 ? 'ие' : 'ия'}</span>
                <Mono size={11} color={T.txtDisabled}>{l.duration}</Mono>
              </div>
            ))}
          </div>
        </div>
      </div>
    </AppShell>
  );
}
