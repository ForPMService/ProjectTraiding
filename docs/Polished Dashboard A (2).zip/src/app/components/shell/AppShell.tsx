import React, { useState, useEffect } from 'react';
import {
  LayoutDashboard, Download, Layers, Calendar, ShieldCheck,
  GitBranch, DollarSign, Star, Settings, ChevronRight, Search, Command, Database,
} from 'lucide-react';

export type NavPage =
  | 'dashboard' | 'loads' | 'instruments' | 'calendar'
  | 'quality' | 'operations' | 'costs' | 'rating' | 'settings';

// ── Design tokens ─────────────────────────────────────────────────────
export const T = {
  bgApp:     '#0B0D10',
  bgSurface: '#14171C',
  bgElevated:'#1C2027',
  bgHover:   '#181C22',
  hairline:  '#1A1E25',
  subtle:    '#232831',
  border:    '#2D333E',
  txtPrimary:  '#E6E8EC',
  txtSecondary:'#9BA1AD',
  txtMuted:    '#6B7280',
  txtDisabled: '#3E4451',
  accent:    '#6366F1',
  accentHov: '#818CF8',
  accentSub: '#1E1F3A',
  shadowCard:'0 6px 16px -3px rgba(0,0,0,.4), inset 0 1px 0 rgba(255,255,255,.035)',
  shadowModal:'0 24px 64px -12px rgba(0,0,0,.7), 0 8px 16px -4px rgba(0,0,0,.5)',
} as const;

// Status config
export const STATUS = {
  success:  { label: 'успешно',     fg: '#22C55E', bg: '#14532D', border: 'rgba(22,163,74,.4)' },
  ok:       { label: 'ok',          fg: '#22C55E', bg: '#14532D', border: 'rgba(22,163,74,.4)' },
  warning:  { label: 'внимание',    fg: '#EAB308', bg: '#713F12', border: 'rgba(202,138,4,.4)' },
  partial:  { label: 'частично',    fg: '#EAB308', bg: '#713F12', border: 'rgba(202,138,4,.4)' },
  error:    { label: 'ошибка',      fg: '#EF4444', bg: '#7F1D1D', border: 'rgba(220,38,38,.4)' },
  stale:    { label: 'устарело',    fg: '#EF4444', bg: '#7F1D1D', border: 'rgba(220,38,38,.4)' },
  running:  { label: 'выполняется', fg: '#38BDF8', bg: '#0C4A6E', border: 'rgba(14,165,233,.4)' },
  pending:  { label: 'ожидает',     fg: '#94A3B8', bg: '#1E293B', border: 'rgba(148,163,184,.35)' },
  neutral:  { label: 'нет данных',  fg: '#9CA3AF', bg: '#1F2937', border: 'rgba(75,85,99,.4)' },
} as const;
export type StatusKey = keyof typeof STATUS;

// ── Shared primitives ─────────────────────────────────────────────────
export function Mono({ children, size = 13, color, bold }: {
  children: React.ReactNode; size?: number; color?: string; bold?: boolean;
}) {
  return (
    <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: size, color: color ?? T.txtPrimary, fontWeight: bold ? 500 : 400 }}>
      {children}
    </span>
  );
}

export function StatusBadge({ status }: { status: string }) {
  const s = STATUS[status as StatusKey] ?? STATUS.neutral;
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 5,
      fontSize: 11, fontWeight: 500, lineHeight: 1,
      padding: '3px 8px', borderRadius: 4,
      color: s.fg, background: s.bg, border: `1px solid ${s.border}`,
    }}>
      <span style={{ width: 5, height: 5, borderRadius: '50%', background: s.fg, flexShrink: 0 }} />
      {s.label}
    </span>
  );
}

export function PrimaryBtn({ children, onClick, small }: { children: React.ReactNode; onClick?: () => void; small?: boolean }) {
  return (
    <button
      onClick={onClick}
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 6,
        background: T.accent, color: '#fff', border: 'none', borderRadius: 8,
        padding: small ? '5px 12px' : '7px 14px',
        fontSize: small ? 12 : 13, fontWeight: 500, cursor: 'pointer',
        fontFamily: "'Inter', sans-serif", whiteSpace: 'nowrap',
      }}
    >
      {children}
    </button>
  );
}

export function SecondaryBtn({ children, onClick, small }: { children: React.ReactNode; onClick?: () => void; small?: boolean }) {
  return (
    <button
      onClick={onClick}
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 6,
        background: 'transparent', color: T.txtSecondary,
        border: `1px solid ${T.border}`, borderRadius: 8,
        padding: small ? '5px 12px' : '7px 14px',
        fontSize: small ? 12 : 13, fontWeight: 500, cursor: 'pointer',
        fontFamily: "'Inter', sans-serif", whiteSpace: 'nowrap',
      }}
    >
      {children}
    </button>
  );
}

export function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: '0.14em', textTransform: 'uppercase', color: T.txtSecondary, marginBottom: 12 }}>
      {children}
    </div>
  );
}

export function EmptyState({ icon: Icon, title, description, action }: {
  icon: React.ElementType; title: string; description: string; action?: React.ReactNode;
}) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', flex: 1, padding: 48, gap: 16, textAlign: 'center' }}>
      <div style={{ width: 48, height: 48, borderRadius: 12, background: T.bgSurface, border: `1px solid ${T.subtle}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <Icon size={22} color={T.txtDisabled} />
      </div>
      <div>
        <div style={{ fontSize: 15, fontWeight: 600, color: T.txtPrimary, marginBottom: 6 }}>{title}</div>
        <div style={{ fontSize: 13, color: T.txtSecondary, maxWidth: 360, lineHeight: 1.6 }}>{description}</div>
      </div>
      {action}
    </div>
  );
}

// ── Abstract indigo avatar ─────────────────────────────────────────────
function IndigoAvatar() {
  return (
    <svg width="30" height="30" viewBox="0 0 30 30" fill="none" style={{ flexShrink: 0 }}>
      <circle cx="15" cy="15" r="15" fill="#1E1F3A"/>
      <circle cx="15" cy="11" r="5" fill="#6366F1" opacity="0.9"/>
      <ellipse cx="15" cy="26" rx="9" ry="6" fill="#6366F1" opacity="0.7"/>
    </svg>
  );
}

// ── Nav items ─────────────────────────────────────────────────────────
const MONITORING_NAV: { id: NavPage; label: string; icon: React.ElementType }[] = [
  { id: 'dashboard',   label: 'Dashboard',   icon: LayoutDashboard },
  { id: 'loads',       label: 'Загрузки',    icon: Download },
  { id: 'instruments', label: 'Инструменты', icon: Layers },
  { id: 'calendar',    label: 'Календарь',   icon: Calendar },
  { id: 'quality',     label: 'Качество',    icon: ShieldCheck },
  { id: 'operations',  label: 'Операции',    icon: GitBranch },
];
const ANALYTICS_NAV: { id: NavPage; label: string; icon: React.ElementType }[] = [
  { id: 'costs',  label: 'Издержки', icon: DollarSign },
  { id: 'rating', label: 'Рейтинг',  icon: Star },
];

function NavItem({ id, label, icon: Icon, active, onClick }: {
  id: string; label: string; icon: React.ElementType; active: boolean; onClick: () => void;
}) {
  const [hovered, setHovered] = useState(false);
  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        position: 'relative', display: 'flex', alignItems: 'center', gap: 10,
        width: '100%', padding: '8px 10px', borderRadius: 8, border: 'none', cursor: 'pointer',
        fontSize: 13, fontWeight: active ? 500 : 400, textAlign: 'left',
        background: active ? T.accentSub : hovered ? 'rgba(255,255,255,0.03)' : 'transparent',
        color: active ? T.accent : hovered ? T.txtPrimary : T.txtSecondary,
        fontFamily: "'Inter', sans-serif",
        transition: 'background 0.12s, color 0.12s',
      }}
    >
      {active && (
        <div style={{ position: 'absolute', left: 0, top: '50%', transform: 'translateY(-50%)', width: 2, height: 20, background: T.accent, borderRadius: '0 2px 2px 0' }} />
      )}
      <Icon size={15} />
      <span>{label}</span>
    </button>
  );
}

// ── AppShell ──────────────────────────────────────────────────────────
interface AppShellProps {
  currentPage: NavPage;
  onNavigate: (page: NavPage) => void;
  breadcrumb: string;
  children: React.ReactNode;
}

export function AppShell({ currentPage, onNavigate, breadcrumb, children }: AppShellProps) {
  const [time, setTime] = useState(() => new Date().toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }));
  useEffect(() => {
    const t = setInterval(() => setTime(new Date().toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })), 30000);
    return () => clearInterval(t);
  }, []);

  return (
    <div style={{ display: 'flex', height: '100vh', background: T.bgApp, color: T.txtPrimary, fontFamily: "'Inter', sans-serif", overflow: 'hidden' }}>
      {/* Sidebar 240px */}
      <div style={{ width: 240, flexShrink: 0, background: T.bgSurface, borderRight: `1px solid ${T.hairline}`, display: 'flex', flexDirection: 'column' }}>
        {/* Logo */}
        <div style={{ padding: '18px 16px 14px', borderBottom: `1px solid ${T.hairline}` }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 32, height: 32, borderRadius: 8, background: T.accent, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <Database size={15} color="#fff" />
            </div>
            <div>
              <div style={{ fontSize: 12, fontWeight: 700, color: T.txtPrimary, lineHeight: 1.25 }}>MOEX</div>
              <div style={{ fontSize: 10, color: T.txtDisabled, lineHeight: 1.25 }}>Data Ops</div>
            </div>
          </div>
        </div>

        {/* Nav */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '12px 8px' }}>
          {/* МОНИТОРИНГ */}
          <div style={{ fontSize: 9, fontWeight: 600, letterSpacing: '0.16em', textTransform: 'uppercase', color: T.txtDisabled, padding: '0 10px', marginBottom: 4 }}>МОНИТОРИНГ</div>
          {MONITORING_NAV.map(item => (
            <NavItem key={item.id} {...item} active={currentPage === item.id} onClick={() => onNavigate(item.id)} />
          ))}
          <div style={{ height: 16 }} />
          {/* АНАЛИТИКА */}
          <div style={{ fontSize: 9, fontWeight: 600, letterSpacing: '0.16em', textTransform: 'uppercase', color: T.txtDisabled, padding: '0 10px', marginBottom: 4 }}>АНАЛИТИКА</div>
          {ANALYTICS_NAV.map(item => (
            <NavItem key={item.id} {...item} active={currentPage === item.id} onClick={() => onNavigate(item.id)} />
          ))}
        </div>

        {/* Bottom */}
        <div style={{ borderTop: `1px solid ${T.hairline}`, padding: 8 }}>
          <NavItem id="settings" label="Настройки" icon={Settings} active={currentPage === 'settings'} onClick={() => onNavigate('settings')} />
          <div style={{ marginTop: 8, padding: '8px 10px', borderRadius: 8, background: T.bgApp, display: 'flex', alignItems: 'center', gap: 10 }}>
            <IndigoAvatar />
            <div style={{ minWidth: 0 }}>
              <div style={{ fontSize: 12, fontWeight: 500, color: T.txtPrimary, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>Александр Е.</div>
              <div style={{ fontSize: 10, color: T.txtDisabled }}>Оператор · MOEX</div>
            </div>
          </div>
        </div>
      </div>

      {/* Content column */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', minWidth: 0 }}>
        {/* Topbar */}
        <div style={{ height: 48, flexShrink: 0, background: T.bgSurface, borderBottom: `1px solid ${T.hairline}`, display: 'flex', alignItems: 'center', padding: '0 20px', gap: 12 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, color: T.txtDisabled }}>
            <span>MOEX Data Ops</span>
            <ChevronRight size={12} />
            <span style={{ color: T.txtSecondary }}>{breadcrumb}</span>
          </div>
          <div style={{ flex: 1 }} />
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ width: 7, height: 7, borderRadius: '50%', background: '#22C55E', boxShadow: '0 0 6px rgba(34,197,94,0.5)' }} />
            <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 12, color: T.txtSecondary }}>LIVE {time}</span>
          </div>
          <div style={{ position: 'relative' }}>
            <Search size={12} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: T.txtMuted }} />
            <input
              placeholder="Поиск..."
              style={{ height: 30, width: 200, background: T.bgApp, border: `1px solid ${T.border}`, borderRadius: 6, paddingLeft: 30, paddingRight: 38, fontSize: 12, color: T.txtPrimary, outline: 'none', fontFamily: "'Inter', sans-serif" }}
            />
            <div style={{ position: 'absolute', right: 8, top: '50%', transform: 'translateY(-50%)', display: 'flex', alignItems: 'center', gap: 2, fontSize: 10, color: T.txtDisabled, background: T.hairline, borderRadius: 4, padding: '2px 5px' }}>
              <Command size={9} />K
            </div>
          </div>
        </div>

        {/* Page content */}
        <div style={{ flex: 1, overflow: 'hidden', position: 'relative' }}>
          {children}
        </div>
      </div>
    </div>
  );
}
