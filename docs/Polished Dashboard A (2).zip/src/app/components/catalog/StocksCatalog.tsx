import { useState } from 'react';
import { Sidebar } from '../Sidebar';
import { Topbar } from '../Topbar';

export function StocksCatalog() {
  const [activeTab, setActiveTab] = useState<'all' | 'stocks' | 'futures'>('stocks');

  const stocks = [
    {
      secid: 'SBER',
      shortname: 'Сбербанк',
      listing: '1',
      lot: '10',
      priceStep: '0.01',
      dataStatus: 'частично',
      loaded: ['candles', 'tradestats', 'orderstats'],
      period: '01.12—31.12',
      coverage: 92,
      flags: ['обогащение частично'],
      watched: true,
      action: 'Дозагрузить'
    },
    {
      secid: 'GAZP',
      shortname: 'Газпром',
      listing: '1',
      lot: '10',
      priceStep: '0.01',
      dataStatus: 'частично',
      loaded: ['candles', 'tradestats'],
      period: '01.12—20.12',
      coverage: 65,
      flags: ['stale'],
      watched: false,
      action: 'Дозагрузить'
    },
    {
      secid: 'LKOH',
      shortname: 'Лукойл',
      listing: '1',
      lot: '1',
      priceStep: '0.5',
      dataStatus: 'не загружено',
      loaded: [],
      period: '—',
      coverage: 0,
      flags: [],
      watched: false,
      action: 'Загрузить'
    },
    {
      secid: 'GMKN',
      shortname: 'Норникель',
      listing: '1',
      lot: '1',
      priceStep: '1.0',
      dataStatus: 'требует проверки',
      loaded: ['candles'],
      period: '20.12—31.12',
      coverage: -1,
      flags: ['ограничение', 'изменён'],
      watched: true,
      action: 'Проверить'
    },
    {
      secid: 'VTBR',
      shortname: 'ВТБ',
      listing: '1',
      lot: '10000',
      priceStep: '0.0001',
      dataStatus: 'загружено',
      loaded: ['candles', 'orderstats', 'obstats'],
      period: '01.12—31.12',
      coverage: 100,
      flags: [],
      watched: false,
      action: 'Открыть'
    },
  ];

  return (
    <div className="min-h-screen bg-[#0b0d10] font-['Inter',sans-serif]">
      <Sidebar activePage="instruments" />

      <div className="ml-[220px] min-h-screen">
        <Topbar liveStatus="live" />

        <div className="p-8">
          {/* Breadcrumb */}
          <div className="mb-6 text-[12px]">
            <span className="text-[#6b7280]">DATA OPS / Инструменты / </span>
            <span className="text-[13px] font-bold text-[#e6e8ec]">Акции</span>
          </div>

          {/* Header */}
          <div className="mb-6">
            <h1 className="text-[32px] font-semibold tracking-[-0.02em] text-[#e6e8ec] mb-2">
              Каталог инструментов
            </h1>
            <p className="text-[13px] text-[#9ba1ad]">
              Центральный реестр торговых инструментов и их данных
            </p>
          </div>

          {/* Tabs */}
          <div className="mb-6">
            <div className="flex items-center gap-6 border-b border-[#1a1e25]">
              <button
                onClick={() => setActiveTab('all')}
                className={`pb-3 text-[13px] transition-all duration-200 ${
                  activeTab === 'all'
                    ? 'font-bold text-[#e6e8ec] border-b-2 border-[#6366f1]'
                    : 'text-[#9ba1ad] hover:text-[#c2c8d2]'
                }`}
              >
                Все
              </button>
              <button
                onClick={() => setActiveTab('stocks')}
                className={`pb-3 text-[13px] transition-all duration-200 ${
                  activeTab === 'stocks'
                    ? 'font-bold text-[#e6e8ec] border-b-2 border-[#6366f1]'
                    : 'text-[#9ba1ad] hover:text-[#c2c8d2]'
                }`}
              >
                Акции
              </button>
              <button
                onClick={() => setActiveTab('futures')}
                className={`pb-3 text-[13px] transition-all duration-200 ${
                  activeTab === 'futures'
                    ? 'font-bold text-[#e6e8ec] border-b-2 border-[#6366f1]'
                    : 'text-[#9ba1ad] hover:text-[#c2c8d2]'
                }`}
              >
                Фьючерсы
              </button>
            </div>
          </div>

          {/* Filters */}
          <div className="mb-6 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <select className="bg-[#14171c] border border-[#2d333e] rounded-md text-[13px] text-[#9ba1ad] px-3 py-2 hover:border-[#6366f1]/50 transition-colors">
                <option>Статус данных ▾</option>
              </select>
              <select className="bg-[#14171c] border border-[#2d333e] rounded-md text-[13px] text-[#9ba1ad] px-3 py-2 hover:border-[#6366f1]/50 transition-colors">
                <option>Что загружено ▾</option>
              </select>
              <select className="bg-[#14171c] border border-[#2d333e] rounded-md text-[13px] text-[#9ba1ad] px-3 py-2 hover:border-[#6366f1]/50 transition-colors">
                <option>Листинг ▾</option>
              </select>
              <select className="bg-[#14171c] border border-[#2d333e] rounded-md text-[13px] text-[#9ba1ad] px-3 py-2 hover:border-[#6366f1]/50 transition-colors">
                <option>Флаги ▾</option>
              </select>
              <select className="bg-[#14171c] border border-[#2d333e] rounded-md text-[13px] text-[#9ba1ad] px-3 py-2 hover:border-[#6366f1]/50 transition-colors">
                <option>Отслеживание ▾</option>
              </select>
              <input
                type="text"
                placeholder="Поиск secid, тикера или названия"
                className="bg-[#14171c] border border-[#2d333e] rounded-md text-[12px] text-[#e6e8ec] placeholder-[#6b7280] px-3 py-2 w-[280px] hover:border-[#6366f1]/50 focus:border-[#6366f1] outline-none transition-colors"
              />
            </div>
            <button className="text-[12px] text-[#6b7280] hover:text-[#9ba1ad] transition-colors">
              Сбросить фильтры
            </button>
          </div>

          {/* Table */}
          <div
            className="bg-[#14171c] border border-[#232831] rounded-xl overflow-hidden"
            style={{
              boxShadow: '0 6px 16px -3px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.035)'
            }}
          >
            {/* Table Caption */}
            <div className="bg-[#0b0d10] px-6 py-3 border-b border-[#232831] flex items-center gap-2">
              <span className="text-[11px] font-bold tracking-[0.14em] uppercase text-[#6b7280]">АКЦИИ</span>
              <span className="font-['JetBrains_Mono',monospace] text-[11px] text-[#9ba1ad]">183</span>
            </div>

            {/* Table Header */}
            <div className="bg-[#0b0d10] px-6 py-3.5 flex items-center gap-4 border-b border-[#232831]">
              <div className="w-[140px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ИНСТРУМЕНТ</div>
              <div className="w-[70px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280] text-right">ЛИСТИНГ</div>
              <div className="w-[60px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280] text-right">ЛОТ</div>
              <div className="w-[80px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ШАГ ЦЕНЫ</div>
              <div className="w-[140px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">СТАТУС ДАННЫХ</div>
              <div className="w-[200px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ЧТО ЗАГРУЖЕНО</div>
              <div className="w-[120px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ПЕРИОД</div>
              <div className="w-[90px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ПОКРЫТИЕ</div>
              <div className="w-[160px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ФЛАГИ</div>
              <div className="w-[70px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ОТСЛЕЖ.</div>
              <div className="w-[100px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ДЕЙСТВИЕ</div>
            </div>

            {/* Table Rows */}
            <div className="bg-[#0b0d10]">
              {stocks.map((stock, i) => {
                const isNotLoaded = stock.dataStatus === 'не загружено';

                return (
                  <div key={stock.secid}>
                    <div
                      className="flex items-center gap-4 px-6 py-4 hover:bg-[#181c22] transition-colors cursor-pointer group"
                    >
                      {/* ИНСТРУМЕНТ */}
                      <div className="w-[140px]">
                        <div className={`text-[13px] font-bold leading-none mb-1 ${isNotLoaded ? 'text-[#6b7280]' : 'text-[#e6e8ec]'}`}>
                          {stock.secid}
                        </div>
                        <div className={`font-['JetBrains_Mono',monospace] text-[10px] ${isNotLoaded ? 'text-[#3e4451]' : 'text-[#6b7280]'}`}>
                          {stock.shortname}
                        </div>
                      </div>

                      {/* ЛИСТИНГ */}
                      <div className={`w-[70px] font-['JetBrains_Mono',monospace] text-[13px] font-medium text-right tabular-nums ${isNotLoaded ? 'text-[#3e4451]' : 'text-[#e6e8ec]'}`}>
                        {stock.listing}
                      </div>

                      {/* ЛОТ */}
                      <div className={`w-[60px] font-['JetBrains_Mono',monospace] text-[13px] font-medium text-right tabular-nums ${isNotLoaded ? 'text-[#3e4451]' : 'text-[#e6e8ec]'}`}>
                        {stock.lot}
                      </div>

                      {/* ШАГ ЦЕНЫ */}
                      <div className={`w-[80px] font-['JetBrains_Mono',monospace] text-[12px] ${isNotLoaded ? 'text-[#3e4451]' : 'text-[#9ba1ad]'}`}>
                        {stock.priceStep}
                      </div>

                      {/* СТАТУС ДАННЫХ */}
                      <div className="w-[140px]">
                        <DataStatusBadge status={stock.dataStatus} />
                      </div>

                      {/* ЧТО ЗАГРУЖЕНО */}
                      <div className="w-[200px] flex flex-wrap gap-1.5">
                        {stock.loaded.length > 0 ? (
                          stock.loaded.map((item) => (
                            <span
                              key={item}
                              className="inline-block font-['JetBrains_Mono',monospace] text-[10px] text-[#9ba1ad] bg-[#0b0d10] border border-[#232831] rounded px-1.5 py-0.5"
                            >
                              {item}
                            </span>
                          ))
                        ) : (
                          <span className="text-[#3e4451]">—</span>
                        )}
                      </div>

                      {/* ПЕРИОД */}
                      <div className={`w-[120px] font-['JetBrains_Mono',monospace] text-[12px] ${isNotLoaded ? 'text-[#3e4451]' : 'text-[#9ba1ad]'}`}>
                        {stock.period}
                      </div>

                      {/* ПОКРЫТИЕ */}
                      <div className="w-[90px]">
                        <CoverageDisplay coverage={stock.coverage} />
                      </div>

                      {/* ФЛАГИ */}
                      <div className="w-[160px] flex flex-wrap gap-1.5">
                        {stock.flags.length > 0 ? (
                          stock.flags.map((flag) => (
                            <FlagBadge key={flag} flag={flag} />
                          ))
                        ) : (
                          <span className="text-[#3e4451]">—</span>
                        )}
                      </div>

                      {/* ОТСЛЕЖ. */}
                      <div className="w-[70px]">
                        <TogglePill checked={stock.watched} />
                      </div>

                      {/* ДЕЙСТВИЕ */}
                      <div className="w-[100px]">
                        <ActionButton action={stock.action} dataStatus={stock.dataStatus} />
                      </div>
                    </div>
                    {i < stocks.length - 1 && (
                      <div className="h-px bg-[#1a1e25]" />
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function DataStatusBadge({ status }: { status: string }) {
  const configs: Record<string, { bg: string; border: string; dot: string; text: string; label: string }> = {
    'загружено': { bg: '#14532d', border: 'rgba(22,163,74,0.4)', dot: '#22c55e', text: '#22c55e', label: 'загружено' },
    'частично': { bg: '#713f12', border: 'rgba(202,138,4,0.4)', dot: '#eab308', text: '#eab308', label: 'частично' },
    'не загружено': { bg: '#1f2937', border: 'rgba(75,85,99,0.4)', dot: '#9ca3af', text: '#9ca3af', label: 'не загружено' },
    'требует проверки': { bg: '#713f12', border: 'rgba(202,138,4,0.4)', dot: '#eab308', text: '#eab308', label: 'требует проверки' },
  };

  const config = configs[status] || configs['не загружено'];

  return (
    <div
      className="inline-flex items-center gap-1.5 py-[3px] pl-[7px] pr-[9px] rounded"
      style={{
        backgroundColor: config.bg,
        border: `1px solid ${config.border}`
      }}
    >
      <div className="w-[5px] h-[5px] rounded-sm" style={{ backgroundColor: config.dot }} />
      <span className="text-[11px] font-medium" style={{ color: config.text }}>{config.label}</span>
    </div>
  );
}

function CoverageDisplay({ coverage }: { coverage: number }) {
  if (coverage === -1) {
    return (
      <span className="font-['JetBrains_Mono',monospace] text-[13px] font-medium text-[#eab308]">
        пропуски
      </span>
    );
  }

  const color = coverage === 100 ? '#22c55e' : coverage > 0 ? '#eab308' : '#3e4451';

  return (
    <span
      className="font-['JetBrains_Mono',monospace] text-[13px] font-medium tabular-nums"
      style={{ color }}
    >
      {coverage}%
    </span>
  );
}

function FlagBadge({ flag }: { flag: string }) {
  const configs: Record<string, { bg: string; border: string; text: string }> = {
    'не обогащён': { bg: '#713f12', border: 'rgba(202,138,4,0.3)', text: '#eab308' },
    'обогащение частично': { bg: '#713f12', border: 'rgba(202,138,4,0.3)', text: '#eab308' },
    'stale': { bg: '#1f2937', border: 'rgba(75,85,99,0.3)', text: '#9ca3af' },
    'ограничение': { bg: '#7f1d1d', border: 'rgba(220,38,38,0.3)', text: '#ef4444' },
    'изменён': { bg: '#0c4a6e', border: 'rgba(14,165,233,0.3)', text: '#38bdf8' },
  };

  const config = configs[flag] || { bg: '#1f2937', border: 'rgba(75,85,99,0.3)', text: '#9ca3af' };

  return (
    <span
      className="inline-block font-['JetBrains_Mono',monospace] text-[9px] rounded px-1.5 py-0.5"
      style={{
        backgroundColor: config.bg,
        border: `1px solid ${config.border}`,
        color: config.text
      }}
    >
      {flag}
    </span>
  );
}

function TogglePill({ checked }: { checked: boolean }) {
  return (
    <div
      className={`w-7 h-4 rounded-lg relative transition-all duration-200 cursor-pointer hover:scale-110 ${
        checked ? 'bg-[rgba(99,102,241,0.75)]' : 'bg-[#2d333e]'
      }`}
    >
      <div
        className={`absolute top-0.5 w-3 h-3 rounded-md transition-all duration-200 ${
          checked ? 'left-[14px] bg-white' : 'left-0.5 bg-[#6b7280]'
        }`}
      />
    </div>
  );
}

function ActionButton({ action, dataStatus }: { action: string; dataStatus: string }) {
  const colorMap: Record<string, string> = {
    'Открыть': '#6366f1',
    'Дозагрузить': '#eab308',
    'Загрузить': '#6366f1',
    'Проверить': '#eab308',
  };

  const color = colorMap[action] || '#6366f1';

  return (
    <button
      className="text-[12px] font-bold hover:translate-x-0.5 transition-all duration-200"
      style={{ color }}
    >
      {action}
    </button>
  );
}
