import { useState } from 'react';
import { Sidebar } from '../Sidebar';
import { Topbar } from '../Topbar';

export function FuturesCatalog() {
  const [activeTab, setActiveTab] = useState<'all' | 'stocks' | 'futures'>('futures');

  const futures = [
    {
      secid: 'SiM6',
      shortname: 'Фьюч. USD/RUB',
      assetCode: 'Si',
      expiration: '20.06.26',
      daysToExpiry: 12,
      initialMargin: '15 420 ₽',
      commission: '3.21 ₽',
      dataStatus: 'частично',
      loaded: ['candles', 'futoi'],
      period: '01.12—31.12',
      coverage: 88,
      flags: ['экспирация'],
      watched: true,
      action: 'Открыть'
    },
    {
      secid: 'SiU6',
      shortname: 'Фьюч. USD/RUB',
      assetCode: 'Si',
      expiration: '19.09.26',
      daysToExpiry: 102,
      initialMargin: '15 420 ₽',
      commission: '3.21 ₽',
      dataStatus: 'не загружено',
      loaded: [],
      period: '—',
      coverage: 0,
      flags: ['только asset_code'],
      watched: false,
      action: 'Загрузить'
    },
    {
      secid: 'SiZ6',
      shortname: 'Фьюч. USD/RUB',
      assetCode: 'Si',
      expiration: '18.12.26',
      daysToExpiry: 192,
      initialMargin: '15 420 ₽',
      commission: '—',
      dataStatus: 'не загружено',
      loaded: [],
      period: '—',
      coverage: 0,
      flags: ['не обогащён'],
      watched: false,
      action: 'Загрузить'
    },
    {
      secid: 'BRN6',
      shortname: 'Фьюч. Brent',
      assetCode: 'BR',
      expiration: '01.07.26',
      daysToExpiry: 23,
      initialMargin: '8 200 ₽',
      commission: '2.00 ₽',
      dataStatus: 'загружено',
      loaded: ['candles', 'futoi'],
      period: '01.12—31.12',
      coverage: 100,
      flags: [],
      watched: true,
      action: 'Открыть'
    },
    {
      secid: 'GOLD-6.26',
      shortname: 'Фьюч. золото',
      assetCode: 'GOLD',
      expiration: '15.06.26',
      daysToExpiry: 7,
      initialMargin: '22 100 ₽',
      commission: '5.50 ₽',
      dataStatus: 'частично',
      loaded: ['candles'],
      period: '15.12—31.12',
      coverage: 52,
      flags: ['экспирация'],
      watched: true,
      action: 'Дозагрузить'
    },
  ];

  return (
    <div className="min-h-screen bg-[#0b0d10] font-['Inter',sans-serif]">
      <Sidebar activePage="instruments" />

      <div className="ml-[220px] min-h-screen">
        <Topbar liveStatus="live" />

        <div className="p-8">
          {/* Breadcrumb */}
          <div className="mb-6 text-[12px]">
            <span className="text-[#6b7280]">DATA OPS / Инструменты / </span>
            <span className="text-[13px] font-bold text-[#e6e8ec]">Фьючерсы</span>
          </div>

          {/* Header */}
          <div className="mb-6">
            <h1 className="text-[32px] font-semibold tracking-[-0.02em] text-[#e6e8ec] mb-2">
              Каталог инструментов
            </h1>
            <p className="text-[13px] text-[#9ba1ad]">
              Центральный реестр торговых инструментов и их данных
            </p>
          </div>

          {/* Tabs */}
          <div className="mb-6">
            <div className="flex items-center gap-6 border-b border-[#1a1e25]">
              <button
                onClick={() => setActiveTab('all')}
                className={`pb-3 text-[13px] transition-all duration-200 ${
                  activeTab === 'all'
                    ? 'font-bold text-[#e6e8ec] border-b-2 border-[#6366f1]'
                    : 'text-[#9ba1ad] hover:text-[#c2c8d2]'
                }`}
              >
                Все
              </button>
              <button
                onClick={() => setActiveTab('stocks')}
                className={`pb-3 text-[13px] transition-all duration-200 ${
                  activeTab === 'stocks'
                    ? 'font-bold text-[#e6e8ec] border-b-2 border-[#6366f1]'
                    : 'text-[#9ba1ad] hover:text-[#c2c8d2]'
                }`}
              >
                Акции
              </button>
              <button
                onClick={() => setActiveTab('futures')}
                className={`pb-3 text-[13px] transition-all duration-200 ${
                  activeTab === 'futures'
                    ? 'font-bold text-[#e6e8ec] border-b-2 border-[#6366f1]'
                    : 'text-[#9ba1ad] hover:text-[#c2c8d2]'
                }`}
              >
                Фьючерсы
              </button>
            </div>
          </div>

          {/* Filters */}
          <div className="mb-6 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <select className="bg-[#14171c] border border-[#2d333e] rounded-md text-[13px] text-[#9ba1ad] px-3 py-2 hover:border-[#6366f1]/50 transition-colors">
                <option>Базовый актив ▾</option>
              </select>
              <select className="bg-[#14171c] border border-[#2d333e] rounded-md text-[13px] text-[#9ba1ad] px-3 py-2 hover:border-[#6366f1]/50 transition-colors">
                <option>Статус данных ▾</option>
              </select>
              <select className="bg-[#14171c] border border-[#2d333e] rounded-md text-[13px] text-[#9ba1ad] px-3 py-2 hover:border-[#6366f1]/50 transition-colors">
                <option>Что загружено ▾</option>
              </select>
              <select className="bg-[#14171c] border border-[#2d333e] rounded-md text-[13px] text-[#9ba1ad] px-3 py-2 hover:border-[#6366f1]/50 transition-colors">
                <option>Флаги ▾</option>
              </select>
              <select className="bg-[#14171c] border border-[#2d333e] rounded-md text-[13px] text-[#9ba1ad] px-3 py-2 hover:border-[#6366f1]/50 transition-colors">
                <option>Отслеживание ▾</option>
              </select>
              <input
                type="text"
                placeholder="Поиск secid, названия или asset_code (Si, BR)"
                className="bg-[#14171c] border border-[#2d333e] rounded-md text-[12px] text-[#e6e8ec] placeholder-[#6b7280] px-3 py-2 w-[320px] hover:border-[#6366f1]/50 focus:border-[#6366f1] outline-none transition-colors"
              />
            </div>
            <button className="text-[12px] text-[#6b7280] hover:text-[#9ba1ad] transition-colors">
              Сбросить фильтры
            </button>
          </div>

          {/* Table */}
          <div
            className="bg-[#14171c] border border-[#232831] rounded-xl overflow-hidden"
            style={{
              boxShadow: '0 6px 16px -3px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.035)'
            }}
          >
            {/* Table Caption */}
            <div className="bg-[#0b0d10] px-6 py-3 border-b border-[#232831] flex items-center gap-2">
              <span className="text-[11px] font-bold tracking-[0.14em] uppercase text-[#6b7280]">ФЬЮЧЕРСЫ</span>
              <span className="font-['JetBrains_Mono',monospace] text-[11px] text-[#9ba1ad]">64</span>
            </div>

            {/* Table Header */}
            <div className="bg-[#0b0d10] px-6 py-3.5 flex items-center gap-4 border-b border-[#232831]">
              <div className="w-[140px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ИНСТРУМЕНТ</div>
              <div className="w-[90px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">БАЗОВЫЙ АКТИВ</div>
              <div className="w-[90px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ЭКСПИРАЦИЯ</div>
              <div className="w-[50px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280] text-right">ДН</div>
              <div className="w-[90px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280] text-right">ГО</div>
              <div className="w-[80px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280] text-right">КОМИССИЯ</div>
              <div className="w-[140px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">СТАТУС ДАННЫХ</div>
              <div className="w-[180px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ЧТО ЗАГРУЖЕНО</div>
              <div className="w-[120px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ПЕРИОД</div>
              <div className="w-[90px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ПОКРЫТИЕ</div>
              <div className="w-[140px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ФЛАГИ</div>
              <div className="w-[70px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ОТСЛЕЖ.</div>
              <div className="w-[100px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ДЕЙСТВИЕ</div>
            </div>

            {/* Table Rows */}
            <div className="bg-[#0b0d10]">
              {futures.map((future, i) => {
                const isNotLoaded = future.dataStatus === 'не загружено';

                return (
                  <div key={future.secid}>
                    <div
                      className="flex items-center gap-4 px-6 py-4 hover:bg-[#181c22] transition-colors cursor-pointer group"
                    >
                      {/* ИНСТРУМЕНТ */}
                      <div className="w-[140px]">
                        <div className={`text-[13px] font-bold leading-none mb-1 ${isNotLoaded ? 'text-[#6b7280]' : 'text-[#e6e8ec]'}`}>
                          {future.secid}
                        </div>
                        <div className={`font-['JetBrains_Mono',monospace] text-[10px] ${isNotLoaded ? 'text-[#3e4451]' : 'text-[#6b7280]'}`}>
                          {future.shortname}
                        </div>
                      </div>

                      {/* БАЗОВЫЙ АКТИВ */}
                      <div className={`w-[90px] font-['JetBrains_Mono',monospace] text-[13px] font-bold ${isNotLoaded ? 'text-[#3e4451]' : 'text-[#e6e8ec]'}`}>
                        {future.assetCode}
                      </div>

                      {/* ЭКСПИРАЦИЯ */}
                      <div className={`w-[90px] font-['JetBrains_Mono',monospace] text-[12px] ${isNotLoaded ? 'text-[#3e4451]' : 'text-[#9ba1ad]'}`}>
                        {future.expiration}
                      </div>

                      {/* ДН (дни до экспирации) */}
                      <div className="w-[50px] text-right">
                        <DaysToExpiry days={future.daysToExpiry} isNotLoaded={isNotLoaded} />
                      </div>

                      {/* ГО (гарантийное обеспечение) */}
                      <div className={`w-[90px] font-['JetBrains_Mono',monospace] text-[12px] text-right ${isNotLoaded ? 'text-[#3e4451]' : 'text-[#9ba1ad]'}`}>
                        {future.initialMargin}
                      </div>

                      {/* КОМИССИЯ */}
                      <div className={`w-[80px] font-['JetBrains_Mono',monospace] text-[12px] text-right ${
                        future.commission === '—' ? 'text-[#3e4451]' : isNotLoaded ? 'text-[#3e4451]' : 'text-[#9ba1ad]'
                      }`}>
                        {future.commission}
                      </div>

                      {/* СТАТУС ДАННЫХ */}
                      <div className="w-[140px]">
                        <DataStatusBadge status={future.dataStatus} />
                      </div>

                      {/* ЧТО ЗАГРУЖЕНО */}
                      <div className="w-[180px] flex flex-wrap gap-1.5">
                        {future.loaded.length > 0 ? (
                          future.loaded.map((item) => (
                            <span
                              key={item}
                              className="inline-block font-['JetBrains_Mono',monospace] text-[10px] text-[#9ba1ad] bg-[#0b0d10] border border-[#232831] rounded px-1.5 py-0.5"
                            >
                              {item}
                            </span>
                          ))
                        ) : (
                          <span className="text-[#3e4451]">—</span>
                        )}
                      </div>

                      {/* ПЕРИОД */}
                      <div className={`w-[120px] font-['JetBrains_Mono',monospace] text-[12px] ${isNotLoaded ? 'text-[#3e4451]' : 'text-[#9ba1ad]'}`}>
                        {future.period}
                      </div>

                      {/* ПОКРЫТИЕ */}
                      <div className="w-[90px]">
                        <CoverageDisplay coverage={future.coverage} />
                      </div>

                      {/* ФЛАГИ */}
                      <div className="w-[140px] flex flex-wrap gap-1.5">
                        {future.flags.length > 0 ? (
                          future.flags.map((flag) => (
                            <FlagBadge key={flag} flag={flag} />
                          ))
                        ) : (
                          <span className="text-[#3e4451]">—</span>
                        )}
                      </div>

                      {/* ОТСЛЕЖ. */}
                      <div className="w-[70px]">
                        <TogglePill checked={future.watched} />
                      </div>

                      {/* ДЕЙСТВИЕ */}
                      <div className="w-[100px]">
                        <ActionButton action={future.action} dataStatus={future.dataStatus} />
                      </div>
                    </div>
                    {i < futures.length - 1 && (
                      <div className="h-px bg-[#1a1e25]" />
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function DaysToExpiry({ days, isNotLoaded }: { days: number; isNotLoaded: boolean }) {
  if (isNotLoaded) {
    return (
      <span className="font-['JetBrains_Mono',monospace] text-[13px] font-medium text-[#3e4451] tabular-nums">
        {days}
      </span>
    );
  }

  let color = '#9ba1ad';
  if (days < 14) {
    color = '#ef4444';
  } else if (days <= 30) {
    color = '#eab308';
  }

  return (
    <span
      className="font-['JetBrains_Mono',monospace] text-[13px] font-medium tabular-nums"
      style={{ color }}
    >
      {days}
    </span>
  );
}

function DataStatusBadge({ status }: { status: string }) {
  const configs: Record<string, { bg: string; border: string; dot: string; text: string; label: string }> = {
    'загружено': { bg: '#14532d', border: 'rgba(22,163,74,0.4)', dot: '#22c55e', text: '#22c55e', label: 'загружено' },
    'частично': { bg: '#713f12', border: 'rgba(202,138,4,0.4)', dot: '#eab308', text: '#eab308', label: 'частично' },
    'не загружено': { bg: '#1f2937', border: 'rgba(75,85,99,0.4)', dot: '#9ca3af', text: '#9ca3af', label: 'не загружено' },
    'требует проверки': { bg: '#713f12', border: 'rgba(202,138,4,0.4)', dot: '#eab308', text: '#eab308', label: 'требует проверки' },
  };

  const config = configs[status] || configs['не загружено'];

  return (
    <div
      className="inline-flex items-center gap-1.5 py-[3px] pl-[7px] pr-[9px] rounded"
      style={{
        backgroundColor: config.bg,
        border: `1px solid ${config.border}`
      }}
    >
      <div className="w-[5px] h-[5px] rounded-sm" style={{ backgroundColor: config.dot }} />
      <span className="text-[11px] font-medium" style={{ color: config.text }}>{config.label}</span>
    </div>
  );
}

function CoverageDisplay({ coverage }: { coverage: number }) {
  const color = coverage === 100 ? '#22c55e' : coverage > 0 ? '#eab308' : '#3e4451';

  return (
    <span
      className="font-['JetBrains_Mono',monospace] text-[13px] font-medium tabular-nums"
      style={{ color }}
    >
      {coverage}%
    </span>
  );
}

function FlagBadge({ flag }: { flag: string }) {
  const configs: Record<string, { bg: string; border: string; text: string }> = {
    'не обогащён': { bg: '#713f12', border: 'rgba(202,138,4,0.3)', text: '#eab308' },
    'обогащение частично': { bg: '#713f12', border: 'rgba(202,138,4,0.3)', text: '#eab308' },
    'stale': { bg: '#1f2937', border: 'rgba(75,85,99,0.3)', text: '#9ca3af' },
    'ограничение': { bg: '#7f1d1d', border: 'rgba(220,38,38,0.3)', text: '#ef4444' },
    'изменён': { bg: '#0c4a6e', border: 'rgba(14,165,233,0.3)', text: '#38bdf8' },
    'экспирация': { bg: '#7f1d1d', border: 'rgba(220,38,38,0.3)', text: '#ef4444' },
    'нет связи': { bg: '#1f2937', border: 'rgba(75,85,99,0.3)', text: '#9ca3af' },
    'только asset_code': { bg: '#0c4a6e', border: 'rgba(14,165,233,0.3)', text: '#38bdf8' },
  };

  const config = configs[flag] || { bg: '#1f2937', border: 'rgba(75,85,99,0.3)', text: '#9ca3af' };

  return (
    <span
      className="inline-block font-['JetBrains_Mono',monospace] text-[9px] rounded px-1.5 py-0.5"
      style={{
        backgroundColor: config.bg,
        border: `1px solid ${config.border}`,
        color: config.text
      }}
    >
      {flag}
    </span>
  );
}

function TogglePill({ checked }: { checked: boolean }) {
  return (
    <div
      className={`w-7 h-4 rounded-lg relative transition-all duration-200 cursor-pointer hover:scale-110 ${
        checked ? 'bg-[rgba(99,102,241,0.75)]' : 'bg-[#2d333e]'
      }`}
    >
      <div
        className={`absolute top-0.5 w-3 h-3 rounded-md transition-all duration-200 ${
          checked ? 'left-[14px] bg-white' : 'left-0.5 bg-[#6b7280]'
        }`}
      />
    </div>
  );
}

function ActionButton({ action, dataStatus }: { action: string; dataStatus: string }) {
  const colorMap: Record<string, string> = {
    'Открыть': '#6366f1',
    'Дозагрузить': '#eab308',
    'Загрузить': '#6366f1',
    'Проверить': '#eab308',
  };

  const color = colorMap[action] || '#6366f1';

  return (
    <button
      className="text-[12px] font-bold hover:translate-x-0.5 transition-all duration-200"
      style={{ color }}
    >
      {action}
    </button>
  );
}
