import { Sidebar } from '../Sidebar';
import { Topbar } from '../Topbar';

export function StockCard() {
  return (
    <div className="min-h-screen bg-[#0b0d10] font-['Inter',sans-serif]">
      <Sidebar activePage="instruments" />

      <div className="ml-[220px] min-h-screen">
        <Topbar liveStatus="live" breadcrumb="DATA OPS / Инструменты / SBER" />

        <div className="p-8">
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex items-start justify-between mb-6">
              <div className="flex items-start gap-3">
                <div>
                  <h1 className="text-[24px] font-bold text-[#e6e8ec] mb-1">SBER</h1>
                  <p className="text-[13px] text-[#9ba1ad]">Сбербанк · акция · TQBR</p>
                </div>
                <DataStatusBadge status="частично" />
              </div>

              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2 mr-4">
                  <span className="text-[12px] text-[#9ba1ad]">Отслеживание</span>
                  <TogglePill checked={true} />
                </div>
                <button
                  className="px-5 py-2.5 bg-[#6366f1] rounded-lg text-[13px] font-bold text-white hover:bg-[#5558e3] transition-all duration-200"
                  style={{
                    boxShadow: '0 4px 12px -2px rgba(99,102,241,0.3), inset 0 1px 0 rgba(255,255,255,0.18)'
                  }}
                >
                  Создать задание
                </button>
                <button className="px-5 py-2.5 bg-transparent border border-[#2d333e] rounded-lg text-[13px] font-bold text-[#e6e8ec] hover:border-[#6366f1]/50 hover:bg-[#16191f] transition-all duration-200">
                  Обогатить карточку
                </button>
              </div>
            </div>

            {/* Mini Metrics */}
            <div className="flex items-center gap-8">
              <MiniMetric label="Покрытие" value="92%" valueColor="#eab308" />
              <MiniMetric label="Загружено типов" value="3 из 5" />
              <MiniMetric label="Последнее обновление" value="09:42" />
              <MiniMetric label="Дней без обновления" value="0" />
            </div>
          </div>

          {/* Section 1: Параметры карточки */}
          <div className="mb-8">
            <h2 className="text-[10px] font-semibold tracking-[0.14em] uppercase text-[#6b7280] mb-3">
              ПАРАМЕТРЫ
            </h2>
            <div
              className="bg-[#14171c] border border-[#232831] rounded-xl p-6"
              style={{
                boxShadow: '0 6px 16px -3px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.035)'
              }}
            >
              <div className="grid grid-cols-2 gap-x-16 gap-y-5">
                <ParamField label="Режим" value="TQBR" />
                <ParamField label="Валюта" value="RUB" />
                <ParamField label="Листинг" value="1" />
                <ParamField label="ISIN" value="RU0009029540" />
                <ParamField label="Лот" value="10" />
                <ParamField label="Шаг цены" value="0.01" />
                <ParamField label="Номинал" value="3.00 ₽" />
                <ParamField label="Статус торгов" value="active" />
              </div>

              {/* Warning Banner */}
              <div className="mt-6 flex items-start gap-3 bg-[#713f12]/20 border border-[rgba(202,138,4,0.3)] rounded-lg p-4">
                <div className="w-[3px] h-full bg-[#eab308] rounded-full shrink-0" />
                <div className="flex-1">
                  <p className="text-[12px] text-[#eab308] mb-2">
                    Карточка обогащена частично. Проверьте недостающие поля MarketStatistics.
                  </p>
                  <button className="text-[12px] font-medium text-[#6366f1] hover:text-[#8084f4]">
                    Обогатить карточку →
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Section 2: Покрытие данных */}
          <div className="mb-8">
            <div className="flex items-center gap-2 mb-3">
              <h2 className="text-[10px] font-semibold tracking-[0.14em] uppercase text-[#6b7280]">
                ПОКРЫТИЕ ДАННЫХ
              </h2>
              <span className="text-[11px] text-[#9ba1ad]">3 из 5 типов загружено</span>
            </div>
            <div
              className="bg-[#14171c] border border-[#232831] rounded-xl overflow-hidden"
              style={{
                boxShadow: '0 6px 16px -3px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.035)'
              }}
            >
              {/* Table Header */}
              <div className="bg-[#0b0d10] px-6 py-3.5 flex items-center gap-4 border-b border-[#232831]">
                <div className="w-[120px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ТИП ДАННЫХ</div>
                <div className="w-[100px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ИНТЕРВАЛ</div>
                <div className="w-[140px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ПЕРИОД</div>
                <div className="w-[100px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280] text-right">СТРОК</div>
                <div className="w-[120px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ХРАНИЛИЩЕ</div>
                <div className="w-[120px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">СТАТУС</div>
                <div className="w-[100px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ОБНОВЛЕНО</div>
                <div className="w-[140px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ДЕЙСТВИЕ</div>
              </div>

              {/* Table Body */}
              <div className="bg-[#0b0d10]">
                <DataCoverageRow
                  type="candles"
                  interval="1m"
                  period="01.12—31.12"
                  rows="22 341"
                  storage="file"
                  status="ok"
                  updated="09:42"
                  action="Открыть задания"
                />
                <DataCoverageRow
                  type="tradestats"
                  interval="—"
                  period="01.12—31.12"
                  rows="18 902"
                  storage="file"
                  status="ok"
                  updated="09:41"
                  action="Открыть задания"
                />
                <DataCoverageRow
                  type="orderstats"
                  interval="—"
                  period="01.12—31.12"
                  rows="16 320"
                  storage="file"
                  status="ok"
                  updated="09:40"
                  action="Открыть задания"
                />
                <DataCoverageRow
                  type="obstats"
                  interval="—"
                  period="—"
                  rows="—"
                  storage="—"
                  status="не загружено"
                  updated="—"
                  action="Загрузить"
                />
                <DataCoverageRow
                  type="securities"
                  interval="—"
                  period="актуально"
                  rows="—"
                  storage="PostgreSQL"
                  status="ok"
                  updated="сегодня"
                  action="Обновить"
                  isLast
                />
              </div>
            </div>
          </div>

          {/* Section 3: Пропуски */}
          <div className="mb-8">
            <div className="flex items-center gap-2 mb-3">
              <h2 className="text-[10px] font-semibold tracking-[0.14em] uppercase text-[#6b7280]">
                ПРОПУСКИ
              </h2>
              <span className="text-[11px] text-[#eab308]">1 пропущенный день</span>
            </div>
            <div
              className="bg-[#14171c] border border-[#232831] rounded-xl p-6"
              style={{
                boxShadow: '0 6px 16px -3px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.035)'
              }}
            >
              <div className="flex items-start gap-2 mb-2">
                <div className="w-[5px] h-[5px] rounded-sm bg-[#eab308] mt-1.5" />
                <p className="text-[12px] text-[#eab308]">
                  14.12 — торговый день, данные candles отсутствуют
                </p>
              </div>
              <button className="text-[12px] font-medium text-[#6366f1] hover:text-[#8084f4] ml-3.5">
                Дозагрузить 14.12 →
              </button>
            </div>
          </div>

          {/* Section 4: Связи */}
          <div className="mb-8">
            <div className="flex items-center gap-2 mb-3">
              <h2 className="text-[10px] font-semibold tracking-[0.14em] uppercase text-[#6b7280]">
                СВЯЗИ
              </h2>
              <span className="text-[11px] text-[#9ba1ad]">2 связанных инструмента</span>
            </div>
            <div
              className="bg-[#14171c] border border-[#232831] rounded-xl overflow-hidden"
              style={{
                boxShadow: '0 6px 16px -3px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.035)'
              }}
            >
              {/* Table Header */}
              <div className="bg-[#0b0d10] px-6 py-3.5 flex items-center gap-4 border-b border-[#232831]">
                <div className="w-[140px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ИНСТРУМЕНТ</div>
                <div className="flex-1 text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ТИП СВЯЗИ</div>
                <div className="w-[120px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">CONFIDENCE</div>
                <div className="w-[120px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ДЕЙСТВИЕ</div>
              </div>

              {/* Table Body */}
              <div className="bg-[#0b0d10]">
                <RelationRow
                  instrument="SBRF-6.26"
                  relationType="фьючерс на базовый актив"
                  confidence="auto"
                />
                <RelationRow
                  instrument="SBRF-9.26"
                  relationType="фьючерс на базовый актив"
                  confidence="auto"
                  isLast
                />
              </div>
            </div>
          </div>

          {/* Section 5: Ограничения и изменения */}
          <div className="mb-8">
            <h2 className="text-[10px] font-semibold tracking-[0.14em] uppercase text-[#6b7280] mb-3">
              ОГРАНИЧЕНИЯ И ИЗМЕНЕНИЯ
            </h2>
            <div
              className="bg-[#14171c] border border-[#232831] rounded-xl p-6 mb-4"
              style={{
                boxShadow: '0 6px 16px -3px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.035)'
              }}
            >
              <h3 className="text-[11px] font-semibold text-[#9ba1ad] mb-3">Приостановки</h3>
              <div className="flex items-center gap-2">
                <div className="w-[5px] h-[5px] rounded-sm bg-[#22c55e]" />
                <span className="text-[12px] text-[#9ba1ad]">Активных приостановок нет</span>
              </div>
            </div>

            <div
              className="bg-[#14171c] border border-[#232831] rounded-xl overflow-hidden"
              style={{
                boxShadow: '0 6px 16px -3px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.035)'
              }}
            >
              <div className="px-6 py-4 border-b border-[#232831]">
                <h3 className="text-[11px] font-semibold text-[#9ba1ad]">Изменения атрибутов (последние 3)</h3>
              </div>

              {/* Table Header */}
              <div className="bg-[#0b0d10] px-6 py-3.5 flex items-center gap-4 border-b border-[#232831]">
                <div className="w-[120px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ДАТА</div>
                <div className="w-[140px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">АТРИБУТ</div>
                <div className="w-[120px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">БЫЛО</div>
                <div className="w-[120px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">СТАЛО</div>
                <div className="w-[100px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ДЕЙСТВИЕ</div>
              </div>

              {/* Table Body */}
              <div className="bg-[#0b0d10]">
                <ChangeRow
                  date="2 дня назад"
                  attribute="LISTLEVEL"
                  from="2"
                  to="1"
                  action="updated"
                />
                <ChangeRow
                  date="5 дней назад"
                  attribute="LOTSIZE"
                  from="100"
                  to="10"
                  action="updated"
                  isLast
                />
              </div>

              <div className="px-6 py-4 border-t border-[#232831]">
                <button className="text-[12px] font-medium text-[#6366f1] hover:text-[#8084f4]">
                  История изменений →
                </button>
              </div>
            </div>
          </div>

          {/* Section 6: Последние действия */}
          <div className="mb-8">
            <h2 className="text-[10px] font-semibold tracking-[0.14em] uppercase text-[#6b7280] mb-3">
              ПОСЛЕДНИЕ ДЕЙСТВИЯ
            </h2>
            <div
              className="bg-[#14171c] border border-[#232831] rounded-xl p-6"
              style={{
                boxShadow: '0 6px 16px -3px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.035)'
              }}
            >
              <div className="space-y-3">
                <ActionItem time="09:42" description="candles загружены успешно · 22 341 строк" />
                <ActionItem time="09:41" description="tradestats загружены · 18 902 строк" />
                <ActionItem time="09:40" description="orderstats загружены · 16 320 строк" />
                <ActionItem time="вчера" description="справочник instruments обновлён" />
                <ActionItem time="вчера" description="MarketStatistics выполнен частично · часть полей не получена" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function MiniMetric({ label, value, valueColor }: { label: string; value: string; valueColor?: string }) {
  return (
    <div>
      <div className="text-[9px] font-semibold tracking-[0.14em] uppercase text-[#6b7280] mb-1.5">
        {label}
      </div>
      <div
        className="font-['JetBrains_Mono',monospace] text-[13px] font-medium"
        style={{ color: valueColor || '#e6e8ec' }}
      >
        {value}
      </div>
    </div>
  );
}

function ParamField({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-[11px] text-[#6b7280] mb-1.5">{label}</div>
      <div className="text-[13px] text-[#e6e8ec]">{value}</div>
    </div>
  );
}

function DataCoverageRow({
  type,
  interval,
  period,
  rows,
  storage,
  status,
  updated,
  action,
  isLast = false
}: {
  type: string;
  interval: string;
  period: string;
  rows: string;
  storage: string;
  status: string;
  updated: string;
  action: string;
  isLast?: boolean;
}) {
  const statusColor = status === 'ok' ? '#22c55e' : status === 'partial' ? '#eab308' : '#9ca3af';

  return (
    <>
      <div className="flex items-center gap-4 px-6 py-4 hover:bg-[#181c22] transition-colors">
        <div className="w-[120px] font-['JetBrains_Mono',monospace] text-[12px] text-[#e6e8ec]">{type}</div>
        <div className="w-[100px] font-['JetBrains_Mono',monospace] text-[11px] text-[#9ba1ad]">{interval}</div>
        <div className="w-[140px] font-['JetBrains_Mono',monospace] text-[11px] text-[#9ba1ad]">{period}</div>
        <div className="w-[100px] font-['JetBrains_Mono',monospace] text-[13px] font-medium text-[#e6e8ec] text-right tabular-nums">
          {rows}
        </div>
        <div className="w-[120px] font-['JetBrains_Mono',monospace] text-[10px] text-[#6b7280]">{storage}</div>
        <div className="w-[120px]">
          <span className="text-[11px]" style={{ color: statusColor }}>● {status}</span>
        </div>
        <div className="w-[100px] font-['JetBrains_Mono',monospace] text-[11px] text-[#9ba1ad]">{updated}</div>
        <div className="w-[140px]">
          <button className="text-[11px] text-[#6366f1] hover:text-[#8084f4]">{action}</button>
        </div>
      </div>
      {!isLast && <div className="h-px bg-[#1a1e25]" />}
    </>
  );
}

function RelationRow({
  instrument,
  relationType,
  confidence,
  isLast = false
}: {
  instrument: string;
  relationType: string;
  confidence: string;
  isLast?: boolean;
}) {
  const confidenceColor = confidence === 'auto' ? '#22c55e' : '#38bdf8';

  return (
    <>
      <div className="flex items-center gap-4 px-6 py-4 hover:bg-[#181c22] transition-colors">
        <div className="w-[140px] text-[13px] font-bold text-[#e6e8ec]">{instrument}</div>
        <div className="flex-1 text-[12px] text-[#9ba1ad]">{relationType}</div>
        <div className="w-[120px]">
          <span
            className="font-['JetBrains_Mono',monospace] text-[10px]"
            style={{ color: confidenceColor }}
          >
            {confidence}
          </span>
        </div>
        <div className="w-[120px]">
          <button className="text-[11px] text-[#6366f1] hover:text-[#8084f4]">Открыть</button>
        </div>
      </div>
      {!isLast && <div className="h-px bg-[#1a1e25]" />}
    </>
  );
}

function ChangeRow({
  date,
  attribute,
  from,
  to,
  action,
  isLast = false
}: {
  date: string;
  attribute: string;
  from: string;
  to: string;
  action: string;
  isLast?: boolean;
}) {
  return (
    <>
      <div className="flex items-center gap-4 px-6 py-4 hover:bg-[#181c22] transition-colors">
        <div className="w-[120px] font-['JetBrains_Mono',monospace] text-[11px] text-[#6b7280]">{date}</div>
        <div className="w-[140px] font-['JetBrains_Mono',monospace] text-[13px] text-[#e6e8ec]">{attribute}</div>
        <div className="w-[120px] text-[13px] text-[#9ba1ad]">{from}</div>
        <div className="w-[120px] text-[13px] text-[#9ba1ad]">{to}</div>
        <div className="w-[100px] text-[10px] text-[#6b7280]">{action}</div>
      </div>
      {!isLast && <div className="h-px bg-[#1a1e25]" />}
    </>
  );
}

function ActionItem({ time, description }: { time: string; description: string }) {
  return (
    <div className="flex items-start gap-3">
      <span className="font-['JetBrains_Mono',monospace] text-[11px] text-[#6b7280] shrink-0">{time}</span>
      <span className="text-[12px] text-[#9ba1ad]">{description}</span>
    </div>
  );
}

function DataStatusBadge({ status }: { status: string }) {
  const configs: Record<string, { bg: string; border: string; dot: string; text: string; label: string }> = {
    'загружено': { bg: '#14532d', border: 'rgba(22,163,74,0.4)', dot: '#22c55e', text: '#22c55e', label: 'загружено' },
    'частично': { bg: '#713f12', border: 'rgba(202,138,4,0.4)', dot: '#eab308', text: '#eab308', label: 'частично' },
    'не загружено': { bg: '#1f2937', border: 'rgba(75,85,99,0.4)', dot: '#9ca3af', text: '#9ca3af', label: 'не загружено' },
    'требует проверки': { bg: '#713f12', border: 'rgba(202,138,4,0.4)', dot: '#eab308', text: '#eab308', label: 'требует проверки' },
  };

  const config = configs[status] || configs['не загружено'];

  return (
    <div
      className="inline-flex items-center gap-1.5 py-[3px] pl-[7px] pr-[9px] rounded"
      style={{
        backgroundColor: config.bg,
        border: `1px solid ${config.border}`
      }}
    >
      <div className="w-[5px] h-[5px] rounded-sm" style={{ backgroundColor: config.dot }} />
      <span className="text-[11px] font-medium" style={{ color: config.text }}>{config.label}</span>
    </div>
  );
}

function TogglePill({ checked }: { checked: boolean }) {
  return (
    <div
      className={`w-7 h-4 rounded-lg relative transition-all duration-200 cursor-pointer hover:scale-110 ${
        checked ? 'bg-[rgba(99,102,241,0.75)]' : 'bg-[#2d333e]'
      }`}
    >
      <div
        className={`absolute top-0.5 w-3 h-3 rounded-md transition-all duration-200 ${
          checked ? 'left-[14px] bg-white' : 'left-0.5 bg-[#6b7280]'
        }`}
      />
    </div>
  );
}
