import { Sidebar } from '../Sidebar';
import { Topbar } from '../Topbar';

export function FutureCard() {
  return (
    <div className="min-h-screen bg-[#0b0d10] font-['Inter',sans-serif]">
      <Sidebar activePage="instruments" />

      <div className="ml-[220px] min-h-screen">
        <Topbar liveStatus="live" breadcrumb="DATA OPS / Инструменты / SiM6" />

        <div className="p-8">
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex items-start justify-between mb-6">
              <div className="flex items-start gap-3">
                <div>
                  <h1 className="text-[24px] font-bold text-[#e6e8ec] mb-1">SiM6</h1>
                  <p className="text-[13px] text-[#9ba1ad] mb-2">Фьючерс USD/RUB · Si · RFUD</p>
                  <div className="flex items-center gap-3">
                    <DataStatusBadge status="частично" />
                    <span className="text-[12px] font-bold text-[#ef4444]">12 дней до экспирации</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <button
                  className="px-5 py-2.5 bg-[#6366f1] rounded-lg text-[13px] font-bold text-white hover:bg-[#5558e3] transition-all duration-200"
                  style={{
                    boxShadow: '0 4px 12px -2px rgba(99,102,241,0.3), inset 0 1px 0 rgba(255,255,255,0.18)'
                  }}
                >
                  Создать задание
                </button>
                <button className="px-5 py-2.5 bg-transparent border border-[#2d333e] rounded-lg text-[13px] font-bold text-[#e6e8ec] hover:border-[#6366f1]/50 hover:bg-[#16191f] transition-all duration-200">
                  Обогатить карточку
                </button>
              </div>
            </div>

            {/* Mini Metrics */}
            <div className="flex items-center gap-8">
              <MiniMetric label="Покрытие" value="88%" valueColor="#eab308" />
              <MiniMetric label="Загружено типов" value="2 из 3" />
              <MiniMetric label="До экспирации" value="12 дн" valueColor="#ef4444" />
              <MiniMetric label="Откр. интерес" value="1 245 000" />
            </div>
          </div>

          {/* Section 1: Параметры карточки фьючерса */}
          <div className="mb-8">
            <h2 className="text-[10px] font-semibold tracking-[0.14em] uppercase text-[#6b7280] mb-3">
              ПАРАМЕТРЫ
            </h2>
            <div
              className="bg-[#14171c] border border-[#232831] rounded-xl p-6"
              style={{
                boxShadow: '0 6px 16px -3px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.035)'
              }}
            >
              <div className="grid grid-cols-2 gap-x-16 gap-y-5">
                <ParamField label="Базовый актив" value="Si" />
                <ParamField label="Объём лота" value="1" />
                <ParamField label="Режим" value="RFUD" />
                <ParamField label="Шаг цены" value="1" />
                <ParamField label="Экспирация" value="20.06.2026" />
                <ParamField label="Цена шага" value="1.00 ₽" />
                <ParamField label="Дата поставки" value="22.06.2026" />
                <ParamField label="Верхний лимит" value="98 500" />
                <ParamField label="ГО" value="15 420 ₽" />
                <ParamField label="Нижний лимит" value="82 300" />
                <ParamField label="Откр. интерес" value="1 245 000" />
                <ParamField label="Комиссия биржи" value="3.21 ₽" />
                <div />
                <ParamField label="Скальперская ком." value="0.50 ₽" />
              </div>
            </div>
          </div>

          {/* Section 2: Покрытие данных */}
          <div className="mb-8">
            <div className="flex items-center gap-2 mb-3">
              <h2 className="text-[10px] font-semibold tracking-[0.14em] uppercase text-[#6b7280]">
                ПОКРЫТИЕ ДАННЫХ
              </h2>
              <span className="text-[11px] text-[#9ba1ad]">2 из 3 типов загружено</span>
            </div>
            <div
              className="bg-[#14171c] border border-[#232831] rounded-xl overflow-hidden"
              style={{
                boxShadow: '0 6px 16px -3px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.035)'
              }}
            >
              {/* Table Header */}
              <div className="bg-[#0b0d10] px-6 py-3.5 flex items-center gap-4 border-b border-[#232831]">
                <div className="w-[120px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ТИП ДАННЫХ</div>
                <div className="w-[100px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ИНТЕРВАЛ</div>
                <div className="w-[140px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ПЕРИОД</div>
                <div className="w-[100px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280] text-right">СТРОК</div>
                <div className="w-[120px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ХРАНИЛИЩЕ</div>
                <div className="w-[120px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">СТАТУС</div>
                <div className="w-[100px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ОБНОВЛЕНО</div>
                <div className="w-[140px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ДЕЙСТВИЕ</div>
              </div>

              {/* Table Body */}
              <div className="bg-[#0b0d10]">
                <DataCoverageRow
                  type="candles"
                  interval="1m"
                  period="01.12—31.12"
                  rows="14 220"
                  storage="file"
                  status="ok"
                  updated="09:39"
                  action="Открыть задания"
                />
                <DataCoverageRow
                  type="futoi"
                  interval="—"
                  period="01.12—31.12"
                  rows="1 440"
                  storage="file"
                  status="ok"
                  updated="09:39"
                  action="Открыть задания"
                />
                <DataCoverageRow
                  type="securities"
                  interval="—"
                  period="актуально"
                  rows="—"
                  storage="PostgreSQL"
                  status="ok"
                  updated="сегодня"
                  action="Обновить"
                  isLast
                />
              </div>

              {/* Info Note */}
              <div className="px-6 py-4 border-t border-[#232831] bg-[#0b0d10]">
                <p className="text-[11px] text-[#6b7280] flex items-start gap-2">
                  <span>ℹ</span>
                  <span>FUTOI загружается по asset_code Si, не по secid SiM6. Данные FUTOI покрывают все контракты на базовый актив.</span>
                </p>
              </div>
            </div>
          </div>

          {/* Section 3: Таблица ролла */}
          <div className="mb-8">
            <div className="flex items-center gap-2 mb-3">
              <h2 className="text-[10px] font-semibold tracking-[0.14em] uppercase text-[#6b7280]">
                КОНТРАКТЫ Si
              </h2>
              <span className="text-[11px] text-[#9ba1ad]">3 контракта</span>
            </div>
            <div
              className="bg-[#14171c] border border-[#232831] rounded-xl overflow-hidden"
              style={{
                boxShadow: '0 6px 16px -3px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.035)'
              }}
            >
              {/* Table Header */}
              <div className="bg-[#0b0d10] px-6 py-3.5 flex items-center gap-4 border-b border-[#232831]">
                <div className="w-[120px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">КОНТРАКТ</div>
                <div className="w-[100px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ТИП</div>
                <div className="w-[120px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ЭКСПИРАЦИЯ</div>
                <div className="w-[80px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280] text-right">ДНЕЙ</div>
                <div className="w-[100px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">WEEKEND</div>
                <div className="flex-1 text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">СТАТУС</div>
              </div>

              {/* Table Body */}
              <div className="bg-[#0b0d10]">
                <RollTableRow
                  contract="SiM6"
                  type="quarterly"
                  expiration="20.06.2026"
                  days={12}
                  weekend="нет"
                  status="← текущий"
                  isCurrent
                />
                <RollTableRow
                  contract="SiU6"
                  type="quarterly"
                  expiration="19.09.2026"
                  days={102}
                  weekend="нет"
                  status="следующий"
                />
                <RollTableRow
                  contract="SiZ6"
                  type="quarterly"
                  expiration="18.12.2026"
                  days={192}
                  weekend="нет"
                  status="—"
                  isLast
                />
              </div>
            </div>
          </div>

          {/* Section 4: Связи */}
          <div className="mb-8">
            <h2 className="text-[10px] font-semibold tracking-[0.14em] uppercase text-[#6b7280] mb-3">
              СВЯЗИ
            </h2>
            <div
              className="bg-[#14171c] border border-[#232831] rounded-xl overflow-hidden"
              style={{
                boxShadow: '0 6px 16px -3px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.035)'
              }}
            >
              {/* Table Header */}
              <div className="bg-[#0b0d10] px-6 py-3.5 flex items-center gap-4 border-b border-[#232831]">
                <div className="w-[140px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ИНСТРУМЕНТ</div>
                <div className="flex-1 text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ТИП СВЯЗИ</div>
                <div className="w-[120px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">ASSET CODE</div>
                <div className="w-[120px] text-[9px] tracking-[0.16em] font-semibold uppercase text-[#6b7280]">CONFIDENCE</div>
              </div>

              {/* Table Body */}
              <div className="bg-[#0b0d10]">
                <div className="flex items-center gap-4 px-6 py-4">
                  <div className="w-[140px] text-[13px] text-[#9ba1ad]">—</div>
                  <div className="flex-1 text-[12px] text-[#9ba1ad]">future_underlying</div>
                  <div className="w-[120px] font-['JetBrains_Mono',monospace] text-[13px] font-bold text-[#e6e8ec]">Si</div>
                  <div className="w-[120px]">
                    <span className="font-['JetBrains_Mono',monospace] text-[10px] text-[#22c55e]">auto</span>
                  </div>
                </div>
              </div>

              {/* Note */}
              <div className="px-6 py-4 border-t border-[#232831] bg-[#0b0d10]">
                <p className="text-[12px] text-[#9ba1ad] mb-2">
                  Связанная акция не найдена. Базовый актив Si не соответствует secid ни одной акции.
                </p>
                <button className="text-[12px] font-medium text-[#6366f1] hover:text-[#8084f4]">
                  Создать ручную связь →
                </button>
              </div>
            </div>
          </div>

          {/* Section 5: Ограничения и изменения */}
          <div className="mb-8">
            <h2 className="text-[10px] font-semibold tracking-[0.14em] uppercase text-[#6b7280] mb-3">
              ОГРАНИЧЕНИЯ И ИЗМЕНЕНИЯ
            </h2>
            <div
              className="bg-[#14171c] border border-[#232831] rounded-xl p-6"
              style={{
                boxShadow: '0 6px 16px -3px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.035)'
              }}
            >
              <h3 className="text-[11px] font-semibold text-[#9ba1ad] mb-3">Приостановки</h3>
              <div className="flex items-center gap-2">
                <div className="w-[5px] h-[5px] rounded-sm bg-[#22c55e]" />
                <span className="text-[12px] text-[#9ba1ad]">Активных приостановок нет</span>
              </div>
            </div>
          </div>

          {/* Section 6: Последние действия */}
          <div className="mb-8">
            <h2 className="text-[10px] font-semibold tracking-[0.14em] uppercase text-[#6b7280] mb-3">
              ПОСЛЕДНИЕ ДЕЙСТВИЯ
            </h2>
            <div
              className="bg-[#14171c] border border-[#232831] rounded-xl p-6"
              style={{
                boxShadow: '0 6px 16px -3px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.035)'
              }}
            >
              <div className="space-y-3">
                <ActionItem time="09:39" description="candles загружены · 14 220 строк" />
                <ActionItem time="09:39" description="futoi загружены · 1 440 строк (asset_code: Si)" />
                <ActionItem time="вчера" description="справочник instruments обновлён" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function MiniMetric({ label, value, valueColor }: { label: string; value: string; valueColor?: string }) {
  return (
    <div>
      <div className="text-[9px] font-semibold tracking-[0.14em] uppercase text-[#6b7280] mb-1.5">
        {label}
      </div>
      <div
        className="font-['JetBrains_Mono',monospace] text-[13px] font-medium"
        style={{ color: valueColor || '#e6e8ec' }}
      >
        {value}
      </div>
    </div>
  );
}

function ParamField({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-[11px] text-[#6b7280] mb-1.5">{label}</div>
      <div className="text-[13px] text-[#e6e8ec]">{value}</div>
    </div>
  );
}

function DataCoverageRow({
  type,
  interval,
  period,
  rows,
  storage,
  status,
  updated,
  action,
  isLast = false
}: {
  type: string;
  interval: string;
  period: string;
  rows: string;
  storage: string;
  status: string;
  updated: string;
  action: string;
  isLast?: boolean;
}) {
  const statusColor = status === 'ok' ? '#22c55e' : status === 'partial' ? '#eab308' : '#9ca3af';

  return (
    <>
      <div className="flex items-center gap-4 px-6 py-4 hover:bg-[#181c22] transition-colors">
        <div className="w-[120px] font-['JetBrains_Mono',monospace] text-[12px] text-[#e6e8ec]">{type}</div>
        <div className="w-[100px] font-['JetBrains_Mono',monospace] text-[11px] text-[#9ba1ad]">{interval}</div>
        <div className="w-[140px] font-['JetBrains_Mono',monospace] text-[11px] text-[#9ba1ad]">{period}</div>
        <div className="w-[100px] font-['JetBrains_Mono',monospace] text-[13px] font-medium text-[#e6e8ec] text-right tabular-nums">
          {rows}
        </div>
        <div className="w-[120px] font-['JetBrains_Mono',monospace] text-[10px] text-[#6b7280]">{storage}</div>
        <div className="w-[120px]">
          <span className="text-[11px]" style={{ color: statusColor }}>● {status}</span>
        </div>
        <div className="w-[100px] font-['JetBrains_Mono',monospace] text-[11px] text-[#9ba1ad]">{updated}</div>
        <div className="w-[140px]">
          <button className="text-[11px] text-[#6366f1] hover:text-[#8084f4]">{action}</button>
        </div>
      </div>
      {!isLast && <div className="h-px bg-[#1a1e25]" />}
    </>
  );
}

function RollTableRow({
  contract,
  type,
  expiration,
  days,
  weekend,
  status,
  isCurrent = false,
  isLast = false
}: {
  contract: string;
  type: string;
  expiration: string;
  days: number;
  weekend: string;
  status: string;
  isCurrent?: boolean;
  isLast?: boolean;
}) {
  const daysColor = days < 14 ? '#ef4444' : days <= 30 ? '#eab308' : '#9ba1ad';

  return (
    <>
      <div className="flex items-center gap-4 px-6 py-4 hover:bg-[#181c22] transition-colors">
        <div className={`w-[120px] text-[13px] ${isCurrent ? 'font-bold text-[#e6e8ec]' : 'text-[#9ba1ad]'}`}>
          {contract}
        </div>
        <div className="w-[100px] font-['JetBrains_Mono',monospace] text-[11px] text-[#9ba1ad]">{type}</div>
        <div className="w-[120px] font-['JetBrains_Mono',monospace] text-[12px] text-[#9ba1ad]">{expiration}</div>
        <div className="w-[80px] text-right">
          <span
            className={`font-['JetBrains_Mono',monospace] text-[13px] font-medium tabular-nums ${isCurrent ? 'font-bold' : ''}`}
            style={{ color: daysColor }}
          >
            {days}
          </span>
        </div>
        <div className="w-[100px] text-[12px] text-[#9ba1ad]">{weekend}</div>
        <div className="flex-1">
          {status !== '—' && (
            <span className="text-[10px] text-[#38bdf8]">{status}</span>
          )}
          {status === '—' && (
            <span className="text-[12px] text-[#6b7280]">—</span>
          )}
        </div>
      </div>
      {!isLast && <div className="h-px bg-[#1a1e25]" />}
    </>
  );
}

function ActionItem({ time, description }: { time: string; description: string }) {
  return (
    <div className="flex items-start gap-3">
      <span className="font-['JetBrains_Mono',monospace] text-[11px] text-[#6b7280] shrink-0">{time}</span>
      <span className="text-[12px] text-[#9ba1ad]">{description}</span>
    </div>
  );
}

function DataStatusBadge({ status }: { status: string }) {
  const configs: Record<string, { bg: string; border: string; dot: string; text: string; label: string }> = {
    'загружено': { bg: '#14532d', border: 'rgba(22,163,74,0.4)', dot: '#22c55e', text: '#22c55e', label: 'загружено' },
    'частично': { bg: '#713f12', border: 'rgba(202,138,4,0.4)', dot: '#eab308', text: '#eab308', label: 'частично' },
    'не загружено': { bg: '#1f2937', border: 'rgba(75,85,99,0.4)', dot: '#9ca3af', text: '#9ca3af', label: 'не загружено' },
    'требует проверки': { bg: '#713f12', border: 'rgba(202,138,4,0.4)', dot: '#eab308', text: '#eab308', label: 'требует проверки' },
  };

  const config = configs[status] || configs['не загружено'];

  return (
    <div
      className="inline-flex items-center gap-1.5 py-[3px] pl-[7px] pr-[9px] rounded"
      style={{
        backgroundColor: config.bg,
        border: `1px solid ${config.border}`
      }}
    >
      <div className="w-[5px] h-[5px] rounded-sm" style={{ backgroundColor: config.dot }} />
      <span className="text-[11px] font-medium" style={{ color: config.text }}>{config.label}</span>
    </div>
  );
}
