import { useState } from 'react';
import { Key, ExternalLink, CheckCircle, AlertCircle, Wifi } from 'lucide-react';
import { AppShell, NavPage, T, Mono, PrimaryBtn, SecondaryBtn, SectionLabel } from '../shell/AppShell';

const CONNECTIONS = [
  { name: 'PostgreSQL', url: 'postgres://moex-ops.internal:5432/data_ops', status: 'ok', latency: '2ms' },
  { name: 'S3',         url: 's3://moex-data-ops-bucket/raw',              status: 'ok', latency: '18ms' },
  { name: 'ClickHouse', url: 'clickhouse://ch.internal:8123/market',        status: 'ok', latency: '5ms' },
  { name: 'MOEX ISS',   url: 'https://iss.moex.com/iss',                   status: 'ok', latency: '94ms' },
  { name: 'MOEX APIM',  url: 'https://apim.moex.com',                      status: 'error', latency: '—' },
];

const RAW_MODES = ['Off', 'FailedOnly', 'Sample', 'All'] as const;

export function SettingsScreen({ currentPage, onNavigate }: { currentPage: NavPage; onNavigate: (p: NavPage) => void }) {
  const [apiKeySet] = useState(true);
  const [rawMode, setRawMode] = useState<typeof RAW_MODES[number]>('FailedOnly');
  const [rateLimitRps] = useState(5);
  const [hoveredConn, setHoveredConn] = useState<string | null>(null);

  return (
    <AppShell currentPage={currentPage} onNavigate={onNavigate} breadcrumb="Настройки">
      <div style={{ height: '100%', overflowY: 'auto', padding: 20 }}>
        <h1 style={{ fontSize: 24, fontWeight: 600, color: T.txtPrimary, marginBottom: 24, marginTop: 0 }}>Настройки</h1>

        {/* API Key */}
        <SectionLabel>Ключ MOEX APIM</SectionLabel>
        <div style={{ background: T.bgSurface, border: `1px solid ${T.subtle}`, borderRadius: 12, padding: 20, boxShadow: T.shadowCard, marginBottom: 20 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
            <div style={{ width: 36, height: 36, borderRadius: 8, background: apiKeySet ? 'rgba(34,197,94,0.1)' : 'rgba(239,68,68,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Key size={16} color={apiKeySet ? '#22C55E' : '#EF4444'} />
            </div>
            <div>
              <div style={{ fontSize: 14, fontWeight: 500, color: T.txtPrimary }}>
                {apiKeySet ? 'Ключ введён' : 'Ключ не введён'}
              </div>
              <div style={{ fontSize: 12, color: T.txtSecondary }}>
                {apiKeySet ? <Mono size={12} color={T.txtMuted}>••••••••••••9A4F</Mono> : 'Без ключа загрузка платных данных недоступна'}
              </div>
            </div>
            <div style={{ flex: 1 }} />
            <SecondaryBtn small>Проверить</SecondaryBtn>
            <SecondaryBtn small>Изменить</SecondaryBtn>
          </div>
          <button style={{ fontSize: 12, color: T.accent, background: 'none', border: 'none', cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 5 }}>
            <ExternalLink size={12} />Получить ключ на портале MOEX
          </button>
        </div>

        {/* Raw capture */}
        <SectionLabel>Raw Capture</SectionLabel>
        <div style={{ background: T.bgSurface, border: `1px solid ${T.subtle}`, borderRadius: 12, padding: 20, boxShadow: T.shadowCard, marginBottom: 20 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
            {RAW_MODES.map(m => (
              <button key={m} onClick={() => setRawMode(m)} style={{
                padding: '6px 14px', borderRadius: 8, fontSize: 12, fontWeight: 500, cursor: 'pointer', fontFamily: "'Inter', sans-serif",
                background: rawMode === m ? T.accentSub : T.bgApp,
                color: rawMode === m ? T.accent : T.txtSecondary,
                border: `1px solid ${rawMode === m ? T.accent : T.border}`,
              }}>{m}</button>
            ))}
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <div style={{ background: T.bgApp, borderRadius: 8, padding: 12, border: `1px solid ${T.hairline}` }}>
              <div style={{ fontSize: 10, color: T.txtDisabled, marginBottom: 4, textTransform: 'uppercase', letterSpacing: '0.12em' }}>Записей за сутки</div>
              <Mono size={20} bold>1 247</Mono>
            </div>
            <div style={{ background: T.bgApp, borderRadius: 8, padding: 12, border: `1px solid ${T.hairline}` }}>
              <div style={{ fontSize: 10, color: T.txtDisabled, marginBottom: 4, textTransform: 'uppercase', letterSpacing: '0.12em' }}>Ошибок за сутки</div>
              <Mono size={20} color="#EF4444" bold>3</Mono>
            </div>
          </div>
        </div>

        {/* Rate limiter */}
        <SectionLabel>Rate Limiter</SectionLabel>
        <div style={{ background: T.bgSurface, border: `1px solid ${T.subtle}`, borderRadius: 12, padding: 20, boxShadow: T.shadowCard, marginBottom: 20 }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
            {[
              { label: 'Лимит req/s', value: `${rateLimitRps}` },
              { label: 'Среднее ожидание', value: '0.8s' },
              { label: 'P95 ожидание', value: '2.1s' },
            ].map(m => (
              <div key={m.label} style={{ background: T.bgApp, borderRadius: 8, padding: 12, border: `1px solid ${T.hairline}` }}>
                <div style={{ fontSize: 10, color: T.txtDisabled, marginBottom: 4, textTransform: 'uppercase', letterSpacing: '0.12em' }}>{m.label}</div>
                <Mono size={22} bold>{m.value}</Mono>
              </div>
            ))}
          </div>
          <div style={{ marginTop: 12 }}>
            <div style={{ height: 6, background: T.bgApp, borderRadius: 3, overflow: 'hidden', border: `1px solid ${T.hairline}` }}>
              <div style={{ width: `${(rateLimitRps / 10) * 100}%`, height: '100%', background: T.accent, borderRadius: 3 }} />
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4 }}>
              <span style={{ fontSize: 10, color: T.txtDisabled }}>Утилизация: {Math.round((rateLimitRps / 10) * 100)}%</span>
              <span style={{ fontSize: 10, color: T.txtDisabled }}>Макс. 10 req/s</span>
            </div>
          </div>
        </div>

        {/* Connections */}
        <SectionLabel>Подключения</SectionLabel>
        <div style={{ background: T.bgSurface, border: `1px solid ${T.subtle}`, borderRadius: 12, overflow: 'hidden', boxShadow: T.shadowCard, marginBottom: 20 }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: T.bgApp }}>
                {['СЕРВИС', 'URL', 'СТАТУС', 'ЗАДЕРЖКА'].map(h => (
                  <th key={h} style={{ padding: '10px 16px', textAlign: 'left', fontSize: 9, fontWeight: 600, letterSpacing: '0.16em', textTransform: 'uppercase', color: T.txtMuted, borderBottom: `1px solid ${T.hairline}` }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {CONNECTIONS.map(c => (
                <tr key={c.name}
                  onMouseEnter={() => setHoveredConn(c.name)}
                  onMouseLeave={() => setHoveredConn(null)}
                  style={{ background: hoveredConn === c.name ? T.bgHover : 'transparent', borderBottom: `1px solid rgba(26,30,37,0.6)`, transition: 'background 0.1s' }}
                >
                  <td style={{ padding: '11px 16px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <Wifi size={13} color={c.status === 'ok' ? '#22C55E' : '#EF4444'} />
                      <span style={{ fontSize: 13, fontWeight: 500, color: T.txtPrimary }}>{c.name}</span>
                    </div>
                  </td>
                  <td style={{ padding: '11px 16px' }}><Mono size={11} color={T.txtMuted}>{c.url}</Mono></td>
                  <td style={{ padding: '11px 16px' }}>
                    {c.status === 'ok'
                      ? <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 12, color: '#22C55E' }}><CheckCircle size={12} />доступен</span>
                      : <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 12, color: '#EF4444' }}><AlertCircle size={12} />недоступен</span>
                    }
                  </td>
                  <td style={{ padding: '11px 16px' }}><Mono size={12} color={c.latency === '—' ? T.txtDisabled : T.txtSecondary}>{c.latency}</Mono></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Observability */}
        <SectionLabel>Наблюдаемость</SectionLabel>
        <div style={{ background: T.bgSurface, border: `1px solid ${T.subtle}`, borderRadius: 12, padding: 20, boxShadow: T.shadowCard }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {[
              { label: 'Grafana — Основной дашборд', url: 'grafana.internal/d/moex-main' },
              { label: 'Grafana — Загрузки', url: 'grafana.internal/d/moex-loads' },
              { label: 'Grafana — Качество', url: 'grafana.internal/d/moex-quality' },
            ].map(l => (
              <button key={l.label} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 13, color: T.accent, background: 'none', border: 'none', cursor: 'pointer', fontFamily: "'Inter', sans-serif", textAlign: 'left' }}>
                <ExternalLink size={13} />{l.label}
                <Mono size={11} color={T.txtDisabled}>{l.url}</Mono>
              </button>
            ))}
          </div>
        </div>
      </div>
    </AppShell>
  );
}
