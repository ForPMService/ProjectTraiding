export function Sidebar({ activePage = 'dashboard' }: { activePage?: 'dashboard' | 'instruments' }) {
  return (
    <div className="fixed left-0 top-0 h-screen w-[220px] bg-[#14171c] flex flex-col z-20">
      <div className="pt-6 pb-7 px-3">
        {/* Logo */}
        <div className="flex items-center gap-2.5 mb-7 pl-3">
          <div className="w-6 h-6 rounded-md bg-[#6366f1]" />
          <div className="flex flex-col leading-none">
            <div className="font-semibold text-[13px] tracking-[0.08em] text-[#e6e8ec]">MOEX</div>
            <div className="text-[10px] tracking-[0.04em] text-[#96a1af] mt-1">Data Operations</div>
          </div>
        </div>

        {/* DATA OPS - раскрыт */}
        <div className="mb-3">
          <div className="flex items-center justify-between px-[14px] py-3 cursor-pointer">
            <span className="text-[10px] font-semibold tracking-[0.14em] uppercase text-[#e6e8ec]">
              DATA OPS
            </span>
            <svg className="w-2 h-2 text-[#6b7280]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M19 9l-7 7-7-7" />
            </svg>
          </div>
          <nav className="flex flex-col gap-0.5 mt-2">
            <NavItem label="Dashboard" active={activePage === 'dashboard'} />
            <NavItem label="Инструменты" active={activePage === 'instruments'} />
            <NavItem label="Загрузки" />
            <NavItem label="Операции" />
            <NavItem label="Календарь" />
            <NavItem label="Ограничения" />
            <NavItem label="Издержки" />
          </nav>
        </div>

        {/* Divider */}
        <div className="h-px bg-[#1a1e25] mx-[14px] my-3" />

        {/* TRADING - свёрнут */}
        <div className="mb-3">
          <div className="flex items-center justify-between px-[14px] py-3 cursor-pointer hover:bg-[#181c22] rounded-md transition-colors duration-200">
            <span className="text-[10px] font-semibold tracking-[0.14em] uppercase text-[#3e4451] group-hover:text-[#6b7280]">
              TRADING
            </span>
            <svg className="w-2 h-2 text-[#3e4451]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M9 5l7 7-7 7" />
            </svg>
          </div>
        </div>
      </div>

      <div className="flex-1" />

      <div className="px-3 pb-6">
        <div className="h-px bg-[#1a1e25] mb-3" />
        <NavItem label="Настройки" />

        {/* Account Card */}
        <div className="mt-4 bg-[#0b0d10] border border-[#1a1e25] rounded-lg py-2 px-2.5 flex items-center gap-2.5 hover:border-[#2d333e] transition-all duration-200 cursor-pointer">
          <div className="w-[30px] h-[30px] rounded-full bg-[#1e1f3a] border border-[rgba(99,102,241,0.4)]" />
          <div className="flex flex-col leading-none">
            <div className="text-[12px] font-medium text-[#e6e8ec] mb-1">Александр Е.</div>
            <div className="text-[10px] text-[#a3adb9]">Оператор · MOEX</div>
          </div>
        </div>
      </div>
    </div>
  );
}

function NavItem({ label, active = false }: { label: string; active?: boolean }) {
  return (
    <button
      className={`
        w-full flex items-center px-4 py-[10px] rounded-md transition-all duration-200 text-left relative
        ${active
          ? 'bg-[rgba(30,31,58,1)] text-[#6366f1]'
          : 'text-[#9ba1ad] hover:text-[#c2c8d2] hover:bg-[#181c22]'
        }
      `}
    >
      {active && <div className="absolute left-0 top-0 bottom-0 w-0.5 bg-[#6366f1]" />}
      <span className={`text-[13px] ${active ? 'font-semibold ml-2' : 'font-normal'}`}>
        {label}
      </span>
    </button>
  );
}
