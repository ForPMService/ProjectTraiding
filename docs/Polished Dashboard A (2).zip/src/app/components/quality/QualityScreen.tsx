import { useState } from 'react';
import { ShieldCheck, Play, ChevronDown } from 'lucide-react';
import { AppShell, NavPage, T, Mono, StatusBadge, PrimaryBtn, SecondaryBtn, SectionLabel, EmptyState } from '../shell/AppShell';

const CHECKS = [
  { secid: 'SBER', dataType: 'candles',    checkType: 'gaps',      status: 'success', result: 'ok',      date: '2026-06-19', details: 'Пропусков не обнаружено. Покрытие 100%.' },
  { secid: 'SBER', dataType: 'tradestats', checkType: 'volume',    status: 'success', result: 'ok',      date: '2026-06-19', details: 'Объёмы в норме.' },
  { secid: 'SiM6', dataType: 'candles',    checkType: 'gaps',      status: 'warning', result: 'warning', date: '2026-06-18', details: 'Пропуск 2026-05-13 10:00–11:00 (60 свечей).' },
  { secid: 'SiM6', dataType: 'futoi',      checkType: 'expiry',    status: 'pending', result: null,      date: '2026-06-19', details: '' },
  { secid: 'GMKN', dataType: 'candles',    checkType: 'gaps',      status: 'error',   result: 'error',   date: '2026-06-17', details: 'HTTP 429 при загрузке. Данные неполные.' },
  { secid: 'GAZP', dataType: 'tradestats', checkType: 'stale',     status: 'running', result: null,      date: '2026-06-19', details: '' },
];

const DIVERGENCES = [
  { secid: 'SiM6', calendarDate: '2026-06-18', issDate: '2026-06-17', diff: '+1 день' },
];

export function QualityScreen({ currentPage, onNavigate }: { currentPage: NavPage; onNavigate: (p: NavPage) => void }) {
  const [expanded, setExpanded] = useState<number | null>(null);
  const [hoveredRow, setHoveredRow] = useState<number | null>(null);

  const summary = {
    ok:     CHECKS.filter(c => c.result === 'ok').length,
    warn:   CHECKS.filter(c => c.result === 'warning').length,
    err:    CHECKS.filter(c => c.result === 'error').length,
    unchecked: CHECKS.filter(c => c.result === null).length,
    withIssues: CHECKS.filter(c => c.result === 'warning' || c.result === 'error').length,
  };

  return (
    <AppShell currentPage={currentPage} onNavigate={onNavigate} breadcrumb="Качество">
      <div style={{ height: '100%', overflowY: 'auto', padding: 20 }}>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 20 }}>
          <h1 style={{ fontSize: 24, fontWeight: 600, color: T.txtPrimary, margin: 0 }}>Качество</h1>
          <div style={{ flex: 1 }} />
          <div style={{ display: 'flex', gap: 8 }}>
            <SecondaryBtn small><Play size={13} />Запустить проверку</SecondaryBtn>
            <PrimaryBtn small><ShieldCheck size={13} />Проверить все</PrimaryBtn>
          </div>
        </div>

        {/* Summary cards */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginBottom: 20 }}>
          <div style={{ background: T.bgSurface, border: `1px solid ${T.subtle}`, borderRadius: 12, padding: 16, boxShadow: T.shadowCard }}>
            <div style={{ fontSize: 9, fontWeight: 600, letterSpacing: '0.16em', textTransform: 'uppercase', color: T.txtMuted, marginBottom: 10 }}>Проверок сегодня</div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
              <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 32, fontWeight: 500, color: T.txtPrimary }}>{summary.ok + summary.warn + summary.err}</span>
            </div>
            <div style={{ display: 'flex', gap: 10, marginTop: 8 }}>
              <span style={{ fontSize: 11, color: '#22C55E' }}>✓ {summary.ok}</span>
              <span style={{ fontSize: 11, color: '#EAB308' }}>⚠ {summary.warn}</span>
              <span style={{ fontSize: 11, color: '#EF4444' }}>✗ {summary.err}</span>
            </div>
          </div>
          <div style={{ background: T.bgSurface, border: `1px solid ${T.subtle}`, borderRadius: 12, padding: 16, boxShadow: T.shadowCard }}>
            <div style={{ fontSize: 9, fontWeight: 600, letterSpacing: '0.16em', textTransform: 'uppercase', color: T.txtMuted, marginBottom: 10 }}>Непроверенных диапазонов</div>
            <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 32, fontWeight: 500, color: T.txtPrimary }}>{summary.unchecked}</div>
          </div>
          <div style={{ background: T.bgSurface, border: `1px solid ${T.subtle}`, borderRadius: 12, padding: 16, boxShadow: T.shadowCard }}>
            <div style={{ fontSize: 9, fontWeight: 600, letterSpacing: '0.16em', textTransform: 'uppercase', color: T.txtMuted, marginBottom: 10 }}>С проблемами</div>
            <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 32, fontWeight: 500, color: summary.withIssues > 0 ? '#EAB308' : T.txtPrimary }}>{summary.withIssues}</div>
          </div>
        </div>

        {/* Checks table */}
        <div style={{ marginBottom: 20 }}>
          <SectionLabel>Проверки</SectionLabel>
          <div style={{ background: T.bgSurface, border: `1px solid ${T.subtle}`, borderRadius: 12, overflow: 'hidden', boxShadow: T.shadowCard }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ background: T.bgApp }}>
                  {['SECID', 'ТИП ДАННЫХ', 'ТИП ПРОВЕРКИ', 'СТАТУС', 'РЕЗУЛЬТАТ', 'ДАТА', 'ДЕТАЛИ'].map(h => (
                    <th key={h} style={{ padding: '10px 16px', textAlign: 'left', fontSize: 9, fontWeight: 600, letterSpacing: '0.16em', textTransform: 'uppercase', color: T.txtMuted, borderBottom: `1px solid ${T.hairline}` }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {CHECKS.map((c, i) => (
                  <>
                    <tr key={i}
                      onMouseEnter={() => setHoveredRow(i)}
                      onMouseLeave={() => setHoveredRow(null)}
                      style={{ background: hoveredRow === i ? T.bgHover : 'transparent', borderBottom: expanded === i ? 'none' : `1px solid rgba(26,30,37,0.6)`, cursor: c.details ? 'pointer' : 'default', transition: 'background 0.1s' }}
                      onClick={() => c.details && setExpanded(expanded === i ? null : i)}
                    >
                      <td style={{ padding: '11px 16px' }}><Mono size={13} bold>{c.secid}</Mono></td>
                      <td style={{ padding: '11px 16px' }}><Mono size={11} color={T.txtSecondary}>{c.dataType}</Mono></td>
                      <td style={{ padding: '11px 16px' }}><span style={{ fontSize: 12, color: T.txtSecondary }}>{c.checkType}</span></td>
                      <td style={{ padding: '11px 16px' }}><StatusBadge status={c.status} /></td>
                      <td style={{ padding: '11px 16px' }}>{c.result ? <StatusBadge status={c.result} /> : <span style={{ color: T.txtDisabled, fontSize: 12 }}>—</span>}</td>
                      <td style={{ padding: '11px 16px' }}><Mono size={11} color={T.txtMuted}>{c.date}</Mono></td>
                      <td style={{ padding: '11px 16px' }}>
                        {c.details && (
                          <ChevronDown size={14} color={T.txtMuted} style={{ transform: expanded === i ? 'rotate(180deg)' : 'none', transition: 'transform 0.15s' }} />
                        )}
                      </td>
                    </tr>
                    {expanded === i && c.details && (
                      <tr key={`exp-${i}`} style={{ borderBottom: `1px solid rgba(26,30,37,0.6)` }}>
                        <td colSpan={7} style={{ padding: '0 16px 12px 48px' }}>
                          <div style={{ fontSize: 12, color: T.txtSecondary, lineHeight: 1.6 }}>{c.details}</div>
                        </td>
                      </tr>
                    )}
                  </>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Divergences */}
        {DIVERGENCES.length > 0 && (
          <div>
            <SectionLabel>Расхождения экспираций</SectionLabel>
            <div style={{ background: T.bgSurface, border: `1px solid ${T.subtle}`, borderRadius: 12, overflow: 'hidden', boxShadow: T.shadowCard }}>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                  <tr style={{ background: T.bgApp }}>
                    {['SECID', 'ДАТА ИЗ КАЛЕНДАРЯ', 'LAST_TRADE_DATE (ISS)', 'РАЗНИЦА'].map(h => (
                      <th key={h} style={{ padding: '10px 16px', textAlign: 'left', fontSize: 9, fontWeight: 600, letterSpacing: '0.16em', textTransform: 'uppercase', color: T.txtMuted, borderBottom: `1px solid ${T.hairline}` }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {DIVERGENCES.map((d, i) => (
                    <tr key={i} style={{ borderBottom: `1px solid rgba(26,30,37,0.6)` }}>
                      <td style={{ padding: '11px 16px' }}><Mono size={13} bold>{d.secid}</Mono></td>
                      <td style={{ padding: '11px 16px' }}><Mono size={12} color={T.txtSecondary}>{d.calendarDate}</Mono></td>
                      <td style={{ padding: '11px 16px' }}><Mono size={12} color={T.txtSecondary}>{d.issDate}</Mono></td>
                      <td style={{ padding: '11px 16px' }}><Mono size={12} color="#EAB308">{d.diff}</Mono></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </AppShell>
  );
}
