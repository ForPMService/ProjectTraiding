import { useState } from 'react';
import { Plus, X } from 'lucide-react';
import { AppShell, NavPage, T, Mono, PrimaryBtn, SecondaryBtn, SectionLabel } from '../shell/AppShell';

const TARIFFS = [
  { broker: 'ВТБ Инвестиции', name: 'Мой онлайн', market: 'stock',   commType: 'percent_of_turnover', value: '0.0413%', currency: 'RUB', from: '2025-01-01', to: '—' },
  { broker: 'Тинькофф',       name: 'Трейдер',     market: 'futures', commType: 'fixed_per_contract',  value: '2.50',    currency: 'RUB', from: '2025-01-01', to: '—' },
  { broker: 'БКС',            name: 'Инвестор',    market: 'stock',   commType: 'percent_of_turnover', value: '0.0100%', currency: 'RUB', from: '2024-07-01', to: '2025-12-31' },
];

const COMM_SHORT: Record<string, string> = {
  percent_of_turnover: '% оборота',
  fixed_per_contract: 'фикс./контракт',
  fixed_per_trade: 'фикс./сделку',
  monthly: 'ежемесячная',
  depository: 'депозитарная',
};

const CALC_INSTRUMENTS = ['SBER', 'GAZP', 'LKOH', 'SiM6'];

function CommTypeTag({ type }: { type: string }) {
  return (
    <span style={{ fontSize: 11, fontFamily: 'JetBrains Mono, monospace', color: T.txtSecondary, padding: '2px 7px', borderRadius: 4, border: `1px solid ${T.border}`, background: T.bgApp }}>
      {COMM_SHORT[type] ?? type}
    </span>
  );
}

export function CostsScreen({ currentPage, onNavigate, onAddTariff }: {
  currentPage: NavPage; onNavigate: (p: NavPage) => void; onAddTariff: () => void;
}) {
  const [calcSecid, setCalcSecid] = useState('SBER');
  const [hoveredRow, setHoveredRow] = useState<number | null>(null);

  return (
    <AppShell currentPage={currentPage} onNavigate={onNavigate} breadcrumb="Издержки">
      <div style={{ height: '100%', overflowY: 'auto', padding: 20 }}>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 24 }}>
          <h1 style={{ fontSize: 24, fontWeight: 600, color: T.txtPrimary, margin: 0 }}>Издержки</h1>
          <div style={{ flex: 1 }} />
          <SecondaryBtn small onClick={onAddTariff}><Plus size={13} />Добавить тариф</SecondaryBtn>
        </div>

        {/* Current tariffs */}
        <SectionLabel>Текущие тарифы</SectionLabel>
        <div style={{ background: T.bgSurface, border: `1px solid ${T.subtle}`, borderRadius: 12, overflow: 'hidden', boxShadow: T.shadowCard, marginBottom: 24 }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: T.bgApp }}>
                {['БРОКЕР', 'НАЗВАНИЕ', 'РЫНОК', 'ТИП КОМИССИИ', 'ЗНАЧЕНИЕ', 'ВАЛЮТА', 'ДЕЙСТВУЕТ С'].map(h => (
                  <th key={h} style={{ padding: '10px 16px', textAlign: 'left', fontSize: 9, fontWeight: 600, letterSpacing: '0.16em', textTransform: 'uppercase', color: T.txtMuted, borderBottom: `1px solid ${T.hairline}` }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {TARIFFS.filter(t => t.to === '—').map((t, i) => (
                <tr key={i}
                  onMouseEnter={() => setHoveredRow(i)}
                  onMouseLeave={() => setHoveredRow(null)}
                  style={{ background: hoveredRow === i ? T.bgHover : 'transparent', borderBottom: `1px solid rgba(26,30,37,0.6)`, transition: 'background 0.1s' }}
                >
                  <td style={{ padding: '11px 16px', fontSize: 13, color: T.txtPrimary, fontWeight: 500 }}>{t.broker}</td>
                  <td style={{ padding: '11px 16px', fontSize: 13, color: T.txtSecondary }}>{t.name}</td>
                  <td style={{ padding: '11px 16px', fontSize: 12, color: T.txtSecondary }}>{t.market === 'stock' ? 'фондовый' : 'срочный'}</td>
                  <td style={{ padding: '11px 16px' }}><CommTypeTag type={t.commType} /></td>
                  <td style={{ padding: '11px 16px' }}><Mono size={13} bold>{t.value}</Mono></td>
                  <td style={{ padding: '11px 16px', fontSize: 12, color: T.txtSecondary }}>{t.currency}</td>
                  <td style={{ padding: '11px 16px' }}><Mono size={12} color={T.txtMuted}>{t.from}</Mono></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Calculator */}
        <SectionLabel>Калькулятор</SectionLabel>
        <div style={{ background: T.bgSurface, border: `1px solid ${T.subtle}`, borderRadius: 12, padding: 20, boxShadow: T.shadowCard, marginBottom: 24 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
            <span style={{ fontSize: 13, color: T.txtSecondary }}>Инструмент:</span>
            <div style={{ display: 'flex', gap: 4 }}>
              {CALC_INSTRUMENTS.map(s => (
                <button key={s} onClick={() => setCalcSecid(s)} style={{
                  padding: '5px 10px', borderRadius: 6, fontSize: 12, fontFamily: 'JetBrains Mono, monospace', cursor: 'pointer',
                  background: calcSecid === s ? T.accentSub : T.bgApp, color: calcSecid === s ? T.accent : T.txtSecondary,
                  border: `1px solid ${calcSecid === s ? T.accent : T.border}`,
                }}>{s}</button>
              ))}
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
            {[
              { label: 'Биржевая', value: '0.0413%', sub: 'MOEX TQBR' },
              { label: 'Брокерская', value: '0.0100%', sub: 'ВТБ Инвестиции' },
              { label: 'Полная', value: '0.0513%', sub: 'Round-trip × 2' },
            ].map(c => (
              <div key={c.label} style={{ background: T.bgApp, borderRadius: 8, padding: 14, border: `1px solid ${T.hairline}` }}>
                <div style={{ fontSize: 10, color: T.txtDisabled, marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.12em' }}>{c.label}</div>
                <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 22, fontWeight: 500, color: T.txtPrimary }}>{c.value}</div>
                <div style={{ fontSize: 11, color: T.txtMuted, marginTop: 4 }}>{c.sub}</div>
              </div>
            ))}
          </div>
        </div>

        {/* History */}
        <SectionLabel>История тарифов</SectionLabel>
        <div style={{ background: T.bgSurface, border: `1px solid ${T.subtle}`, borderRadius: 12, overflow: 'hidden', boxShadow: T.shadowCard }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: T.bgApp }}>
                {['БРОКЕР', 'НАЗВАНИЕ', 'РЫНОК', 'ТИП КОМИССИИ', 'ЗНАЧЕНИЕ', 'ПЕРИОД'].map(h => (
                  <th key={h} style={{ padding: '10px 16px', textAlign: 'left', fontSize: 9, fontWeight: 600, letterSpacing: '0.16em', textTransform: 'uppercase', color: T.txtMuted, borderBottom: `1px solid ${T.hairline}` }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {TARIFFS.filter(t => t.to !== '—').map((t, i) => (
                <tr key={i} style={{ borderBottom: `1px solid rgba(26,30,37,0.6)`, opacity: 0.7 }}>
                  <td style={{ padding: '11px 16px', fontSize: 13, color: T.txtSecondary }}>{t.broker}</td>
                  <td style={{ padding: '11px 16px', fontSize: 13, color: T.txtMuted }}>{t.name}</td>
                  <td style={{ padding: '11px 16px', fontSize: 12, color: T.txtMuted }}>{t.market === 'stock' ? 'фондовый' : 'срочный'}</td>
                  <td style={{ padding: '11px 16px' }}><CommTypeTag type={t.commType} /></td>
                  <td style={{ padding: '11px 16px' }}><Mono size={12} color={T.txtMuted}>{t.value}</Mono></td>
                  <td style={{ padding: '11px 16px' }}><Mono size={11} color={T.txtMuted}>{t.from} – {t.to}</Mono></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AppShell>
  );
}
