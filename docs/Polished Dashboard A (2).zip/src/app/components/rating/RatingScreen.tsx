import { useState } from 'react';
import { ArrowUpDown, ArrowUp, ArrowDown } from 'lucide-react';
import { AppShell, NavPage, T, Mono, SectionLabel, EmptyState } from '../shell/AppShell';

const RATING_DATA = [
  { secid: 'SBER', type: 'stock',  assetCode: '—',   rows: 214200, typesCovered: 4, commission: '0.0513%', liquidity: 9.2, qualityOk: true,  score: 94 },
  { secid: 'GAZP', type: 'stock',  assetCode: '—',   rows: 156400, typesCovered: 3, commission: '0.0513%', liquidity: 8.7, qualityOk: true,  score: 88 },
  { secid: 'SiM6', type: 'future', assetCode: 'Si',  rows: 109620, typesCovered: 2, commission: '2.50',    liquidity: 9.8, qualityOk: false, score: 75 },
  { secid: 'LKOH', type: 'stock',  assetCode: '—',   rows: 98400,  typesCovered: 2, commission: '0.0513%', liquidity: 7.8, qualityOk: true,  score: 71 },
  { secid: 'GMKN', type: 'stock',  assetCode: '—',   rows: 10080,  typesCovered: 1, commission: '0.0513%', liquidity: 6.9, qualityOk: false, score: 38 },
];

type SortKey = 'rows' | 'typesCovered' | 'liquidity' | 'score';

function ScoreBar({ score }: { score: number }) {
  const color = score >= 80 ? '#22C55E' : score >= 60 ? '#EAB308' : '#EF4444';
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <div style={{ width: 60, height: 4, background: T.bgApp, borderRadius: 2, overflow: 'hidden' }}>
        <div style={{ width: `${score}%`, height: '100%', background: color, borderRadius: 2 }} />
      </div>
      <Mono size={12} color={color} bold>{score}</Mono>
    </div>
  );
}

export function RatingScreen({ currentPage, onNavigate }: { currentPage: NavPage; onNavigate: (p: NavPage) => void }) {
  const [sortKey, setSortKey] = useState<SortKey>('score');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');
  const [hoveredRow, setHoveredRow] = useState<string | null>(null);

  const handleSort = (key: SortKey) => {
    if (sortKey === key) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortKey(key); setSortDir('desc'); }
  };

  const sorted = [...RATING_DATA].sort((a, b) => {
    const av = a[sortKey] as number;
    const bv = b[sortKey] as number;
    return sortDir === 'desc' ? bv - av : av - bv;
  });

  const SortIcon = ({ k }: { k: SortKey }) => {
    if (sortKey !== k) return <ArrowUpDown size={10} color={T.txtDisabled} />;
    return sortDir === 'desc' ? <ArrowDown size={10} color={T.accent} /> : <ArrowUp size={10} color={T.accent} />;
  };

  const headers: { key: string; label: string; sortable?: SortKey }[] = [
    { key: 'secid', label: 'SECID' },
    { key: 'type', label: 'ТИП' },
    { key: 'assetCode', label: 'ASSET_CODE' },
    { key: 'rows', label: 'СТРОК', sortable: 'rows' },
    { key: 'types', label: 'ТИПОВ', sortable: 'typesCovered' },
    { key: 'commission', label: 'КОМИССИЯ' },
    { key: 'liquidity', label: 'ЛИКВИДНОСТЬ', sortable: 'liquidity' },
    { key: 'quality', label: 'КАЧЕСТВО' },
    { key: 'score', label: 'SCORE', sortable: 'score' },
  ];

  return (
    <AppShell currentPage={currentPage} onNavigate={onNavigate} breadcrumb="Рейтинг">
      <div style={{ height: '100%', overflowY: 'auto', padding: 20 }}>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 24 }}>
          <h1 style={{ fontSize: 24, fontWeight: 600, color: T.txtPrimary, margin: 0 }}>Рейтинг</h1>
        </div>

        <div style={{ background: T.bgSurface, border: `1px solid ${T.subtle}`, borderRadius: 12, overflow: 'hidden', boxShadow: T.shadowCard }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: T.bgApp }}>
                {headers.map(h => (
                  <th key={h.key}
                    onClick={() => h.sortable && handleSort(h.sortable)}
                    style={{
                      padding: '10px 16px', textAlign: 'left', fontSize: 9, fontWeight: 600, letterSpacing: '0.16em',
                      textTransform: 'uppercase', color: h.sortable && sortKey === h.sortable ? T.accent : T.txtMuted,
                      borderBottom: `1px solid ${T.hairline}`, cursor: h.sortable ? 'pointer' : 'default', userSelect: 'none',
                      whiteSpace: 'nowrap',
                    }}
                  >
                    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                      {h.label}
                      {h.sortable && <SortIcon k={h.sortable} />}
                    </span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {sorted.map((r, i) => (
                <tr key={r.secid}
                  onMouseEnter={() => setHoveredRow(r.secid)}
                  onMouseLeave={() => setHoveredRow(null)}
                  style={{ background: hoveredRow === r.secid ? T.bgHover : 'transparent', borderBottom: `1px solid rgba(26,30,37,0.6)`, transition: 'background 0.1s' }}
                >
                  <td style={{ padding: '11px 16px' }}>
                    <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <span style={{ fontSize: 11, color: T.txtDisabled, fontFamily: 'JetBrains Mono, monospace', width: 16 }}>{i + 1}</span>
                      <Mono size={13} bold>{r.secid}</Mono>
                    </span>
                  </td>
                  <td style={{ padding: '11px 16px', fontSize: 12, color: T.txtSecondary }}>{r.type === 'stock' ? 'акция' : 'фьючерс'}</td>
                  <td style={{ padding: '11px 16px' }}><Mono size={12} color={r.assetCode === '—' ? T.txtDisabled : T.txtSecondary}>{r.assetCode}</Mono></td>
                  <td style={{ padding: '11px 16px', textAlign: 'right' }}><Mono size={12} bold>{r.rows.toLocaleString('ru-RU')}</Mono></td>
                  <td style={{ padding: '11px 16px', textAlign: 'right' }}><Mono size={12} color={T.txtSecondary}>{r.typesCovered}/6</Mono></td>
                  <td style={{ padding: '11px 16px' }}><Mono size={12} color={T.txtSecondary}>{r.commission}</Mono></td>
                  <td style={{ padding: '11px 16px' }}><Mono size={12} color={T.txtPrimary}>{r.liquidity.toFixed(1)}</Mono></td>
                  <td style={{ padding: '11px 16px' }}>
                    {r.qualityOk
                      ? <span style={{ fontSize: 11, color: '#22C55E' }}>✓ ok</span>
                      : <span style={{ fontSize: 11, color: '#EF4444' }}>✗ проблемы</span>
                    }
                  </td>
                  <td style={{ padding: '11px 16px' }}><ScoreBar score={r.score} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AppShell>
  );
}
