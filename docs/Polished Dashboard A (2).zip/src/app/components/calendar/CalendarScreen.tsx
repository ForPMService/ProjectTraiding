import { useState } from 'react';
import { Download } from 'lucide-react';
import { AppShell, NavPage, T, Mono, StatusBadge, PrimaryBtn, SectionLabel, EmptyState } from '../shell/AppShell';

const TODAY_DATA = {
  stock:   { label: 'Фондовый рынок', trading: true,  schedule: '10:00 – 18:50',  nextClearing: '14:00' },
  futures: { label: 'Срочный рынок',  trading: true,  schedule: '09:00 – 23:50',  nextClearing: '14:00 / 18:45' },
};

// Calendar grid — June 2026
const JUNE_2026 = [
  { d: 1, trading: true,  type: 'normal'  },
  { d: 2, trading: true,  type: 'normal'  },
  { d: 3, trading: true,  type: 'normal'  },
  { d: 4, trading: true,  type: 'normal'  },
  { d: 5, trading: true,  type: 'normal'  },
  { d: 6, trading: false, type: 'weekend' },
  { d: 7, trading: false, type: 'weekend' },
  { d: 8, trading: true,  type: 'normal'  },
  { d: 9, trading: true,  type: 'normal'  },
  { d: 10, trading: true, type: 'normal'  },
  { d: 11, trading: true, type: 'normal'  },
  { d: 12, trading: false, type: 'holiday' },
  { d: 13, trading: false, type: 'weekend' },
  { d: 14, trading: false, type: 'weekend' },
  { d: 15, trading: true, type: 'normal'  },
  { d: 16, trading: true, type: 'normal'  },
  { d: 17, trading: true, type: 'normal'  },
  { d: 18, trading: true, type: 'normal'  },
  { d: 19, trading: true, type: 'normal'  },
  { d: 20, trading: false, type: 'weekend' },
  { d: 21, trading: false, type: 'weekend' },
  { d: 22, trading: true, type: 'normal'  },
  { d: 23, trading: true, type: 'normal'  },
  { d: 24, trading: true, type: 'normal'  },
  { d: 25, trading: true, type: 'normal'  },
  { d: 26, trading: true, type: 'normal'  },
  { d: 27, trading: false, type: 'weekend' },
  { d: 28, trading: false, type: 'weekend' },
  { d: 29, trading: true, type: 'normal'  },
  { d: 30, trading: true, type: 'normal'  },
];

const EXPIRATIONS = [
  { secid: 'SiM6', assetCode: 'Si', expirationDate: '2026-06-18', daysLeft: 0,  type: 'futures' },
  { secid: 'BRN6', assetCode: 'BR', expirationDate: '2026-06-29', daysLeft: 10, type: 'futures' },
  { secid: 'SiU6', assetCode: 'Si', expirationDate: '2026-09-17', daysLeft: 90, type: 'futures' },
];

const TYPE_STYLE: Record<string, { bg: string; border: string; color: string; hint: string }> = {
  normal:  { bg: 'transparent', border: T.hairline, color: T.txtPrimary, hint: '' },
  weekend: { bg: 'rgba(75,85,99,0.12)', border: 'rgba(75,85,99,0.3)', color: T.txtMuted, hint: '' },
  holiday: { bg: 'rgba(239,68,68,0.08)', border: 'rgba(239,68,68,0.25)', color: '#EF4444', hint: 'Праздник' },
  trading_weekend: { bg: 'rgba(234,179,8,0.08)', border: 'rgba(234,179,8,0.25)', color: '#EAB308', hint: 'Торговый выходной' },
};

const tradingDaysInJune = JUNE_2026.filter(d => d.trading).length;
// June 1 starts on Monday (weekday 1), need to pad
const startOffset = 0; // Monday

export function CalendarScreen({ currentPage, onNavigate }: { currentPage: NavPage; onNavigate: (p: NavPage) => void }) {
  const [hoveredExp, setHoveredExp] = useState<string | null>(null);

  return (
    <AppShell currentPage={currentPage} onNavigate={onNavigate} breadcrumb="Календарь">
      <div style={{ height: '100%', overflowY: 'auto', padding: 20 }}>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 20 }}>
          <h1 style={{ fontSize: 24, fontWeight: 600, color: T.txtPrimary, margin: 0 }}>Торговый календарь</h1>
        </div>

        {/* Today block */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 20 }}>
          {Object.entries(TODAY_DATA).map(([key, d]) => (
            <div key={key} style={{ background: T.bgSurface, border: `1px solid ${T.subtle}`, borderRadius: 12, padding: 16, boxShadow: T.shadowCard }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
                <span style={{ fontSize: 13, fontWeight: 500, color: T.txtPrimary }}>{d.label}</span>
                <StatusBadge status={d.trading ? 'success' : 'neutral'} />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                <div>
                  <div style={{ fontSize: 10, color: T.txtDisabled, marginBottom: 3, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Расписание</div>
                  <Mono size={12} color={T.txtSecondary}>{d.schedule}</Mono>
                </div>
                <div>
                  <div style={{ fontSize: 10, color: T.txtDisabled, marginBottom: 3, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Клиринг</div>
                  <Mono size={12} color={T.txtSecondary}>{d.nextClearing}</Mono>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Calendar grid */}
        <div style={{ background: T.bgSurface, border: `1px solid ${T.subtle}`, borderRadius: 12, padding: 16, marginBottom: 20, boxShadow: T.shadowCard }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: T.txtPrimary }}>Июнь 2026</div>
            <div style={{ fontSize: 12, color: T.txtMuted }}>
              <Mono size={12} color={T.accent}>{tradingDaysInJune}</Mono>
              <span style={{ color: T.txtMuted }}> торговых дней</span>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 4, marginBottom: 6 }}>
            {['Пн','Вт','Ср','Чт','Пт','Сб','Вс'].map(d => (
              <div key={d} style={{ fontSize: 9, fontWeight: 600, textAlign: 'center', color: T.txtDisabled, letterSpacing: '0.1em' }}>{d}</div>
            ))}
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 4 }}>
            {Array.from({ length: startOffset }).map((_, i) => <div key={`pad-${i}`} />)}
            {JUNE_2026.map(day => {
              const st = TYPE_STYLE[day.type];
              const isToday = day.d === 19;
              return (
                <div key={day.d} style={{
                  aspectRatio: '1', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
                  borderRadius: 6, background: st.bg, border: `1px solid ${isToday ? T.accent : st.border}`,
                  cursor: 'default',
                }}>
                  <div style={{ fontSize: 12, fontWeight: isToday ? 700 : 400, color: isToday ? T.accent : st.color }}>{day.d}</div>
                  {st.hint && <div style={{ fontSize: 8, color: st.color, marginTop: 1 }}>•</div>}
                </div>
              );
            })}
          </div>
          <div style={{ display: 'flex', gap: 12, marginTop: 12, flexWrap: 'wrap' }}>
            {[
              { color: T.txtPrimary, border: T.hairline, label: 'Торговый' },
              { color: '#EF4444', border: 'rgba(239,68,68,0.25)', label: 'Праздник' },
              { color: '#EAB308', border: 'rgba(234,179,8,0.25)', label: 'Торговый выходной' },
              { color: T.txtMuted, border: 'rgba(75,85,99,0.3)', label: 'Выходной' },
            ].map(leg => (
              <div key={leg.label} style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                <div style={{ width: 12, height: 12, borderRadius: 3, border: `1px solid ${leg.border}` }} />
                <span style={{ fontSize: 11, color: T.txtSecondary }}>{leg.label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Expirations */}
        <div style={{ marginBottom: 4 }}>
          <SectionLabel>Экспирации &lt; 30 дней</SectionLabel>
          <div style={{ background: T.bgSurface, border: `1px solid ${T.subtle}`, borderRadius: 12, overflow: 'hidden', boxShadow: T.shadowCard }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ background: T.bgApp }}>
                  {['SECID', 'ASSET_CODE', 'ЭКСПИРАЦИЯ', 'ДНЕЙ', 'ТИП'].map(h => (
                    <th key={h} style={{ padding: '10px 16px', textAlign: 'left', fontSize: 9, fontWeight: 600, letterSpacing: '0.16em', textTransform: 'uppercase', color: T.txtMuted, borderBottom: `1px solid ${T.hairline}` }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {EXPIRATIONS.filter(e => e.daysLeft < 30).map(e => (
                  <tr key={e.secid}
                    onMouseEnter={() => setHoveredExp(e.secid)}
                    onMouseLeave={() => setHoveredExp(null)}
                    style={{ background: hoveredExp === e.secid ? T.bgHover : 'transparent', borderBottom: `1px solid rgba(26,30,37,0.6)`, transition: 'background 0.1s' }}
                  >
                    <td style={{ padding: '11px 16px' }}><Mono size={13} bold>{e.secid}</Mono></td>
                    <td style={{ padding: '11px 16px' }}><Mono size={12} color={T.txtSecondary}>{e.assetCode}</Mono></td>
                    <td style={{ padding: '11px 16px' }}><Mono size={12} color={T.txtSecondary}>{e.expirationDate}</Mono></td>
                    <td style={{ padding: '11px 16px' }}>
                      <Mono size={12} color={e.daysLeft <= 5 ? '#EF4444' : e.daysLeft <= 14 ? '#EAB308' : T.txtPrimary} bold>
                        {e.daysLeft === 0 ? 'сегодня' : `${e.daysLeft}`}
                      </Mono>
                    </td>
                    <td style={{ padding: '11px 16px' }}>
                      <span style={{ fontSize: 11, color: T.txtMuted, padding: '2px 6px', background: T.bgApp, borderRadius: 4, border: `1px solid ${T.hairline}` }}>{e.type}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
